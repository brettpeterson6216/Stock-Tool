/* ══════════════════════════════════════════════════════
   STATE
══════════════════════════════════════════════════════ */

/* ── Client analytics ─────────────────────────────────────────────────── */
function acquisitionContext() {
  const params = new URLSearchParams(window.location.search);
  let persisted = {};
  try { persisted = JSON.parse(sessionStorage.getItem('ilAcquisitionContext') || '{}'); } catch (_) {}
  let referrerHost = '';
  try { referrerHost = document.referrer ? new URL(document.referrer).hostname : ''; } catch (_) {}
  const context = {
    path: window.location.pathname,
    ticker: (params.get('ticker') || '').toUpperCase().replace(/[^A-Z0-9.\-^]/g, '').slice(0, 10) || null,
    source: params.get('source') || persisted.source || null,
    utm_source: params.get('utm_source') || persisted.utm_source || null,
    utm_medium: params.get('utm_medium') || persisted.utm_medium || null,
    utm_campaign: params.get('utm_campaign') || persisted.utm_campaign || null,
    referrer_host: referrerHost || persisted.referrer_host || null,
  };
  const filtered = Object.fromEntries(Object.entries(context).filter(([, value]) => value !== null && value !== ''));
  try {
    const attribution = Object.fromEntries(
      ['source','utm_source','utm_medium','utm_campaign','referrer_host']
        .filter(key => filtered[key])
        .map(key => [key, filtered[key]])
    );
    if (Object.keys(attribution).length) sessionStorage.setItem('ilAcquisitionContext', JSON.stringify(attribution));
  } catch (_) {}
  return filtered;
}

async function track(event, props = {}) {
  try {
    await fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event, properties: { ...acquisitionContext(), ...props } }),
      keepalive: true,
    });
  } catch (_) { /* never crash the caller */ }
}

function analysisReturnUrl(extra = {}) {
  const params = new URLSearchParams({ view: 'tool', section: 'analyze', resume_analysis: '1' });
  const ticker = (document.getElementById('main-ticker')?.value || S.ticker || '').trim().toUpperCase()
    .replace(/[^A-Z0-9.\-^]/g, '').slice(0, 10);
  if (ticker) params.set('ticker', ticker);
  if (S.range) params.set('range', S.range);
  Object.entries(extra).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== '') params.set(key, String(value));
  });
  return '/?' + params.toString();
}

function startGuestSignup(source = 'guest_prompt') {
  const ticker = (document.getElementById('main-ticker')?.value || S.ticker || '').trim().toUpperCase()
    .replace(/[^A-Z0-9.\-^]/g, '').slice(0, 10);
  const next = analysisReturnUrl({ source });
  try { sessionStorage.setItem('pendingAnalysisContext', JSON.stringify({ ticker, range: S.range, source })); } catch (_) {}
  track('guest_signup_started', { source, ticker: ticker || null });
  const params = new URLSearchParams({ next, source });
  if (ticker) params.set('ticker', ticker);
  const context = acquisitionContext();
  ['utm_source','utm_medium','utm_campaign'].forEach(key => { if (context[key]) params.set(key, context[key]); });
  window.location.href = '/signup?' + params.toString();
}

function startGuestLogin(source = 'guest_prompt') {
  const ticker = (document.getElementById('main-ticker')?.value || S.ticker || '').trim().toUpperCase()
    .replace(/[^A-Z0-9.\-^]/g, '').slice(0, 10);
  const next = analysisReturnUrl({ source });
  const params = new URLSearchParams({ next, source });
  if (ticker) params.set('ticker', ticker);
  const context = acquisitionContext();
  ['utm_source','utm_medium','utm_campaign'].forEach(key => { if (context[key]) params.set(key, context[key]); });
  window.location.href = '/login?' + params.toString();
}

const S = {
  ticker: null, data: null, range: '1y',
  charts: {},
  inds: { ma50: true, ma200: false, bb: false },
  chartType: 'candle',
  screenerData: null,
  screenerSort: { col: 'marketCap', dir: -1 },
  userPlan: 'free',   // 'free' | 'trial' | 'pro'
  loggedIn: false,
  authReady: false,
  trialEndsAt: null,
  analystTarget: null,  // { mean, high, low } set by loadAnalyst()
  csrfToken: null,      // fetched from GET /api/csrf on page load
};
window.IL_STATE = S;
window.S = S;  // alias so external modules (Projection Lab, Valuation Lab) can read app state
const COLORS = ['#16C784','#3B82F6','#A78BFA','#F5B83D'];
// Keep this list in sync with the requirePro-gated API routes in routes/financials.js
// and routes/market-data.js (screener).
const PRO_SECTIONS = ['financials','advmetrics','projection','dcf','screener',
  'earnings','secfilings','institutional','analyst','darkpool'];
const PRO_SECTION_CONTENT = {};

function isPro() { return S.userPlan === 'pro' || S.userPlan === 'trial'; }

function syncPlanUI() {
  const pro = isPro();
  const sidebarUpgrade = document.getElementById('sb-pro-card');
  const homeUpgrade = document.getElementById('hsb-upgrade-box');
  const navUpgrade = document.getElementById('nav-upgrade');
  if (sidebarUpgrade) {
    sidebarUpgrade.style.display = pro ? 'none' : '';
    sidebarUpgrade.setAttribute('aria-hidden', String(pro));
  }
  if (homeUpgrade) homeUpgrade.style.display = pro ? 'none' : homeUpgrade.style.display;
  if (navUpgrade && pro) navUpgrade.style.display = 'none';
  const limitCounter = document.getElementById('limit-counter');
  if (limitCounter && pro) limitCounter.style.display = 'none';
  document.documentElement.dataset.plan = pro ? 'pro' : 'free';
  if (pro && typeof PRO_SECTION_CONTENT !== 'undefined' && typeof PRO_SECTIONS !== 'undefined') {
    const activeSection=document.querySelector('.app-section.open');
    const activeId=activeSection?.id?.replace('sec-','');
    const activeBody=activeId ? document.getElementById('body-'+activeId) : null;
    if(activeId && PRO_SECTIONS.includes(activeId) && activeBody?.querySelector('.pro-gate-card,.sec-state-wrap') && PRO_SECTION_CONTENT[activeId]){
      activeBody.innerHTML=PRO_SECTION_CONTENT[activeId];
      if(typeof openSection==='function') openSection(activeId,true);
    }
  }
}

/* ══════════════════════════════════════════════════════
   CENTRALISED SECTION HELPERS
   sectionProGateHtml(id)   — contextual upgrade card
   sectionLoadingHtml()     — spinner markup
   sectionErrorHtml(msg)    — error markup
   proAwareFetch(url,id)    — fetch that throws typed errors
   handleSectionError(e,id,el) — routes errors to right UI
══════════════════════════════════════════════════════ */
/* ── Rich contextual Pro gate config ── */
const PRO_GATE_CONFIG = {
  financials: {
    title: 'Full Financial Statements',
    bullets: [
      'Annual &amp; quarterly income statements — revenue, gross profit, net income',
      'Balance sheet: assets, liabilities, and shareholder equity breakdown',
      'Cash flow statement: operating, investing &amp; financing activities',
      '5-year trend view to spot growth acceleration or deterioration early',
    ],
    preview: `<table class="pgc-tbl"><thead><tr><th>Income Statement</th><th>FY2023</th><th>FY2024</th></tr></thead><tbody>
      <tr><td>Revenue</td><td>$383.3B</td><td>$391.0B</td></tr>
      <tr><td>Gross Profit</td><td>$169.1B</td><td>$180.7B</td></tr>
      <tr><td>Operating Income</td><td>$114.3B</td><td>$123.2B</td></tr>
      <tr><td>Net Income</td><td>$97.0B</td><td>$93.7B</td></tr>
      <tr><td>EPS (diluted)</td><td>$6.16</td><td>$6.11</td></tr>
    </tbody></table>`,
    previewLabel: 'AAPL FY2023–2024 · sample',
  },
  advmetrics: {
    title: 'Advanced Risk &amp; Performance Metrics',
    bullets: [
      'Sharpe &amp; Sortino ratios, Alpha, Beta vs S&amp;P 500 benchmark',
      'Value at Risk (VaR), Max Drawdown, and annualised volatility',
      'Valuation history: P/E, P/B, P/S, EV/EBITDA trends over time',
      'Identify over/undervalued conditions with full historical context',
    ],
    preview: `<div>
      <div class="pgc-row"><span class="pgc-row-label">Sharpe Ratio (1Y)</span><span class="pgc-row-val">1.43</span></div>
      <div class="pgc-row"><span class="pgc-row-label">Beta vs S&amp;P 500</span><span class="pgc-row-val">1.21</span></div>
      <div class="pgc-row"><span class="pgc-row-label">Max Drawdown</span><span class="pgc-row-val">−18.2%</span></div>
      <div class="pgc-row"><span class="pgc-row-label">Annualised Volatility</span><span class="pgc-row-val">22.4%</span></div>
      <div class="pgc-row"><span class="pgc-row-label">P/E Ratio (TTM)</span><span class="pgc-row-val">28.4×</span></div>
    </div>`,
    previewLabel: 'AAPL · illustrative sample',
  },
  earnings: {
    title: 'EPS History &amp; Beat/Miss Tracker',
    bullets: [
      'Quarterly EPS actuals vs Wall Street consensus estimates — every quarter',
      'Beat/miss percentage and streak — how consistently it surprises',
      'Revenue trend across the last 8+ reporting periods',
      'Forward EPS estimates and analyst guidance revision history',
    ],
    preview: `<table class="pgc-tbl"><thead><tr><th>Quarter</th><th>Est. EPS</th><th>Act. EPS</th><th>Surprise</th></tr></thead><tbody>
      <tr><td>Q1 FY25</td><td>$2.35</td><td>$2.40</td><td style="color:#46b184">+2.1%</td></tr>
      <tr><td>Q4 FY24</td><td>$1.60</td><td>$1.64</td><td style="color:#46b184">+2.5%</td></tr>
      <tr><td>Q3 FY24</td><td>$1.34</td><td>$1.40</td><td style="color:#46b184">+4.5%</td></tr>
      <tr><td>Q2 FY24</td><td>$1.50</td><td>$1.53</td><td style="color:#46b184">+2.0%</td></tr>
    </tbody></table>`,
    previewLabel: 'AAPL recent quarters · sample',
  },
  secfilings: {
    title: 'SEC EDGAR Filings — Direct Access',
    bullets: [
      'Annual reports (10-K): complete financials and business overview',
      'Quarterly reports (10-Q): interim results every 3 months',
      'Material event filings (8-K): immediate disclosure of major news',
      'Proxy statements (DEF 14A): executive pay, board votes, governance',
    ],
    preview: `<table class="pgc-tbl"><tbody>
      <tr><td>10-K</td><td>Annual Report</td><td>Nov 1, 2024</td></tr>
      <tr><td>10-Q</td><td>Quarterly Report</td><td>Aug 2, 2024</td></tr>
      <tr><td>8-K</td><td>Earnings Release</td><td>Aug 1, 2024</td></tr>
      <tr><td>10-Q</td><td>Quarterly Report</td><td>May 3, 2024</td></tr>
      <tr><td>DEF 14A</td><td>Proxy Statement</td><td>Jan 15, 2024</td></tr>
    </tbody></table>`,
    previewLabel: 'AAPL recent filings · sample',
  },
  institutional: {
    title: 'Institutional Holdings &amp; Fund Activity',
    bullets: [
      'Top institutional holders with exact share counts and % of float owned',
      'Recent additions, reductions, and newly opened positions each quarter',
      'Total institutional ownership % and concentration risk at a glance',
      'FINRA OTC activity paired with reported institutional ownership',
    ],
    preview: `<table class="pgc-tbl"><thead><tr><th>Institution</th><th>Shares</th><th>% Float</th></tr></thead><tbody>
      <tr><td>Vanguard Group</td><td>1.29B</td><td>8.2%</td></tr>
      <tr><td>BlackRock</td><td>1.02B</td><td>6.5%</td></tr>
      <tr><td>Berkshire Hathaway</td><td>789M</td><td>5.0%</td></tr>
      <tr><td>State Street</td><td>598M</td><td>3.8%</td></tr>
    </tbody></table>`,
    previewLabel: 'AAPL top holders · sample',
  },
  analyst: {
    title: 'Analyst Price Targets &amp; Ratings',
    bullets: [
      'Consensus price target with upside/downside % from today\'s price',
      'Buy / Hold / Sell breakdown across all covering Wall Street analysts',
      'Individual firm targets — Goldman, Morgan Stanley, JPMorgan, and more',
      'Historical target trend — where analysts stood 3, 6, and 12 months ago',
    ],
    preview: null,
  },
  darkpool: {
    title: 'FINRA OTC &amp; Institutional Activity',
    bullets: [
      'Aggregated weekly OTC volume and trade counts from FINRA',
      'Review changes in off-exchange activity over time',
      'Keep activity context separate from unsupported intent claims',
      'Compare OTC activity with reported institutional ownership',
    ],
    preview: null,
  },
  projection: {
    title: 'Independent Bull, Base &amp; Bear Scenario Lab',
    bullets: [
      'Model bull, base, and bear price scenarios simultaneously',
      'Set earnings growth, exit P/E, dividends, dilution, and probability independently',
      'Probability-weighted expected value with total-return and CAGR estimates',
      'Save projections and revisit them as the story changes quarter to quarter',
    ],
    preview: null,
  },
  dcf: {
    title: 'EPS Intrinsic Value Model',
    bullets: [
      'Set your own earnings growth, terminal growth, and discount rate',
      'Calculates an EPS-based intrinsic-value range',
      'Shows whether the stock is over or undervalued at today\'s price',
      'Sensitivity table: see exactly how fair value shifts with each assumption',
    ],
    preview: `<div style="text-align:center;padding:.4rem 0 .2rem;">
      <div style="font-size:.63rem;color:var(--ink5);letter-spacing:.06em;text-transform:uppercase;margin-bottom:.3rem">Intrinsic Value Estimate</div>
      <div style="font-size:1.9rem;font-family:var(--serif);color:var(--gold);font-weight:700;line-height:1">$198.40</div>
      <div style="font-size:.7rem;color:var(--ink4);margin-top:.25rem">vs market $219.86 · <span style="color:#d96a70">−9.8% overvalued</span></div>
      <div style="margin-top:.65rem;display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px;font-size:.67rem">
        <div style="background:var(--bg2);border-radius:5px;padding:4px 3px"><div style="color:var(--ink5)">Growth</div><div style="color:var(--ink)">8.0%</div></div>
        <div style="background:var(--bg2);border-radius:5px;padding:4px 3px"><div style="color:var(--ink5)">Margin</div><div style="color:var(--ink)">25%</div></div>
        <div style="background:var(--bg2);border-radius:5px;padding:4px 3px"><div style="color:var(--ink5)">WACC</div><div style="color:var(--ink)">9.0%</div></div>
      </div>
    </div>`,
    previewLabel: 'AAPL · illustrative EPS value sample',
  },
  screener: {
    title: 'Full Market Screener — 200+ Stocks',
    bullets: [
      'Filter by sector, market cap, P/E, P/B, beta, momentum, and 15+ metrics',
      'Sort by revenue growth, dividend yield, or 1-year price performance',
      'Click any result to instantly load the full stock analysis',
      'Uses the latest available provider observations at request time',
    ],
    preview: `<table class="pgc-tbl"><thead><tr><th>Stock</th><th>Sector</th><th>P/E</th><th>1Y Chg</th></tr></thead><tbody>
      <tr><td>AAPL</td><td>Technology</td><td>28.4×</td><td style="color:#46b184">+22%</td></tr>
      <tr><td>MSFT</td><td>Technology</td><td>34.1×</td><td style="color:#46b184">+18%</td></tr>
      <tr><td>NVDA</td><td>Semiconductors</td><td>65.2×</td><td style="color:#46b184">+82%</td></tr>
      <tr><td>JPM</td><td>Financials</td><td>12.3×</td><td style="color:#46b184">+41%</td></tr>
    </tbody></table>`,
    previewLabel: 'Sample screener results',
  },
  adveducation: {
    title: 'Advanced Investor Education',
    bullets: [
      'Detailed DCF &amp; relative valuation modelling guides with worked examples',
      'Driver-based forecasting and model-audit frameworks',
      'Per-share economics, dilution, and capital-allocation analysis',
      'Base rates, position sizing, and repeatable review workflows',
    ],
    preview: null,
  },
};

function sectionProGateHtml(id) {
  const cfg = PRO_GATE_CONFIG[id];
  const ticker = (S && S.ticker) ? S.ticker : '';
  const titleSuffix = ticker ? ' — ' + ticker : '';

  if (!cfg) {
    return `<div class="pro-gate-card"><div class="pgc-body">
      <div class="pgc-badge">⚡ Pro Feature</div>
      <div class="pgc-title">Pro Feature${titleSuffix}</div>
      <button class="pgc-btn js-pgc-upgrade">Start 7-day free trial →</button>
      <div class="pgc-note">7-day free trial · Discount codes accepted in Checkout</div>
    </div></div>`;
  }

  const previewHtml = cfg.preview ? `
    <div class="pgc-preview">
      <div class="pgc-preview-blur">${cfg.preview}</div>
      <div class="pgc-preview-overlay"></div>
      ${cfg.previewLabel ? `<div class="pgc-preview-tag">${cfg.previewLabel}</div>` : ''}
    </div>` : '';

  return `<div class="pro-gate-card">
    ${previewHtml}
    <div class="pgc-body">
      <div class="pgc-badge">⚡ Pro Feature</div>
      <div class="pgc-title">${cfg.title}${titleSuffix}</div>
      <ul class="pgc-bullets">
        ${cfg.bullets.map(b => `<li>${b}</li>`).join('\n        ')}
      </ul>
      <button class="pgc-btn js-pgc-upgrade">Start 7-day free trial →</button>
      <div class="pgc-note">7-day free trial · Discount codes accepted in Checkout</div>
    </div>
  </div>`;
}

function sectionLoadingHtml() {
  return '<div class="sec-state-wrap"><span class="spinner"></span><span style="color:var(--ink4);font-size:.82rem;">Loading…</span></div>';
}

function sectionErrorHtml(msg) {
  return `<div class="sec-state-wrap sec-state-error"><span style="font-size:1.1rem;">⚠</span><span>${escapeHtml(msg)}</span></div>`;
}

async function refreshAuthStateForAccess() {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'same-origin' });
    if (!res.ok) return false;
    const { user } = await res.json();
    if (user) {
      S.userPlan = user.effectivePlan || 'free';
      S.trialEndsAt = user.trial_ends_at || null;
      S.loggedIn = true;
      S.emailVerified = !!user.email_verified;
    } else {
      S.userPlan = 'free';
      S.loggedIn = false;
      S.emailVerified = false;
    }
    syncPlanUI();
    return isPro();
  } catch (_) {
    return false;
  }
}

async function proAwareFetch(url, sectionId, opts) {
  const retryingAuth = !!(opts && opts._retriedAuth);
  const fetchOpts = { ...(opts || {}) };
  delete fetchOpts._retriedAuth;
  const res = await fetch(url, { credentials: 'same-origin', ...fetchOpts });
  if (res.status === 401) { const e = new Error('LOGIN_REQUIRED');  e.code = 'LOGIN_REQUIRED';  throw e; }
  if (res.status === 403) {
    if (!retryingAuth && await refreshAuthStateForAccess()) {
      return proAwareFetch(url, sectionId, { ...fetchOpts, _retriedAuth: true });
    }
    const e = new Error('PRO_REQUIRED');    e.code = 'PRO_REQUIRED';    e.sectionId = sectionId; throw e;
  }
  if (res.status === 429) { const e = new Error('LIMIT_REACHED');   e.code = 'LIMIT_REACHED';   throw e; }
  if (!res.ok)            { throw new Error(`Request failed (${res.status})`); }
  return res;
}

function handleSectionError(e, sectionId, container) {
  if (!container) return;
  if (e.code === 'PRO_REQUIRED') {
    container.innerHTML = sectionProGateHtml(sectionId);
    container.style.display = 'block';
    track('pro_gate_viewed', { section: sectionId, ticker: S.ticker || null });
  } else if (e.code === 'LOGIN_REQUIRED') {
    container.innerHTML = `<div class="pro-gate-card"><div class="pgc-body" style="padding:1.5rem 1.75rem">
      <div class="pgc-badge" style="background:var(--ink2)">🔒 Sign in required</div>
      <div class="pgc-title" style="font-size:1rem">Create a free account to continue</div>
      <ul class="pgc-bullets">
        <li>Free account: 5 analyses per day, price charts, projections</li>
        <li>Cloud-saved analyses that sync across all your devices</li>
        <li>Upgrade to Pro anytime for full access — no pressure</li>
      </ul>
      <a href="/signup" onclick="startGuestSignup('pro_gate_login_required');return false;" style="display:block;background:var(--ink);color:var(--cream);border-radius:9px;padding:.8rem 1.6rem;font-size:.9rem;font-weight:700;text-decoration:none;text-align:center;margin-bottom:.5rem;">Create free account →</a>
      <div style="font-size:.75rem;color:var(--ink4);text-align:center">Already have an account? <a href="/login" onclick="startGuestLogin('pro_gate_login_required');return false;" style="color:var(--gold);font-weight:600;">Sign in</a></div>
    </div></div>`;
    container.style.display = 'block';
  } else if (e.code === 'LIMIT_REACHED') {
    container.innerHTML = `<div class="pro-gate-card"><div class="pgc-body">
      <div class="pgc-badge">⚡ Daily limit reached</div>
      <div class="pgc-title">You've used your 5 free analyses today</div>
      <ul class="pgc-bullets">
        <li>Unlimited stock analyses — no daily cap, ever</li>
        <li>All Pro sections: Financials, intrinsic value, Screener, SEC filings &amp; more</li>
        <li>Advanced projections, institutional data, and analyst targets</li>
        <li>Comes back tomorrow free, or unlock everything now</li>
      </ul>
      <button class="pgc-btn js-pgc-upgrade">Start 7-day free trial →</button>
      <div class="pgc-note">7-day free trial · Discount codes accepted in Checkout</div>
    </div></div>`;
    container.style.display = 'block';
  } else {
    container.innerHTML = sectionErrorHtml(e.message || 'Failed to load data');
    container.style.display = 'block';
  }
}




function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function safeExternalUrl(value) {
  try {
    const url = new URL(String(value || ''), window.location.origin);
    return url.protocol === 'https:' || url.protocol === 'http:' ? escapeHtml(url.href) : '';
  } catch (_) {
    return '';
  }
}

// ── Accordion open/close ──
function openSection(id, skipProCheck) {
  // For Pro sections: open the panel and show the gate card inline
  // (still shows modal only if user explicitly triggers upgrade button)
  if (!skipProCheck && PRO_SECTIONS.includes(id) && !isPro()) {
    // Fall through — we'll render the gate card inside the section body
  }
  // Close all sections first
  document.querySelectorAll('.app-section').forEach(el => {
    el.classList.remove('open');
    const b = el.querySelector('.acc-body');
    if (b) b.style.display = 'none';
  });
  // Update sidebar active state (workspace sub-items are activated by the click handler)
  const wsItems = document.querySelectorAll('.sb-item[data-sec="' + id + '"][data-wstab]');
  document.querySelectorAll('.sb-item').forEach(el => {
    el.classList.toggle('active', el.dataset.sec === id && !el.dataset.wstab && !el.dataset.scroll);
  });
  if (wsItems.length && !document.querySelector('.sb-item.active')) wsItems[0].classList.add('active');
  // Sync the mobile section strip active state.
  document.querySelectorAll('.mst-btn').forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-sec') === id);
  });
  // Top-bar active tab follows the section's nav group; the left panel shows
  // only that group's options and can never change the top tab.
  const navGroup = navGroupOf(id);
  document.querySelectorAll('#nav-links .nav-tab').forEach(el => el.classList.remove('active-tab'));
  document.getElementById(NAV_GROUP_TAB[navGroup])?.classList.add('active-tab');
  renderSidebarGroup(navGroup);
  // Open the target section
  const sec = document.getElementById('sec-' + id);
  const bod = document.getElementById('body-' + id);
  if (!sec || !bod) return;
  document.getElementById('view-tool')?.setAttribute('data-active-section', id);
  if (PRO_SECTIONS.includes(id) && !PRO_SECTION_CONTENT[id] && !bod.querySelector('.pro-gate-card')) {
    PRO_SECTION_CONTENT[id] = bod.innerHTML;
  }
  if (PRO_SECTIONS.includes(id) && isPro() && PRO_SECTION_CONTENT[id] && bod.querySelector('.pro-gate-card')) {
    bod.innerHTML = PRO_SECTION_CONTENT[id];
  }
  sec.classList.add('open');
  bod.style.display = 'block';
  setTimeout(function(){ if(window.refreshToolEnhancements) window.refreshToolEnhancements(); },0);
  // Show/hide chart toolbars (only for analyze)
  const ct = document.getElementById('app-chart-toolbar');
  const tf = document.getElementById('app-tf-strip');
  if (ct) ct.style.display = id === 'analyze' ? '' : 'none';
  if (tf) tf.style.display = id === 'analyze' ? '' : 'none';
  // Update section header
  updateSectionHeader(id);
  // Scroll content to top
  const scroll = document.querySelector('.app-content-scroll');
  if (scroll) scroll.scrollTop = 0;
  // Auto-load data tabs
  const t = S.ticker;
  if (PRO_SECTIONS.includes(id) && !S.authReady) {
    bod.innerHTML = sectionLoadingHtml();
    history.replaceState(null, '', '/?view=tool&section=' + encodeURIComponent(id));
    window.IL_AUTH_READY?.then(() => {
      if (sec.classList.contains('open')) openSection(id, true);
    });
    return;
  }
  if (!isPro() && PRO_SECTIONS.includes(id) && id !== 'reports') {
    // Show contextual gate card inline — user can dismiss and see upgrade options
    const gateBody = document.getElementById('body-' + id);
    if (gateBody) { gateBody.innerHTML = sectionProGateHtml(id); gateBody.style.display = 'block'; }
  } else if (id === 'financials')  { if(t) loadFinancials(t); }
  else if (id === 'advmetrics')  { if(t) loadAdvMetrics(t); }
  else if (id === 'earnings')    { if(t) loadEarnings(t); }
  else if (id === 'secfilings')     { if(t) loadSecFilings(t); }
  else if (id === 'institutional')  { if(t) loadInstitutional(t); }
  else if (id === 'screener')    { loadScreener(); }
  else if (id === 'projection')  { mountProjectionLab(); }
  else if (id === 'dcf')         { mountValuationLab(); }
  else if (id === 'reports')     { setTimeout(renderSavedAnalyses, 100); }
  else if (id === 'education')   { setTimeout(function(){ var c=document.querySelector('.edu-path[data-lesson]'); if(c && typeof openLesson==='function' && !document.querySelector('#edu-lesson-panel .edu-lesson-content')) openLesson(c); }, 30); }
  else if (id === 'analyze')     { if(!S.ticker){ if(typeof loadFeaturedGridOnce==='function') loadFeaturedGridOnce(); if(typeof window.renderToolLaunch==='function') window.renderToolLaunch(); } }
  if (document.getElementById('view-tool')?.style.display !== 'none') {
    history.replaceState(null, '', '/?view=tool&section=' + encodeURIComponent(id));
  }
}

function closeSection(id) {
  const sec = document.getElementById('sec-' + id);
  const bod = document.getElementById('body-' + id);
  if (!sec || !bod) return;
  sec.classList.remove('open');
  bod.style.display = 'none';
}

// Mount / re-seed the Projection Lab into its section.
function mountProjectionLab() {
  const mountEl = document.getElementById('il-projlab-mount');
  const empty = document.getElementById('il-projlab-empty');
  if (!mountEl) return;
  if (!(window.S && S.ticker)) { if (empty) empty.style.display = 'block'; return; }
  if (empty) empty.style.display = 'none';
  if (window.ProjectionLab && typeof window.ProjectionLab.mount === 'function') {
    window.ProjectionLab.mount('il-projlab-mount');
  }
}

// Mount / re-seed the Valuation Lab into the Value (dcf) section.
function mountValuationLab() {
  const mountEl = document.getElementById('vlab-mount');
  const empty = document.getElementById('vlab-empty');
  if (!mountEl) return;
  if (!(window.S && S.ticker)) { if (empty) empty.style.display = 'block'; return; }
  if (empty) empty.style.display = 'none';
  // Ensure financials are cached for seeding, then mount.
  if (!(window.S && S.financialsRaw) && typeof window.loadFinancials === 'function' && !window._vlabLoadingFin) {
    window._vlabLoadingFin = true;
    if (window.ValuationLab) window.ValuationLab.mount('vlab-mount');
    Promise.resolve(window.loadFinancials(S.ticker)).then(function () {
      window._vlabLoadingFin = false;
      if (window.ValuationLab && document.getElementById('sec-dcf')?.classList.contains('open')) window.ValuationLab.reseed();
    }).catch(function () { window._vlabLoadingFin = false; });
    return;
  }
  if (window.ValuationLab && typeof window.ValuationLab.mount === 'function') window.ValuationLab.mount('vlab-mount');
}

// Persist a Valuation Lab model into the existing Saved Analyses system.
function saveValuationToAnalyses(state) {
  try {
    if (typeof persistSavedEntry !== 'function') return;
    const entry = { id: Date.now(), type: 'valuation', ticker: (state && state.ticker) || (window.S && S.ticker) || '', title: ((state && state.ticker) || 'Valuation') + ' — Valuation Lab', date: new Date().toISOString(), data: { model: state, price: (window.S && S.data && S.data.meta && S.data.meta.regularMarketPrice) || null } };
    persistSavedEntry(entry, 'Valuation saved');
  } catch (e) {}
}

function saveProjectionToAnalyses(model) {
  try {
    if (typeof persistSavedEntry !== 'function' || !model) return;
    const ticker = model.ticker || (window.S && S.ticker) || '';
    const entry = {
      id: Date.now(),
      type: 'projection',
      ticker,
      title: (ticker || 'Projection') + ' — Projection Lab',
      date: new Date().toISOString(),
      data: {
        model,
        price: model.startPrice || (window.S && S.data && S.data.meta && S.data.meta.regularMarketPrice) || null
      }
    };
    persistSavedEntry(entry, 'Projection saved');
  } catch (e) {}
}

function toggleSection(id) {
  const sec = document.getElementById('sec-' + id);
  if (!sec) return;
  if (sec.classList.contains('open')) {
    closeSection(id);
  } else {
    openSection(id);
  }
}

// Keep switchTab as alias so any legacy calls don't break
function switchTab(id, btn) {
  openSection(id);
}

// App shell helpers
const SECTION_META = {
  analyze:     { icon:'ti-chart-candle',  title:'Chart & Analysis' },
  financials:  { icon:'ti-table',         title:'Financials' },
  advmetrics:  { icon:'ti-report-analytics', title:'Adv. Metrics' },
  earnings:    { icon:'ti-trending-up',   title:'Earnings & EPS' },
  secfilings:  { icon:'ti-file-text',     title:'SEC Filings' },
  institutional:{ icon:'ti-building-bank', title:'Institutional' },
  compare:     { icon:'ti-adjustments-horizontal', title:'Compare Stocks' },
  projection:  { icon:'ti-timeline',      title:'Projection' },
  dcf:         { icon:'ti-calculator',    title:'EPS Intrinsic Value' },
  screener:    { icon:'ti-filter',        title:'Screener' },
  reports:     { icon:'ti-bookmark',      title:'Saved Analyses' },
  education:   { icon:'ti-school',        title:'Learn' },
};

function updateSectionHeader(id) {
  const m = SECTION_META[id] || { icon:'ti-layout', title: id };
  const iconEl = document.getElementById('ash-icon');
  const titleEl = document.getElementById('ash-title');
  const subEl = document.getElementById('ash-sub');
  if (iconEl) { iconEl.className = ''; iconEl.classList.add('ti', m.icon, 'ash-icon'); }
  if (titleEl) titleEl.textContent = m.title;
  if (subEl && S.ticker) subEl.textContent = S.name ? S.name + ' · ' + (S.meta && S.meta.exchangeName || '') : S.ticker;
  else if (subEl) subEl.textContent = '';
}

function updateNavTickerBar() {
  const bar = document.getElementById('nav-ticker-bar');
  if (!bar || !S.ticker) return;
  const sym = document.getElementById('ntb-sym');
  const price = document.getElementById('ntb-price');
  const chg = document.getElementById('ntb-chg');
  if (sym) sym.textContent = S.ticker;
  const p = S.data && S.data.meta && S.data.meta.regularMarketPrice;
  const c = S.data && S.data.meta && S.data.meta.regularMarketChangePercent;
  if (price && p) price.textContent = '$' + p.toFixed(2);
  if (chg && c !== undefined) {
    const pct = c.toFixed(2);
    chg.textContent = (c >= 0 ? '▲ +' : '▼ ') + pct + '%';
    chg.className = 'ntb-chg ' + (c >= 0 ? 'ntb-pos' : 'ntb-neg');
  }
  bar.classList.add('visible');
}

function updateStatsFooter() {
  if (!S.data || !S.data.meta) return;
  const m = S.data.meta;
  const fmt = (v, pre='$') => v != null ? pre + (v >= 1e12 ? (v/1e12).toFixed(2)+'T' : v >= 1e9 ? (v/1e9).toFixed(2)+'B' : v >= 1e6 ? (v/1e6).toFixed(2)+'M' : v.toFixed(2)) : '—';
  const set = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
  set('asf-open',  m.regularMarketOpen    != null ? '$'+m.regularMarketOpen.toFixed(2) : '—');
  set('asf-high',  m.regularMarketDayHigh != null ? '$'+m.regularMarketDayHigh.toFixed(2) : '—');
  set('asf-low',   m.regularMarketDayLow  != null ? '$'+m.regularMarketDayLow.toFixed(2) : '—');
  set('asf-vol',   m.regularMarketVolume  != null ? fmt(m.regularMarketVolume,'') : '—');
  set('asf-mktcap',m.marketCap            != null ? fmt(m.marketCap) : '—');
  set('asf-pe',    m.trailingPE           != null ? m.trailingPE.toFixed(1)+'×' : '—');
  set('asf-eps',   m.epsTrailingTwelveMonths != null ? '$'+m.epsTrailingTwelveMonths.toFixed(2) : '—');
  set('asf-52hi',  m.fiftyTwoWeekHigh     != null ? '$'+m.fiftyTwoWeekHigh.toFixed(2) : '—');
  set('asf-52lo',  m.fiftyTwoWeekLow      != null ? '$'+m.fiftyTwoWeekLow.toFixed(2) : '—');
}

function updateNavToolLink(isHome) {
  // All nav tabs always visible — no-op
  const bar = document.getElementById('nav-ticker-bar');
  if (bar && isHome) bar.classList.remove('visible');
}

function setChartType(type, btn) {
  document.querySelectorAll('#app-chart-toolbar .act-btn[id^="ct-"]').forEach(b => {
    const selected = b === btn;
    b.classList.toggle('on', selected);
    b.setAttribute('aria-pressed', String(selected));
  });
  S.chartType = type;
  rebuildPriceChart();
}
// Expanded/fullscreen chart type switching (line/area/candle) — price chart only.
function syncExpandedTypeToggle(){
  var tg=document.getElementById('cex-type-toggle'); if(!tg) return;
  // Chart type now lives in the unified expanded toolbar. The duplicate toggle
  // made the phone header taller than the plot controls themselves.
  tg.style.display='none';
}
function setExpandedChartType(type){
  if(!_expandedSource||_expandedSource.chartId!=='price-chart') return;
  S.chartType=type;
  document.querySelectorAll('#app-chart-toolbar .act-btn[id^="ct-"]').forEach(function(b){ var sel=b.id==='ct-'+type; b.classList.toggle('on',sel); b.setAttribute('aria-pressed',String(sel)); });
  rebuildPriceChart();
  expandChart('price-chart', _expandedSource.title);
}


/* ══════════════════════════════════════════════════════
   TABS
══════════════════════════════════════════════════════ */


/* =====================================================
   SAVED ANALYSES
===================================================== */
var _savedSort = 'date';
var _savedTypeFilter = 'ALL';
var _saListEntries = [];

const SA_KEY = 'impliedLens_savedAnalyses';

// Saves storage — DB when logged in, localStorage fallback
function getSavedAnalyses() {
  try { return JSON.parse(localStorage.getItem(SA_KEY) || '[]'); } catch(_) { return []; }
}
function putSavedAnalyses(arr) {
  try { localStorage.setItem(SA_KEY, JSON.stringify(arr)); } catch(_) {}
}
function savedEntrySignature(entry) {
  return [entry.type || '', entry.ticker || '', entry.title || '', entry.date || ''].join('|');
}
async function persistSavedEntry(entry, successMessage) {
  const localEntry = { ...entry, syncState: S.loggedIn ? 'syncing' : 'local' };
  const all = getSavedAnalyses();
  all.unshift(localEntry);
  putSavedAnalyses(all.slice(0, 100));
  renderSavedAnalyses();

  if (!S.loggedIn) {
    toast((successMessage || 'Saved') + ' on this device ✓', 'green');
    return localEntry;
  }

  try {
    const response = await fetch('/api/saves', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.csrfToken || '' },
      body: JSON.stringify({ ticker: entry.ticker, type: entry.type, label: entry.title, data: entry })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok || !result.id) {
      throw new Error(result.error || 'Cloud save failed');
    }
    const saved = getSavedAnalyses().map(item => item.id === entry.id
      ? { ...item, id: 'db_' + result.id, _dbId: result.id, syncState: 'synced' }
      : item);
    putSavedAnalyses(saved);
    renderSavedAnalyses();
    toast((successMessage || 'Saved') + ' to your account ✓', 'green');
    return saved.find(item => item._dbId === result.id) || localEntry;
  } catch (_) {
    const saved = getSavedAnalyses().map(item => item.id === entry.id
      ? { ...item, syncState: 'local' }
      : item);
    putSavedAnalyses(saved);
    renderSavedAnalyses();
    toast('Saved on this device — cloud sync failed.', 'red');
    return localEntry;
  }
}
// Load from DB into local cache and re-render
async function syncSavesFromDB() {
  try {
    const r = await fetch('/api/saves', { credentials:'same-origin' });
    if (!r.ok) return;
    const rows = await r.json();
    // Merge DB rows into localStorage format
    const mapped = rows.map(row => {
      const payload = row.data && typeof row.data === 'object' ? row.data : {};
      return {
        ...payload,
        id: 'db_' + row.id,
        _dbId: row.id,
        ticker: row.ticker,
        type: row.type,
        title: row.label || payload.title || row.ticker,
        date: payload.date || row.created_at,
        data: payload.data && typeof payload.data === 'object' ? payload.data : payload,
        syncState: 'synced'
      };
    });
    const remoteSignatures = new Set(mapped.map(savedEntrySignature));
    const localOnly = getSavedAnalyses().filter(entry => !entry._dbId && !remoteSignatures.has(savedEntrySignature(entry)));
    putSavedAnalyses([...mapped, ...localOnly].slice(0, 100));
    renderSavedAnalyses();
  } catch(_) {}
}

async function saveAnalysis(type) {
  if (!S.ticker && type !== 'note' && type !== 'compare') { toast('Load a stock first.', 'err'); return; }
  const meta = S.data?.meta || {};
  let title = '', data = {};
  const price = meta.regularMarketPrice;
  const now = new Date().toISOString();

  if (type === 'price') {
    title = `${S.ticker} — Price Snapshot $${price ? price.toFixed(2) : '—'}`;
    data = { price, marketCap: meta.marketCap, range: S.range };
  } else if (type === 'dcf') {
    const dcfEl = document.getElementById('dcf-output');
    title = `${S.ticker} — EPS Intrinsic Value`;
    data = { intrinsicText: dcfEl ? dcfEl.innerText.slice(0,200) : '', price };
  } else if (type === 'projection') {
    const projEl = document.getElementById('adv-scenario-cards') || document.getElementById('adv-proj-results');
    const assumptions = {};
    ['adv-years','adv-price','adv-pe-now','adv-g-bear','adv-pe-bear','adv-div-bear','adv-div-g-bear','adv-dil-bear','adv-prob-bear','adv-g-base','adv-pe-base','adv-div-base','adv-div-g-base','adv-dil-base','adv-prob-base','adv-g-bull','adv-pe-bull','adv-div-bull','adv-div-g-bull','adv-dil-bull','adv-prob-bull'].forEach(id => { assumptions[id] = document.getElementById(id)?.value; });
    title = `${S.ticker} — Scenario Lab`;
    data = { summaryText: projEl ? projEl.innerText.slice(0,400) : '', assumptions, price };
  } else if (type === 'compare') {
    const tickers = ['cmp1','cmp2','cmp3','cmp4'].map(id=>document.getElementById(id)?.value.trim().toUpperCase()).filter(Boolean);
    title = `Compare: ${tickers.join(' vs ')}`;
    data = { tickers };
  }

  const entryTicker = type === 'compare' ? (data.tickers?.[0] || S.ticker || '') : (S.ticker || '');
  const entry = { id: Date.now(), type, ticker: entryTicker, title, date: now, data };
  return persistSavedEntry(entry, 'Analysis saved');
}

function setSavedSort(s) {
  _savedSort = s;
  document.querySelectorAll('.sa-sort-btn').forEach(b => b.classList.toggle('active', b.id === 'sa-sort-'+s));
  renderSavedAnalyses();
}

function setSavedTypeFilter(t) {
  _savedTypeFilter = t;
  document.querySelectorAll('.sa-pill').forEach(b => b.classList.toggle('active', b.dataset.type === t));
  renderSavedAnalyses();
}

async function deleteSavedAnalysis(id) {
  const all = getSavedAnalyses();
  const entry = all.find(a => a.id === id);
  if (entry && entry._dbId) {
    try {
      const response = await fetch('/api/saves/' + entry._dbId, {
        method:'DELETE',
        credentials:'same-origin',
        headers:{'X-CSRF-Token': S.csrfToken||''}
      });
      if (!response.ok) throw new Error('Delete failed');
    } catch (_) {
      toast('Could not delete this cloud save. Try again.', 'red');
      return;
    }
  }
  putSavedAnalyses(all.filter(a => a.id !== id));
  renderSavedAnalyses();
  toast('Saved analysis deleted.', 'green');
}

async function clearAllSaved() {
  if (!confirm('Clear all saved analyses? This cannot be undone.')) return;
  if (S.loggedIn) {
    try {
      const response = await fetch('/api/saves', {
        method:'DELETE',
        credentials:'same-origin',
        headers:{'X-CSRF-Token': S.csrfToken||''}
      });
      if (!response.ok) throw new Error('Clear failed');
    } catch (_) {
      toast('Could not clear your cloud saves. Try again.', 'red');
      return;
    }
  }
  putSavedAnalyses([]);
  renderSavedAnalyses();
  toast('Saved analyses cleared.', 'green');
}

async function loadSavedAnalysis(entry) {
  if (!entry || !entry.data) {
    toast('This saved analysis is incomplete.', 'red');
    return;
  }
  if (entry.type === 'compare' && entry.data.tickers) {
    entry.data.tickers.forEach((t,i) => {
      const el = document.getElementById('cmp'+(i+1));
      if (el) el.value = t;
    });
    openSection('compare');
    await runCompare();
    toast('Saved comparison reopened ✓', 'green');
    return;
  }
  if (entry.type === 'lensscore' && entry.ticker) {
    window.location.assign('/lens-score?ticker=' + encodeURIComponent(entry.ticker));
    return;
  }
  if (entry.ticker) {
    const ticker = String(entry.ticker).trim().toUpperCase();
    const input = document.getElementById('main-ticker');
    if (!input) {
      toast('Research search is unavailable. Reload and try again.', 'red');
      return;
    }
    if (entry.type === 'projection' && entry.data.model) {
      try { localStorage.setItem('il-projlab:v2:' + ticker, JSON.stringify(entry.data.model)); } catch (_) {}
    }
    if (entry.type === 'valuation' && entry.data.model) {
      try { localStorage.setItem('il-vlab:' + ticker, JSON.stringify(entry.data.model)); } catch (_) {}
    }
    input.value = ticker;
    if (typeof navGoTo === 'function') navGoTo('analyze');
    else openSection('analyze');
    toast('Loading ' + ticker + '…', 'green');
    await fetchAndRender();
    if (S.ticker !== ticker) return;

    if (entry.type === 'projection') {
      if (typeof navGoTo === 'function') navGoTo('projection');
      else openSection('projection');
      if (entry.data.assumptions) {
        Object.entries(entry.data.assumptions).forEach(([id, value]) => {
          const field = document.getElementById(id);
          if (field && value != null) field.value = value;
        });
        if (typeof runAdvancedProjection === 'function') runAdvancedProjection();
      }
    } else if (entry.type === 'dcf' || entry.type === 'valuation') {
      if (typeof navGoTo === 'function') navGoTo('dcf');
      else openSection('dcf');
    }
    toast((entry.title || ticker + ' analysis') + ' reopened ✓', 'green');
  }
}

function renderSavedAnalyses() {
  const list = document.getElementById('sa-list');
  const empty = document.getElementById('sa-empty');
  if (!list) return;
  // Show guest/sync notice
  const guestBanner = document.getElementById('sa-guest-banner');
  const syncBanner  = document.getElementById('sa-sync-banner');
  if (guestBanner) guestBanner.style.display = !S.loggedIn ? 'block' : 'none';
  if (syncBanner)  syncBanner.style.display  = S.loggedIn ? 'block' : 'none';

  let all = getSavedAnalyses();
  if (_savedTypeFilter !== 'ALL') all = all.filter(a => a.type === _savedTypeFilter);

  if (_savedSort === 'date') {
    all.sort((a,b) => (Date.parse(b.date || 0) || 0) - (Date.parse(a.date || 0) || 0));
  } else if (_savedSort === 'stock') {
    all.sort((a,b) => (a.ticker||'').localeCompare(b.ticker||''));
  } else if (_savedSort === 'type') {
    all.sort((a,b) => a.type.localeCompare(b.type));
  }

  if (!all.length) {
    list.innerHTML = '';
    if (empty) empty.style.display = 'block';
    return;
  }
  if (empty) empty.style.display = 'none';

  const typeLabels = { price:'Price Snapshot', dcf:'Intrinsic Value', valuation:'Valuation Lab', projection:'Projection', lensscore:'LensScore', compare:'Compare', note:'Note' };
  const typeClass  = { price:'sa-type-price', dcf:'sa-type-dcf', valuation:'sa-type-dcf', projection:'sa-type-projection', lensscore:'sa-type-lensscore', compare:'sa-type-compare', note:'sa-type-note' };

  _saListEntries = all;
  list.innerHTML = all.map((entry, idx) => {
    const d = new Date(entry.date);
    const dateStr = d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})
      + ' ' + d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});
    const label = typeLabels[entry.type] || entry.type;
    const cls   = typeClass[entry.type] || 'sa-type-note';
    const lensData = entry.type === 'lensscore' ? (entry.data?.data || entry.data || {}) : null;
    const lensScores = lensData?.lenses;
    const lensSummary = lensData && Number.isFinite(Number(lensData.score))
      ? `<div class="sa-lens-summary"><span>LensScore <strong>${Number(lensData.score).toFixed(1)}</strong></span>${Number.isFinite(Number(lensScores?.value?.score)) ? `<span>Value <strong>${Number(lensScores.value.score).toFixed(1)}</strong></span>` : ''}${Number.isFinite(Number(lensScores?.setup?.score)) ? `<span>Setup <strong>${Number(lensScores.setup.score).toFixed(1)}</strong></span>` : ''}${Number.isFinite(Number(lensData.entryPrice)) ? `<span>Test price <strong>$${Number(lensData.entryPrice).toFixed(2)}</strong></span>` : ''}</div>`
      : '';
    return `<div class="sa-card">
      <span class="sa-type-badge ${cls}">${escapeHtml(label)}</span>
      <div class="sa-card-body">
        <div class="sa-card-title">${escapeHtml(entry.title)}</div>
        <div class="sa-card-meta">${escapeHtml(dateStr)}${entry.ticker ? ' · '+escapeHtml(entry.ticker) : ''}${entry.syncState === 'local' && S.loggedIn ? ' · Saved on this device' : ''}</div>
        ${lensSummary}
        <div class="sa-card-actions">
          <button class="sa-btn" data-sa-action="load" data-sa-idx="${idx}">↩ Load</button>
          <button class="sa-del-btn" data-sa-action="del" data-sa-idx="${idx}">✕ Delete</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function checkReportReady() {
  renderSavedAnalyses();
}

function exportPDF() {
  saveAnalysis('price');
}

// switchTab → now handled by toggleSection/openSection above

function showUpgradeModal(annual, source) {
  document.getElementById('upgrade-modal-bg').classList.add('show');
  if(annual) selectUpgradePlan('annual'); else selectUpgradePlan('monthly');
  track('upgrade_modal_opened', { source: source || 'unknown', ticker: S.ticker || null });
}
function closeUpgradeModal() {
  document.getElementById('upgrade-modal-bg').classList.remove('show');
  _resetUpgradeModal();
}

/* ── Account Settings modal ── */
async function openAccountModal() {
  document.getElementById('acct-modal-bg').classList.add('show');
  // Reset all fields & messages
  ['am-cur-pw','am-new-pw','am-confirm-pw'].forEach(id => { const el = document.getElementById(id); if(el) el.value=''; });
  const msg = document.getElementById('am-pw-msg'); if(msg) msg.textContent='';
  const unInput = document.getElementById('am-new-username'); if(unInput) unInput.value='';
  const unMsg = document.getElementById('am-username-msg'); if(unMsg) unMsg.textContent='';

  try {
    const r = await fetch('/api/auth/me', { credentials:'same-origin' });
    const { user } = await r.json();
    if (!user) return;

    document.getElementById('am-username').textContent = user.username || '—';
    document.getElementById('am-email').textContent    = user.email    || '—';

    const since = user.created_at
      ? new Date(typeof user.created_at === 'number' ? user.created_at : user.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})
      : '—';
    document.getElementById('am-since').textContent = since;

    const planEl = document.getElementById('am-plan');
    if (user.effectivePlan === 'pro') {
      planEl.innerHTML = '<span style="color:var(--gold-d);">✦ Pro</span>';
    } else if (user.effectivePlan === 'trial') {
      planEl.innerHTML = '<span style="color:var(--gold-d);">Trial</span>';
      const trialRow = document.getElementById('am-trial-row');
      const trialInfo = document.getElementById('am-trial-info');
      if (trialRow && user.trial_ends_at) {
        const end = new Date(user.trial_ends_at);
        const days = Math.max(0, Math.ceil((end - Date.now()) / 86400000));
        const expiry = end.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'});
        trialInfo.innerHTML = days > 0
          ? `<span style="color:${days<=3?'#e67e22':'var(--ink2)'};">${days} day${days!==1?'s':''} remaining — expires <strong>${expiry}</strong></span>`
          : `<span style="color:#c0392b;">Trial expired on ${expiry}</span>`;
        trialRow.style.display = 'block';
      }
      // Legacy trial rows may not have a Stripe customer yet.
      const subBtn = document.getElementById('am-sub-btn');
      if (subBtn && !user.stripe_customer_id) subBtn.style.display = 'none';
    } else {
      planEl.textContent = 'Free';
      // Swap button to upgrade CTA
      const subBtn = document.getElementById('am-sub-btn');
      if (subBtn) { subBtn.textContent = '⭐ Upgrade to Pro'; subBtn.href='#'; subBtn.onclick=function(e){e.preventDefault();closeAccountModal();showUpgradeModal();}; }
    }
  } catch(_) {}
}

function closeAccountModal() {
  document.getElementById('acct-modal-bg').classList.remove('show');
}

async function submitUsernameChange() {
  const input = document.getElementById('am-new-username');
  const msg   = document.getElementById('am-username-msg');
  const val   = input.value.trim().toLowerCase();
  if (!val)           { msg.style.color='#c0392b'; msg.textContent='Please enter a new username.'; return; }
  if (val.length < 3) { msg.style.color='#c0392b'; msg.textContent='Username must be at least 3 characters.'; return; }
  if (!/^[a-z0-9_.-]+$/.test(val)) { msg.style.color='#c0392b'; msg.textContent='Only letters, numbers, _ . and - are allowed.'; return; }
  msg.style.color='var(--ink3)'; msg.textContent='Updating…';
  try {
    const r = await fetch('/api/auth/change-username', {
      method:'POST', credentials:'same-origin',
      headers:{'Content-Type':'application/json','X-CSRF-Token': S.csrfToken||''},
      body: JSON.stringify({ username: val }),
    });
    const data = await r.json();
    if (data.ok) {
      msg.style.color='#27ae60'; msg.textContent='Username updated successfully.';
      input.value = '';
      document.getElementById('am-username').textContent = val;
      const navName = document.getElementById('nav-acct-name');
      const hdrName = document.getElementById('nav-acct-header-name');
      if (navName) navName.textContent = val;
      if (hdrName) hdrName.textContent = val;
    } else {
      msg.style.color='#c0392b'; msg.textContent = data.error || 'Update failed.';
    }
  } catch(_) { msg.style.color='#c0392b'; msg.textContent='Network error. Please try again.'; }
}

async function submitPasswordChange() {
  const cur  = document.getElementById('am-cur-pw').value.trim();
  const nw   = document.getElementById('am-new-pw').value;
  const conf = document.getElementById('am-confirm-pw').value;
  const msg  = document.getElementById('am-pw-msg');

  if (!cur || !nw || !conf) { msg.style.color='#c0392b'; msg.textContent='Please fill in all fields.'; return; }
  if (nw.length < 8)         { msg.style.color='#c0392b'; msg.textContent='New password must be at least 8 characters.'; return; }
  if (nw.length > 200)       { msg.style.color='#c0392b'; msg.textContent='New password must be 200 characters or fewer.'; return; }
  if (nw !== conf)           { msg.style.color='#c0392b'; msg.textContent='New passwords do not match.'; return; }

  msg.style.color='var(--ink3)'; msg.textContent='Updating…';
  try {
    const r = await fetch('/api/auth/change-password', {
      method:'POST', credentials:'same-origin',
      headers:{'Content-Type':'application/json','X-CSRF-Token': S.csrfToken||''},
      body: JSON.stringify({ currentPassword:cur, newPassword:nw }),
    });
    const data = await r.json();
    if (data.ok) {
      if (data.csrfToken) S.csrfToken = data.csrfToken;
      msg.style.color='#27ae60'; msg.textContent='Password updated successfully.';
      ['am-cur-pw','am-new-pw','am-confirm-pw'].forEach(id => { document.getElementById(id).value=''; });
    } else {
      msg.style.color='#c0392b'; msg.textContent = data.error || 'Update failed.';
    }
  } catch(_) { msg.style.color='#c0392b'; msg.textContent='Network error. Please try again.'; }
}

async function openBillingPortal() {
  try {
    const r = await fetch('/api/stripe/portal', {
      method: 'POST',
      headers: { 'X-CSRF-Token': S.csrfToken||'' },
      credentials: 'same-origin',
    });
    const data = await r.json().catch(() => ({}));
    if (r.status === 401) {
      window.location.href = '/login?next=' + encodeURIComponent('/');
      return;
    }
    if (r.status === 404) {
      if (typeof closeAccountModal === 'function') closeAccountModal();
      showUpgradeModal(false, 'billing_portal_no_subscription');
      return;
    }
    if (!r.ok || !data.url) {
      toast(data.error || 'Could not open the billing portal.', 'err');
      return;
    }
    window.location.href = data.url;
  } catch (_) {
    toast('Could not open the billing portal. Please try again.', 'err');
  }
}

async function startTrial(annual) {
  try {
    const r = await fetch('/api/stripe/create-checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.csrfToken||'' },
      credentials: 'same-origin',
      body: JSON.stringify({ annual: !!annual }),
    });
    const data = await r.json();
    if (!r.ok) {
      if (data.hasSubscription) {
        await openBillingPortal();
        return;
      }
      if (data.requiresEmailVerification) {
        S.emailVerified = false;
        showUpgradeModal(!!annual, 'checkout_requires_verification');
        document.getElementById('upgrade-modal-unverified').style.display = 'block';
      }
      toast(data.error || 'Could not start checkout.', 'err');
      return;
    }
    sessionStorage.removeItem('pendingUpgradePlan');
    window.location.href = data.url;
  } catch (e) {
    toast('Something went wrong. Please try again.', 'err');
  }
}

// Decorate pro sections with lock indicator in nav tabs
function decorateProTabs() {
  if (isPro()) {
    // Remove all pro badges from nav for paying users
    document.querySelectorAll('.acc-pro-badge').forEach(el => el.style.display = 'none');
    return;
  }
  // Add lock to nav items for pro sections
  document.querySelectorAll('a.nav-tab[data-tool]').forEach(a => {
    const id = a.getAttribute('data-tool');
    if (PRO_SECTIONS.includes(id) && !a.querySelector('.tab-lock')) {
      const lock = document.createElement('span');
      lock.className = 'tab-lock';
      lock.textContent = ' 🔒';
      a.appendChild(lock);
    }
    if (isPro()) {
      const lock = btn.querySelector('.tab-lock');
      if (lock) lock.remove();
    }
  });
}

/* ══════════════════════════════════════════════════════
   MODAL
══════════════════════════════════════════════════════ */
function openModal() { document.getElementById('modal-bg').classList.add('show'); }
function closeModal() { document.getElementById('modal-bg').classList.remove('show'); }
function selectPlan(el) { document.querySelectorAll('.plan-opt').forEach(p=>p.classList.remove('sel')); el.classList.add('sel'); }

let _upgradePlan = 'monthly';
function selectUpgradePlan(plan) {
  _upgradePlan = plan;
  document.getElementById('plan-monthly').classList.toggle('sel', plan === 'monthly');
  document.getElementById('plan-annual').classList.toggle('sel', plan === 'annual');
}
async function handleUpgradeClick() {
  // Guest: show inline auth instead of failing at Stripe
  if (!S.loggedIn) {
    track('checkout_requires_login', { plan: _upgradePlan });
    sessionStorage.setItem('pendingUpgradePlan', _upgradePlan);
    // Attach plan to signup/login links so they redirect back
    const signupBtn = document.getElementById('upgrade-signup-btn');
    const loginBtn  = document.getElementById('upgrade-login-btn');
    const ticker = (document.getElementById('main-ticker')?.value || S.ticker || '').trim().toUpperCase()
      .replace(/[^A-Z0-9.\-^]/g, '').slice(0, 10);
    const context = acquisitionContext();
    const upgradeAuthUrl = path => {
      const params = new URLSearchParams({ next: '/?resume_checkout=1', source: 'upgrade_modal' });
      if (ticker) params.set('ticker', ticker);
      ['utm_source','utm_medium','utm_campaign'].forEach(key => { if (context[key]) params.set(key, context[key]); });
      return `${path}?${params.toString()}`;
    };
    if (signupBtn) {
      signupBtn.href = upgradeAuthUrl('/signup');
      signupBtn.onclick = () => {
        track('signup_started_from_upgrade', { plan: _upgradePlan });
        track('guest_signup_started', { source: 'upgrade_modal', plan: _upgradePlan, ticker: ticker || null });
      };
    }
    if (loginBtn) {
      loginBtn.href = upgradeAuthUrl('/login');
      loginBtn.onclick = () => track('login_started_from_upgrade', { plan: _upgradePlan });
    }
    document.getElementById('upgrade-cta-btn').style.display = 'none';
    document.querySelector('#upgrade-modal-bg .modal-note').style.display = 'none';
    document.getElementById('upgrade-modal-auth').style.display = 'block';
    document.getElementById('upgrade-modal-unverified').style.display = 'none';
    return;
  }
  // Logged in but email not verified
  if (!S.emailVerified) {
    track('checkout_blocked_unverified', { plan: _upgradePlan });
    document.getElementById('upgrade-modal-unverified').style.display = 'block';
    return;
  }
  const btn = document.getElementById('upgrade-cta-btn');
  btn.disabled = true; btn.textContent = 'Redirecting to checkout…';
  await startTrial(_upgradePlan === 'annual');
  btn.disabled = false; btn.textContent = 'Start 7-day free trial →';
}

// Reset modal state when closed
function _resetUpgradeModal() {
  const cta = document.getElementById('upgrade-cta-btn');
  const note = document.querySelector('#upgrade-modal-bg .modal-note');
  if (cta)  { cta.style.display = ''; cta.disabled = false; cta.textContent = 'Start 7-day free trial →'; }
  if (note) note.style.display = '';
  const authDiv  = document.getElementById('upgrade-modal-auth');
  const unverifDiv = document.getElementById('upgrade-modal-unverified');
  if (authDiv)    authDiv.style.display = 'none';
  if (unverifDiv) unverifDiv.style.display = 'none';
}

/* ══════════════════════════════════════════════════════
   TOAST
══════════════════════════════════════════════════════ */
function toast(msg, type='') {
  const t=document.getElementById('toast');
  const kind = type === 'green' || type === 'ok' ? 'ok' : type === 'red' || type === 'err' ? 'err' : '';
  const icon = kind === 'ok' ? 'ti-check' : kind === 'err' ? 'ti-alert-triangle' : 'ti-info-circle';
  t.className='toast show '+kind;
  t.style.setProperty('background-color',kind==='ok'?'#0f2a1c':kind==='err'?'#2a0f0f':'#171a20','important');
  t.style.setProperty('color',kind==='ok'?'#e9fff2':kind==='err'?'#fff0f0':'#f7f4ee','important');
  t.replaceChildren();
  const iconWrap=document.createElement('span');iconWrap.className='toast-icon';iconWrap.setAttribute('aria-hidden','true');
  const iconEl=document.createElement('i');iconEl.className='ti '+icon;iconWrap.appendChild(iconEl);
  const text=document.createElement('span');text.className='toast-msg';text.textContent=msg;
  t.append(iconWrap,text);
  setTimeout(()=>t.classList.remove('show'),3000);
}

function toggleToolbarOption(btn) {
  const selected = !btn.classList.contains('on');
  btn.classList.toggle('on', selected);
  btn.setAttribute('aria-pressed', String(selected));
}

async function resendVerification() {
  try {
    const r = await fetch('/api/auth/resend-verification', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.csrfToken||'' },
      credentials: 'same-origin',
    });
    const d = await r.json();
    if (r.ok) toast('Verification email sent! Check your inbox.', 'ok');
    else      toast(d.error || 'Could not send email.', 'err');
  } catch(_) { toast('Network error.', 'err'); }
}

/* ══════════════════════════════════════════════════════
   FETCH
══════════════════════════════════════════════════════ */
async function yahooFetch(ticker, range='1y') {
  const localPreview = /^(127\.0\.0\.1|localhost)$/.test(window.location.hostname) ? '&preview=1' : '';
  const r = await fetch(`/api/quote/${encodeURIComponent(ticker)}?range=${range}${localPreview}`, { credentials: 'same-origin' });

  // Handle rate limit / daily cap
  if (r.status === 429) {
    const d = await r.json().catch(()=>({}));
    updateLimitUI(d.remaining ?? 0, d.limit ?? 5, d.plan || 'free');
    if (d.requiresLogin) {
      const e = new Error('SIGNUP_REQUIRED');
      e.limitData = d; throw e;
    }
    const e = new Error('LIMIT_REACHED');
    e.limitData = d; throw e;
  }

  if (!r.ok) {
    const d = await r.json().catch(()=>({}));
    const e = new Error(r.status === 404 ? 'TICKER_NOT_FOUND' : 'QUOTE_LOAD_FAILED');
    e.status = r.status;
    e.detail = d.error || '';
    throw e;
  }
  const d = await r.json();
  if (!d.chart?.result?.[0]) throw new Error('TICKER_NOT_FOUND');
  d.chart.result[0].impliedLensProvenance = d.impliedLens || null;

  // Update limit counter from response headers
  const remaining = r.headers.get('X-Analyses-Remaining');
  const limit     = r.headers.get('X-Analyses-Limit');
  const plan      = r.headers.get('X-Plan') || S.userPlan;
  if (remaining !== null) updateLimitUI(Number(remaining), Number(limit||5), plan);

  return d.chart.result[0];
}

// Update the analyses-remaining badge in the UI
function updateLimitUI(remaining, limit, plan) {
  if (plan === 'pro' || plan === 'trial' || plan === 'free') {
    S.userPlan = plan;
    syncPlanUI();
  }
  const wrap = document.getElementById('limit-counter');
  if (!wrap) return;
  if (plan === 'pro' || plan === 'trial') { wrap.style.display = 'none'; return; }
  wrap.style.display = 'flex';
  const used = limit - remaining;
  const pct  = Math.min(100, (used / limit) * 100);
  const color = remaining <= 1 ? 'var(--market-down)' : remaining <= 2 ? '#C6A052' : 'var(--market-up)';
  const isGuest = plan === 'guest';
  if (isGuest && used >= 1) {
    try {
      if (!sessionStorage.getItem('guestSignupPromptSeen')) {
        sessionStorage.setItem('guestSignupPromptSeen', '1');
        track('guest_signup_prompt_viewed', { source: 'analysis_limit_counter', used, limit });
      }
    } catch (_) {}
  }
  wrap.innerHTML = `
    <span style="font-size:.68rem;color:var(--text5);">${isGuest ? 'Guest analyses today:' : 'Free analyses today:'}</span>
    <span style="font-size:.68rem;font-weight:700;color:${color};">${used}/${limit}</span>
    <div style="height:4px;width:60px;background:var(--t-chart-border);border-radius:2px;overflow:hidden;">
      <div style="height:100%;width:${pct}%;background:${color};border-radius:2px;transition:width .3s;"></div>
    </div>
    ${isGuest
      ? `<button onclick="startGuestSignup('analysis_limit_counter')" style="font-size:.63rem;padding:.22rem .61rem;background:var(--gold);color:var(--ink);border:none;border-radius:4px;cursor:pointer;font-weight:700;">Create free account for 5/day</button>`
      : remaining === 0 ? `<button onclick="showUpgradeModal()" style="font-size:.63rem;padding:.15rem .45rem;background:var(--gold);color:var(--ink);border:none;border-radius:4px;cursor:pointer;font-weight:700;">Upgrade</button>` : ''}
  `;
}

function fmtBig(n) { if(!n) return '—'; if(n>=1e12) return `$${(n/1e12).toFixed(2)}T`; if(n>=1e9) return `$${(n/1e9).toFixed(2)}B`; if(n>=1e6) return `$${(n/1e6).toFixed(2)}M`; return `$${n.toLocaleString()}`; }
// Share counts (volume) — never prefixed with a currency symbol.
function fmtShares(n) { if(!n) return '—'; if(n>=1e12) return `${(n/1e12).toFixed(2)}T`; if(n>=1e9) return `${(n/1e9).toFixed(2)}B`; if(n>=1e6) return `${(n/1e6).toFixed(2)}M`; if(n>=1e3) return `${(n/1e3).toFixed(1)}K`; return `${n.toLocaleString()}`; }
function showDataSource(elementId, meta, fallbackSource, fallbackAsOf) {
  const element = document.getElementById(elementId);
  if (!element) return;
  const source = meta?.source || fallbackSource || 'Provider data';
  const rawAsOf = meta?.asOf || fallbackAsOf || meta?.retrievedAt || null;
  let asOf = 'as-of time unavailable';
  if (rawAsOf) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(String(rawAsOf))) {
      const reportedDate = new Date(`${rawAsOf}T12:00:00Z`);
      asOf = `as of ${reportedDate.toLocaleDateString('en-US', { dateStyle:'medium', timeZone:'UTC' })}`;
    } else {
      const parsed = new Date(rawAsOf);
      asOf = Number.isNaN(parsed.getTime())
        ? `as of ${rawAsOf}`
        : `as of ${parsed.toLocaleString('en-US', { dateStyle:'medium', timeStyle:'short' })}`;
    }
  }
  element.textContent = `${source} · ${asOf} · no synthetic replacement`;
  element.style.display = 'flex';
}
function fmtPct(n) { return n==null?'—':`${n>=0?'+':''}${n.toFixed(2)}%`; }
function alignQuoteSeries(result) {
  const q=result?.indicators?.quote?.[0]||{};
  const timestamps=result?.timestamp||[];
  const rows=timestamps.map((timestamp,index)=>({
    timestamp,
    close:q.close?.[index],
    open:q.open?.[index],
    high:q.high?.[index],
    low:q.low?.[index],
    volume:q.volume?.[index],
  })).filter(row=>Number.isFinite(Number(row.close)));
  const closes=rows.map(row=>Number(row.close));
  const alignedQuote={
    ...q,
    close:closes,
    open:rows.map(row=>Number.isFinite(Number(row.open))?Number(row.open):Number(row.close)),
    high:rows.map(row=>Number.isFinite(Number(row.high))?Number(row.high):Number(row.close)),
    low:rows.map(row=>Number.isFinite(Number(row.low))?Number(row.low):Number(row.close)),
    volume:rows.map(row=>Number.isFinite(Number(row.volume))?Number(row.volume):0),
  };
  return {
    result:{...result,timestamp:rows.map(row=>row.timestamp),indicators:{...result.indicators,quote:[alignedQuote]}},
    timestamps:rows.map(row=>row.timestamp),
    quote:alignedQuote,
    closes,
  };
}

/* ══════════════════════════════════════════════════════
   INDICATORS
══════════════════════════════════════════════════════ */
const INDICATOR_REQUIREMENTS = {
  ma50: { bars:50, label:'50D Avg' },
  ma200:{ bars:200,label:'200D Avg' },
  bb:   { bars:20, label:'Bands' },
};

function syncIndicatorAvailability(barCount) {
  Object.entries(INDICATOR_REQUIREMENTS).forEach(([ind,config])=>{
    const unavailable=barCount<config.bars;
    const title=unavailable
      ? `${config.label} requires ${config.bars} trading days; choose a longer range`
      : `Toggle ${config.label}`;
    document.querySelectorAll(`[data-ind="${ind}"], #ind-${ind}-btn`).forEach(btn=>{
      btn.disabled=unavailable;
      btn.setAttribute('aria-disabled',String(unavailable));
      btn.title=title;
    });
  });
  const note=document.getElementById('chart-data-note');
  if(!note) return;
  const unavailableActive=Object.entries(INDICATOR_REQUIREMENTS)
    .filter(([ind,config])=>S.inds[ind]&&barCount<config.bars)
    .map(([,config])=>config.label);
  note.classList.toggle('warn',unavailableActive.length>0);
  note.textContent=unavailableActive.length
    ? `${unavailableActive.join(' and ')} ${unavailableActive.length===1?'needs':'need'} more trading days. Choose a longer range.`
    : 'Zoom out at full view to load more price history';
}

function rebuildPriceChart() {
  if(!S.data) return;
  const aligned=alignQuoteSeries(S.data);
  S.data=aligned.result;
  buildPriceChart(S.data,aligned.closes,aligned.timestamps);
}

function sma(data,p) {
  return data.map((_,i)=>{
    if(i<p-1) return null;
    const window=data.slice(i-p+1,i+1);
    return window.every(Number.isFinite) ? window.reduce((a,b)=>a+b,0)/p : null;
  });
}
// ── MA/Bollinger look-back: compute overlays from a ~2y daily series so a
// 50-/200-DAY average spans the whole visible window (even a 1-month view needs
// 50 prior days). Silently falls back to visible-window SMA if unavailable. ──
function _alignToVisible(fullTs, fullVals, visibleTs){
  return visibleTs.map(function(vt){ var lo=0,hi=fullTs.length-1,idx=-1; while(lo<=hi){var mid=(lo+hi)>>1; if(fullTs[mid]<=vt){idx=mid;lo=mid+1;}else hi=mid-1;} return idx>=0?fullVals[idx]:null; });
}
function _lookbackDaily(){
  var lb=window.S&&S.maLookback; if(!lb||!lb.ts||lb.ts.length<60) return null;
  var gaps=[]; for(var i=1;i<Math.min(lb.ts.length,40);i++) gaps.push(lb.ts[i]-lb.ts[i-1]);
  gaps.sort(function(a,b){return a-b;}); var med=gaps[gaps.length>>1]||0;
  return (med>0 && med<86400*2.5) ? lb : null;
}
function _lbSeries(kind,period){
  var lb=_lookbackDaily(); if(!lb) return null;
  lb._cache=lb._cache||{}; var key=kind+period;
  if(!lb._cache[key]) lb._cache[key]= (kind==='bb') ? bollinger(lb.close,period) : sma(lb.close,period);
  return {ts:lb.ts, vals:lb._cache[key]};
}
async function ensureMALookback(ticker){
  try{
    if(window.S && S.maLookback && S.maLookback.ticker===ticker) return;
    var r=await fetch('/api/quote/'+encodeURIComponent(ticker)+'?range=2y',{credentials:'same-origin'});
    if(!r.ok) return;
    var d=await r.json(); var res=d&&d.chart&&d.chart.result&&d.chart.result[0]; if(!res) return;
    var ts=res.timestamp||[], cl=(res.indicators&&res.indicators.quote&&res.indicators.quote[0]&&res.indicators.quote[0].close)||[];
    var T=[],C=[]; var n=Math.min(ts.length,cl.length);
    for(var i=0;i<n;i++){ if(cl[i]!=null&&Number.isFinite(cl[i])){ T.push(ts[i]); C.push(Number(cl[i])); } }
    if(C.length<60) return;
    S.maLookback={ticker:ticker, ts:T, close:C, _cache:{}};
    if(S.ticker===ticker && document.getElementById('price-chart')){ try{ rebuildPriceChart(); }catch(e){} }
  }catch(e){ /* fallback to visible-window SMA */ }
}
function rsi(c,p=14) {
  return c.map((_,i)=>{ if(i<p)return null; let g=0,l=0; for(let j=i-p+1;j<=i;j++){const d=c[j]-c[j-1]; if(d>0)g+=d; else l-=d;} const rs=g/(l||.0001); return 100-100/(1+rs); });
}
function ema(d,p) {
  const arr=Array(d.length).fill(null);
  if(d.length<p || !d.slice(0,p).every(Number.isFinite)) return arr;
  const k=2/(p+1);
  let v=d.slice(0,p).reduce((a,b)=>a+b,0)/p;
  arr[p-1]=v;
  for(let i=p;i<d.length;i++){ if(Number.isFinite(d[i])){v=d[i]*k+v*(1-k);arr[i]=v;} }
  return arr;
}
function macd(c) { const e12=ema(c,12),e26=ema(c,26); const line=e12.map((v,i)=>v==null||e26[i]==null?null:v-e26[i]); const clean=line.filter(x=>x!=null); const sig=ema(clean,9); const fs=Array(line.length-sig.length).fill(null).concat(sig); const hist=line.map((v,i)=>v==null||fs[i]==null?null:v-fs[i]); return{line,sig:fs,hist}; }
function bollinger(c,p=20,m=2) { return c.map((_,i)=>{ if(i<p-1)return{u:null,l:null,mid:null}; const sl=c.slice(i-p+1,i+1); const mid=sl.reduce((a,b)=>a+b,0)/p; const std=Math.sqrt(sl.reduce((a,b)=>a+(b-mid)**2,0)/p); return{u:mid+m*std,l:mid-m*std,mid}; }); }
function calcOBV(closes,vols) { return closes.map((c2,i)=>{ if(i===0)return vols[0]||0; const prev=closes[i-1]; return 0; }).reduce((acc,_,i)=>{ if(i===0){acc.push(vols[0]||0);return acc;} const prev=closes[i-1]; const v=vols[i]||0; acc.push(acc[i-1]+(closes[i]>prev?v:closes[i]<prev?-v:0)); return acc; },[]); }
function calcATR(highs,lows,closes,p=14) { const tr=closes.map((c2,i)=>{ if(i===0)return highs[i]-lows[i]; const pc=closes[i-1]; return Math.max(highs[i]-lows[i],Math.abs(highs[i]-pc),Math.abs(lows[i]-pc)); }); return tr.map((_,i)=>{ if(i<p-1)return null; return tr.slice(i-p+1,i+1).reduce((a,b)=>a+b,0)/p; }); }

/* ══════════════════════════════════════════════════════
   CHART HELPERS
══════════════════════════════════════════════════════ */
function destroyChart(id) { if(S.charts[id]){S.charts[id].destroy();delete S.charts[id];} }
/* Returns a theme-aware chart grid color */
function isDark(){ return document.documentElement.getAttribute('data-theme')==='dark'; }
function gcol(){ return 'rgba(217,179,94,.105)'; }
function ttbg(){ return 'rgba(10,12,14,.98)'; }
function ttbody(){ return '#F6EBD2'; }
function ttborder(){ return 'rgba(217,179,94,.28)'; }
function ct() {
  var dark = document.documentElement.getAttribute('data-theme') === 'dark';
  if (dark) {
    return {
      text:     'rgba(238,233,224,.86)',
      muted:    'rgba(190,182,168,.60)',
      grid:     'rgba(220,186,110,.10)',
      zeroline: 'rgba(220,186,110,.26)',
      ttBg:     'rgba(16,18,21,.97)',
      ttTitle:  'rgba(229,191,99,.80)',
      ttBody:   '#F3ECDC',
      ttBorder: 'rgba(229,191,99,.26)',
      axisLabelBg: 'rgba(24,27,31,.96)',
      axisLabelText: '#F3ECDC',
      legendBg: 'rgba(255,255,255,0)',
    };
  }
  // Light theme — dark text on light surfaces for real contrast
  return {
    text:     'rgba(38,30,18,.82)',
    muted:    'rgba(90,76,52,.62)',
    grid:     'rgba(120,86,30,.10)',
    zeroline: 'rgba(120,86,30,.22)',
    ttBg:     'rgba(255,253,249,.98)',
    ttTitle:  '#8a6418',
    ttBody:   '#27200f',
    ttBorder: 'rgba(120,86,30,.22)',
    axisLabelBg: '#1f1813',
    axisLabelText: '#fdf6e7',
    legendBg: 'rgba(255,255,255,0)',
  };
}

/* TradingView-style crosshair — vertical + horizontal hairlines with floating
   price (y-axis) and date (x-axis) labels. Theme-aware via ct(). */
const crosshairPlugin = {
  id:'crosshair',
  afterDraw(chart){
    const cx = chart._crosshairX, cy = chart._crosshairY;
    if(cx==null) return;
    const area = chart.chartArea; if(!area) return;
    const {ctx} = chart;
    const t = ct();
    const line = t.zeroline;
    ctx.save();
    ctx.lineWidth = 1;
    ctx.setLineDash([3,3]);
    ctx.strokeStyle = line;
    // vertical
    ctx.beginPath(); ctx.moveTo(cx, area.top); ctx.lineTo(cx, area.bottom); ctx.stroke();
    // horizontal (only when pointer is inside vertically and chart opts in)
    if(chart._crosshairAxes && cy!=null && cy>=area.top && cy<=area.bottom){
      ctx.beginPath(); ctx.moveTo(area.left, cy); ctx.lineTo(area.right, cy); ctx.stroke();
    }
    ctx.setLineDash([]);
    // Axis labels (price + date) only on charts that opt in
    if(chart._crosshairAxes){
      const yScale = chart.scales.y, xScale = chart.scales.x;
      ctx.font = "600 10px 'DM Mono', monospace";
      ctx.textBaseline = 'middle';
      // price label on right edge
      if(cy!=null && cy>=area.top && cy<=area.bottom && yScale){
        const val = yScale.getValueForPixel(cy);
        const label = (chart._crosshairFmt||((v)=>('$'+Number(v).toFixed(2))))(val);
        const padX=6, h=16, w=ctx.measureText(label).width+padX*2;
        const lx=area.right+1, ly=cy;
        ctx.fillStyle=t.axisLabelBg;
        ctx.beginPath();
        (ctx.roundRect?ctx.roundRect(lx,ly-h/2,w,h,3):ctx.rect(lx,ly-h/2,w,h));
        ctx.fill();
        ctx.fillStyle=t.axisLabelText; ctx.textAlign='left';
        ctx.fillText(label, lx+padX, ly);
      }
      // date label on bottom edge
      if(xScale){
        const idx = Math.round(xScale.getValueForPixel(cx));
        const lbl = chart.data.labels && chart.data.labels[idx];
        if(lbl){
          const txt=String(lbl);
          const padX=6, h=16, w=ctx.measureText(txt).width+padX*2;
          let bx=cx-w/2; bx=Math.max(area.left, Math.min(bx, area.right-w));
          const by=area.bottom+2;
          ctx.fillStyle=t.axisLabelBg;
          ctx.beginPath();
          (ctx.roundRect?ctx.roundRect(bx,by,w,h,3):ctx.rect(bx,by,w,h));
          ctx.fill();
          ctx.fillStyle=t.axisLabelText; ctx.textAlign='left';
          ctx.fillText(txt, bx+padX, by+h/2);
        }
      }
    }
    ctx.restore();
  },
  afterEvent(chart, args){
    const evt = args.event;
    const area = chart.chartArea;
    if((evt.type==='mousemove'||evt.type==='pointermove') && area && evt.x>=area.left && evt.x<=area.right){
      chart._crosshairX = evt.x;
      chart._crosshairY = evt.y;
    } else {
      chart._crosshairX = null;
      chart._crosshairY = null;
    }
    args.changed = true;
  }
};
Chart.register(crosshairPlugin);
Chart.defaults.font.family = "'DM Sans', system-ui, sans-serif";
Chart.defaults.font.size = 11;
Chart.defaults.font.weight = '500';
Chart.defaults.color = ct().text;

function chartPriceValue(raw) {
  if (Array.isArray(raw)) return Number(raw[raw.length - 1]);
  if (raw && typeof raw === 'object') return Number(raw.y ?? raw.c ?? raw.close ?? raw.value);
  return Number(raw);
}
function fmtChartPrice(raw) {
  const value = chartPriceValue(raw);
  if (!Number.isFinite(value)) return '$--';
  if (Math.abs(value) >= 1000) return '$' + value.toLocaleString('en-US', { maximumFractionDigits: 0 });
  if (Math.abs(value) >= 100) return '$' + value.toFixed(2);
  if (Math.abs(value) >= 1) return '$' + value.toFixed(2);
  return '$' + value.toFixed(4);
}

function fmtChartAxisPrice(raw) {
  const value = chartPriceValue(raw);
  if (!Number.isFinite(value)) return '$--';
  if (Math.abs(value) >= 1000) return '$' + value.toLocaleString('en-US', { maximumFractionDigits: 0 });
  if (Math.abs(value) >= 100) return '$' + value.toFixed(0);
  if (Math.abs(value) >= 10) return '$' + value.toFixed(1);
  if (Math.abs(value) >= 1) return '$' + value.toFixed(2);
  return '$' + value.toFixed(3);
}

function expandedPriceBounds(srcCfg) {
  const values=[];
  const add=value=>{
    if(value==null||value==='') return;
    const number=Number(value);
    if(Number.isFinite(number)&&number>=0) values.push(number);
  };
  (srcCfg?.data?.datasets||[]).forEach(dataset=>{
    if(dataset.hidden) return;
    (dataset.data||[]).forEach(point=>{
      if(Array.isArray(point)) point.forEach(add);
      else if(point&&typeof point==='object') {
        const value=point.y??point.c??point.close??point.value;
        Array.isArray(value)?value.forEach(add):add(value);
      } else add(point);
    });
    (dataset._quote?.high||[]).forEach(add);
    (dataset._quote?.low||[]).forEach(add);
  });
  if(!values.length) return null;
  const low=Math.min(...values), high=Math.max(...values);
  const span=Math.max(high-low,Math.abs(high)*.035,.01);
  const pad=span*.08;
  return {min:Math.max(0,low-pad),max:high+pad};
}

const baseOpts = (extraScales={}) => {
  const t = ct();
  const compact=window.matchMedia('(max-width: 640px)').matches;
  const xExtra=extraScales.x||{};
  const yExtra=extraScales.y||{};
  return {
    responsive:true, maintainAspectRatio:false, normalized:true, resizeDelay:60,
    interaction:{mode:'index',intersect:false,axis:'xy'},
    animation:{duration:compact?0:180,easing:'easeOutQuart'},
    layout:{padding:{top:compact?6:8,right:compact?8:12,bottom:4,left:4}},
    plugins:{
      legend:{display:false},
      tooltip:{
        mode:'index', intersect:false,
        backgroundColor:t.ttBg, titleColor:t.ttTitle, bodyColor:t.ttBody,
        borderColor:t.ttBorder, borderWidth:1, padding:12, caretSize:6,
        cornerRadius:10, displayColors:true, boxWidth:8, boxHeight:8, usePointStyle:true,
        titleFont:{family:'DM Mono',size:11,weight:'600'},bodyFont:{family:'DM Sans',size:12,weight:'600'},
        callbacks:{ label: ctx => ` ${ctx.dataset.label||''}: ${ctx.parsed?.y != null ? Number(ctx.parsed.y).toLocaleString('en-US', { maximumFractionDigits: 2 }) : ctx.formattedValue}` }
      }
    },
    scales:{
      x:{ ...xExtra, border:{display:false,...(xExtra.border||{})}, title:{...(xExtra.title||{}),display:false}, ticks:{color:t.text,font:{family:'DM Mono',size:compact?9:10,weight:'600'},maxTicksLimit:compact?4:8,padding:8,autoSkip:true,...(xExtra.ticks||{})}, grid:{display:false,color:t.grid,drawTicks:false,...(xExtra.grid||{})} },
      y:{ ...yExtra, border:{display:false,...(yExtra.border||{})}, title:{...(yExtra.title||{}),display:false}, ticks:{color:t.text,font:{family:'DM Mono',size:compact?9:10,weight:'600'},padding:8,maxTicksLimit:compact?5:8,...(yExtra.ticks||{})}, grid:{color:t.grid,lineWidth:1,drawTicks:false,...(yExtra.grid||{})} }
    }
  };
};

function chartXLabels(tsArr){
  const multi=tsArr.length>1&&(new Date(tsArr[tsArr.length-1]*1000).getFullYear()!==new Date(tsArr[0]*1000).getFullYear());
  return tsArr.map(ts=>{const d=new Date(ts*1000);
    return multi?d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'2-digit'}).replace(', '," '"):d.toLocaleDateString('en-US',{month:'short',day:'numeric'});});
}
function chartZoomOptions() {
  // Inline charts are STATIC: page scrolling is never hijacked. Wheel, pinch,
  // drag zoom and panning live only in the expanded view (expandChart), where
  // body scroll is locked. Inline zoom buttons still work via chart.zoom().
  return {
    zoom:{ wheel:{enabled:false}, pinch:{enabled:false}, drag:{enabled:false}, mode:'x' },
    pan:{ enabled:false, mode:'x' },
    limits:{x:{min:'original',max:'original',minRange:4},y:{min:'original',max:'original'}},
  };
}

const CHART_RANGE_ORDER=['1d','5d','1mo','3mo','6mo','1y','2y','5y','max'];
let _rangeExpansionBusy=false;

function chartAtFullHistory(chart){
  return !chart?.getZoomLevel || chart.getZoomLevel()<=1.01;
}
async function loadMorePriceHistory(){
  if(_rangeExpansionBusy) return false;
  const current=S.range==='ytd'?'1y':S.range;
  const index=CHART_RANGE_ORDER.indexOf(current);
  const next=CHART_RANGE_ORDER[Math.min(index+1,CHART_RANGE_ORDER.length-1)];
  if(!next||next===current){
    toast('Maximum available price history is already loaded');
    return false;
  }
  _rangeExpansionBusy=true;
  try {
    const loaded=await changeRange(next);
    if(loaded) toast(`Loaded ${next==='max'?'maximum':next.toUpperCase()} price history`,'ok');
    return loaded;
  } finally {
    _rangeExpansionBusy=false;
  }
}
async function zoomPriceChart(factor){
  const chart=S.charts['price-chart'];
  if(factor<1&&chartAtFullHistory(chart)){
    await loadMorePriceHistory();
    return;
  }
  if(chart?.zoom) chart.zoom(factor);
}
function resetPriceZoom(){
  const chart=S.charts['price-chart'];
  if(chart?.resetZoom) chart.resetZoom();
}

/* ══ CHART EXPAND MODAL ══ */
var _expandedChart = null;
var _expandedSource = null;
var _expandedHasUserZoom = false;
var _markup = {tool:'cursor',color:'#16C784',items:[],draft:null,ready:false,observer:null};

function expandChart(chartId, title) {
  const src = S.charts[chartId];
  if (!src) { toast('Load a stock first', 'red'); return; }
  document.getElementById('cex-title').textContent = title;
  _expandedSource={chartId,title};
  const modal = document.getElementById('chart-expand-modal');
  modal.dataset.chartId=chartId;
  modal.dataset.chartTitle=title;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  setMarkupTool('cursor');
  clearMarkup();

  if(_expandedChart){ _expandedChart.destroy(); _expandedChart = null; }

  const canvas = document.getElementById('chart-expanded');
  // Deep-clone the chart config
  const srcCfg = src.config;
  // Rebuild datasets with hover dots enabled
  const datasets = (srcCfg.data.datasets||[]).map(ds => ({
    ...ds,
    pointRadius: ds.type==='bar' ? undefined : 0,
    pointHoverRadius: ds.type==='bar' ? undefined : 6,
    pointHoverBorderWidth: 2,
    pointHoverBackgroundColor: ds.borderColor || cp().price,
    pointHoverBorderColor: '#fff',
  }));

  const theme = ct();
  const compact=window.matchMedia('(max-width: 640px)').matches;
  const isPriceChart=chartId==='price-chart';
  const priceBounds=isPriceChart?expandedPriceBounds(srcCfg):null;
  _expandedChart = new Chart(canvas, {
    type: srcCfg.type,
    data: { labels:[...srcCfg.data.labels], datasets },
    options: {
      ...srcCfg.options,
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      layout:{
        ...(srcCfg.options?.layout||{}),
        padding:compact?{top:4,right:4,bottom:2,left:2}:{top:8,right:16,bottom:8,left:8}
      },
      plugins: {
        ...(srcCfg.options?.plugins||{}),
        legend: { display: !compact, labels: { color:theme.text, font:{family:'DM Sans',size:11,weight:'500'}, boxWidth:20, boxHeight:2, padding:16, usePointStyle:false } },
        tooltip: {
          enabled: window.__ilTipOn !== false,
          mode:'index', intersect:false,
          backgroundColor:ttbg(), titleColor:theme.muted, bodyColor:ttbody(),
          borderColor:ttborder(), borderWidth:1, padding:12, caretSize:6,
          cornerRadius:10, displayColors:true, boxWidth:8, boxHeight:8, usePointStyle:true,
          titleFont:{family:'DM Mono',size:11,weight:'600'},bodyFont:{family:'DM Sans',size:12,weight:'600'},
          callbacks:{
            title:items=>items[0]?.label||'',
            label:ctx=>{
              const quote=ctx.dataset?._quote;
              if(quote&&ctx.dataset.label==='Price') {
                const i=ctx.dataIndex;
                return [
                  ` Open  ${fmtChartPrice(quote.open?.[i])}`,
                  ` High  ${fmtChartPrice(quote.high?.[i])}`,
                  ` Low   ${fmtChartPrice(quote.low?.[i])}`,
                  ` Close ${fmtChartPrice(quote.close?.[i])}`,
                ];
              }
              const v=ctx.raw;
              if(Array.isArray(v)) return ` ${ctx.dataset.label||'Range'}: ${fmtChartPrice(v[0])} – ${fmtChartPrice(v[1])}`;
              return ` ${ctx.dataset.label||''}: ${fmtChartPrice(v)}`;
            }
          }
        },
        zoom: {
          zoom: { wheel:{enabled:true,speed:0.045}, pinch:{enabled:true}, mode:isPriceChart?'x':'xy', onZoomComplete({chart}){_expandedHasUserZoom=!chartAtFullHistory(chart);} },
          pan:  { enabled:true, mode:isPriceChart?'x':'xy', threshold:0 },
          limits: isPriceChart?{x:{min:'original',max:'original',minRange:4}}:{x:{min:'original',max:'original',minRange:4},y:{min:'original',max:'original'}}
        }
      },
      scales: {
        ...(srcCfg.options?.scales||{}),
        x: {
          ...(srcCfg.options?.scales?.x||{}),
          ticks:{...(srcCfg.options?.scales?.x?.ticks||{}),color:theme.text,font:{family:'DM Mono',size:compact?9:11,weight:'500'},maxTicksLimit:compact?4:10,maxRotation:0,minRotation:0,autoSkip:true,padding:compact?8:10},
          grid:{color:gcol()}
        },
        y: {
          ...(srcCfg.options?.scales?.y||{}),
          ...(priceBounds||{}),
          beginAtZero:false,
          position:isPriceChart?'right':(srcCfg.options?.scales?.y?.position||'left'),
          title:{...(srcCfg.options?.scales?.y?.title||{}),display:false},
          ticks:{...(srcCfg.options?.scales?.y?.ticks||{}),color:theme.text,font:{family:'DM Mono',size:compact?9:11,weight:'500'},maxTicksLimit:compact?6:8,padding:compact?6:8,callback:isPriceChart?(value=>fmtChartAxisPrice(value)):(srcCfg.options?.scales?.y?.ticks?.callback)},
          grid:{color:gcol()}
        }
      }
    }
  });
  _expandedHasUserZoom=false;
  initMarkupCanvas();
  syncExpandedTypeToggle();
}
function cp() {
  const styles=getComputedStyle(document.documentElement);
  const get=(name,fallback)=>styles.getPropertyValue(name).trim()||fallback;
  return {
    price:get('--chart-price','#16C784'),
    positive:get('--chart-positive','#16C784'),
    negative:get('--chart-negative','#F45B5B'),
    ma50:get('--chart-ma50','#3B82F6'),
    ma200:get('--chart-ma200','#A78BFA'),
    bands:get('--chart-bands','#F5B83D'),
    neutral:get('--chart-neutral','#AAB2C0'),
  };
}
function colorAlpha(hex, alpha) {
  const raw=hex.replace('#','');
  const n=parseInt(raw.length===3?raw.split('').map(x=>x+x).join(''):raw,16);
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${alpha})`;
}

function resetExpandZoom(){
  if(_expandedChart) _expandedChart.resetZoom();
}
async function zoomExpandedChart(factor){
  const modal=document.getElementById('chart-expand-modal');
  const sourceId=modal?.dataset?.chartId||_expandedSource?.chartId;
  const sourceTitle=modal?.dataset?.chartTitle||_expandedSource?.title;
  if(factor<1&&sourceId==='price-chart'&&chartAtFullHistory(_expandedChart)){
    const loaded=await loadMorePriceHistory();
    if(loaded) expandChart(sourceId,sourceTitle||'Price Chart');
    return;
  }
  if(_expandedChart?.zoom) {
    _expandedChart.zoom(factor);
    _expandedHasUserZoom=!chartAtFullHistory(_expandedChart);
  }
}

function closeExpandModal(){
  document.getElementById('chart-expand-modal').classList.remove('open');
  document.body.style.overflow = '';
  if(_expandedChart){ _expandedChart.destroy(); _expandedChart = null; }
}

function setMarkupTool(tool){
  _markup.tool=tool;
  document.querySelectorAll('[data-markup-tool]').forEach(btn=>btn.classList.toggle('active',btn.dataset.markupTool===tool));
  const canvas=document.getElementById('chart-markup');
  if(canvas)canvas.classList.toggle('drawing',tool!=='cursor');
}
function setMarkupColor(color){
  _markup.color=color;
  document.querySelectorAll('[data-markup-color]').forEach(btn=>btn.classList.toggle('active',btn.dataset.markupColor===color));
}
function markupPoint(canvas,event){
  const r=canvas.getBoundingClientRect();
  return{x:Math.max(0,Math.min(1,(event.clientX-r.left)/r.width)),y:Math.max(0,Math.min(1,(event.clientY-r.top)/r.height))};
}
function resizeMarkupCanvas(){
  const canvas=document.getElementById('chart-markup');if(!canvas)return;
  const r=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;
  canvas.width=Math.max(1,Math.round(r.width*dpr));canvas.height=Math.max(1,Math.round(r.height*dpr));
  drawMarkup();
}
function drawMarkup(){
  const canvas=document.getElementById('chart-markup');if(!canvas)return;
  const ctx2=canvas.getContext('2d'),dpr=window.devicePixelRatio||1,w=canvas.width/dpr,h=canvas.height/dpr;
  ctx2.setTransform(dpr,0,0,dpr,0,0);ctx2.clearRect(0,0,w,h);ctx2.lineCap='round';ctx2.lineJoin='round';ctx2.shadowColor='rgba(0,0,0,.22)';ctx2.shadowBlur=3;ctx2.shadowOffsetY=1;
  [..._markup.items,...(_markup.draft?[_markup.draft]:[])].forEach(item=>{
    ctx2.strokeStyle=item.color;ctx2.lineWidth=item.type==='freehand'?2.5:3;ctx2.beginPath();
    if(item.type==='horizontal'){ctx2.moveTo(0,item.a.y*h);ctx2.lineTo(w,item.a.y*h);}
    else if(item.type==='line'){ctx2.moveTo(item.a.x*w,item.a.y*h);ctx2.lineTo(item.b.x*w,item.b.y*h);}
    else if(item.type==='freehand'&&item.points.length){ctx2.moveTo(item.points[0].x*w,item.points[0].y*h);item.points.slice(1).forEach(p=>ctx2.lineTo(p.x*w,p.y*h));}
    ctx2.stroke();
  });
}
function eraseMarkupAt(point){
  let best=-1,bestD=.055;
  _markup.items.forEach((item,i)=>{
    const pts=item.type==='freehand'?item.points:item.type==='horizontal'?[{x:point.x,y:item.a.y}]:[item.a,item.b];
    pts.forEach(p=>{const d=Math.hypot(p.x-point.x,p.y-point.y);if(d<bestD){bestD=d;best=i;}});
  });
  if(best>=0)_markup.items.splice(best,1);drawMarkup();
}
function initMarkupCanvas(){
  const canvas=document.getElementById('chart-markup');if(!canvas)return;
  resizeMarkupCanvas();
  if(_markup.ready)return;_markup.ready=true;
  _markup.observer=new ResizeObserver(resizeMarkupCanvas);_markup.observer.observe(canvas.parentElement);
  canvas.addEventListener('pointerdown',event=>{
    if(_markup.tool==='cursor')return;
    const p=markupPoint(canvas,event);canvas.setPointerCapture(event.pointerId);
    if(_markup.tool==='eraser'){eraseMarkupAt(p);return;}
    _markup.draft=_markup.tool==='freehand'?{type:'freehand',color:_markup.color,points:[p]}:{type:_markup.tool,color:_markup.color,a:p,b:p};
    drawMarkup();
  });
  canvas.addEventListener('pointermove',event=>{
    if(!_markup.draft)return;const p=markupPoint(canvas,event);
    if(_markup.draft.type==='freehand')_markup.draft.points.push(p);else _markup.draft.b=p;
    drawMarkup();
  });
  const finish=()=>{if(!_markup.draft)return;_markup.items.push(_markup.draft);_markup.draft=null;drawMarkup();};
  canvas.addEventListener('pointerup',finish);canvas.addEventListener('pointercancel',finish);
}
function undoMarkup(){_markup.items.pop();_markup.draft=null;drawMarkup();}
function clearMarkup(){_markup.items=[];_markup.draft=null;drawMarkup();}

document.addEventListener('keydown', e => { if(e.key==='Escape') closeExpandModal(); });

/* ══════════════════════════════════════════════════════
   QUICK LOAD / ANALYZE
══════════════════════════════════════════════════════ */
function quickLoad(t){ document.getElementById('main-ticker').value=t; fetchAndRender(); }

async function fetchAndRender() {
  const ticker=document.getElementById('main-ticker').value.trim().toUpperCase();
  if(!ticker){ toast('Enter a ticker symbol','red'); return; }
  const requestedDataSection = [...document.querySelectorAll('.app-section.open')]
    .map(section => section.id.replace(/^sec-/, ''))
    .find(Boolean) || 'analyze';
  const btn=document.getElementById('search-btn');
  btn.disabled=true; btn.innerHTML='<span style="display:inline-flex;gap:6px;align-items:center;"><span class="spinner"></span> Loading…</span>';
  document.getElementById('analyze-loading').style.display='flex';
  document.getElementById('analyze-error').style.display='none';
  document.getElementById('stock-result').style.display='none';
  track('analyze_started', { ticker });
  try {
    const result=await yahooFetch(ticker,S.range);
    S.ticker=ticker; S.data=result; S.analystTarget=null;
    renderStock(result,ticker);
    if(requestedDataSection !== 'analyze' && typeof window.navGoTo === 'function') {
      window.navGoTo(requestedDataSection);
    }
    ensureMALookback(ticker);
    track('analyze_completed', { ticker });
    toast(`${ticker} loaded ✓`,'green'); const _fg=document.getElementById('featured-grid'); if(_fg) _fg.style.display='none'; const _tw=document.getElementById('tool-welcome'); if(_tw) _tw.style.display='none'; const _fl=document.getElementById('fg-label'); if(_fl) _fl.style.display='none'; const _tx=document.getElementById('tw-extra'); if(_tx) _tx.style.display='none';
  } catch(e) {
    if (e.message === 'LIMIT_REACHED') {
      track('daily_limit_reached', { ticker });
      showUpgradeModal();
      const err=document.getElementById('analyze-error');
      err.innerHTML=`<span>You've used all <strong>${e.limitData?.limit||5} free analyses</strong> for today. <a href="#" onclick="showUpgradeModal();return false;" style="color:var(--gold);font-weight:600;">Upgrade to Pro</a> for unlimited access.</span>`;
      err.style.display='block';
    } else if (e.message === 'SIGNUP_REQUIRED') {
      startGuestSignup('guest_limit_reached');
    } else if (e.message === 'TICKER_NOT_FOUND') {
      const err=document.getElementById('analyze-error');
      err.textContent=`Could not find "${ticker}". Check the ticker symbol and try again—it may not exist or may not be supported.`;
      err.style.display='block';
    } else {
      const err=document.getElementById('analyze-error');
      err.textContent=`We could not load "${ticker}" right now. Please try again in a moment.`;
      err.style.display='block';
    }
  } finally {
    btn.disabled=false; btn.textContent='Analyze →';
    document.getElementById('analyze-loading').style.display='none';
  }
}

function renderStock(result, ticker) {
  const meta=result.meta;
  const provenance=result.impliedLensProvenance||null;
  const aligned=alignQuoteSeries(result);
  result=aligned.result;
  S.data=result;
  const ts=aligned.timestamps;
  const q=aligned.quote;
  const closes=aligned.closes; const opens=q.open||[]; const highs=q.high||[]; const lows=q.low||[]; const vols=q.volume||[];

  const price=meta.regularMarketPrice||closes[closes.length-1]||0;
  const finiteCloses=closes.filter(Number.isFinite);
  const previousBar=finiteCloses.length>1?finiteCloses[finiteCloses.length-2]:null;
  const interval=String(provenance?.interval||'');
  if(interval==='1d'&&previousBar>0) S.previousClose=previousBar;
  const intraday=/^[0-9]+(?:m|h)$/.test(interval);
  const prev=meta.previousClose||(intraday?meta.chartPreviousClose:null)||S.previousClose||previousBar||meta.chartPreviousClose||price;
  const chg=price-prev; const chgPct=(chg/prev)*100;

  document.getElementById('r-ticker').textContent=meta.symbol;
  document.getElementById('r-name').textContent=meta.longName||meta.shortName||ticker;
  document.getElementById('r-exchange').textContent=`${meta.exchangeName||''} · ${meta.currency||'USD'}`;
  document.getElementById('r-price').textContent=`$${price.toFixed(2)}`;
  const chgEl=document.getElementById('r-change');
  chgEl.textContent=`Today ${chg>=0?'+':''}${chg.toFixed(2)} (${fmtPct(chgPct)})`;
  chgEl.className='price-chg '+(chg>=0?'up':'dn');
  const providerAsOf = provenance?.asOf ? new Date(provenance.asOf) : null;
  document.getElementById('r-time').textContent=providerAsOf && !Number.isNaN(providerAsOf.getTime())
    ? `Provider observation · ${providerAsOf.toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'})}`
    : 'Provider observation time unavailable';
  showDataSource('quote-source', provenance, provenance?.source || 'Market data provider', provenance?.asOf);

  // metrics
  const c=closes;
  const rsiVals=rsi(c); const rsiNow=rsiVals[rsiVals.length-1];
  const ma50v=sma(c,50); const ma50Now=ma50v[ma50v.length-1];
  const ma200v=sma(c,200); const ma200Now=ma200v[ma200v.length-1];
  const returns=c.map((v,i)=>i===0?0:(v-c[i-1])/c[i-1]*100);
  const stdDev=ImpliedLensMath.annualizedVolatility(c,252)*100;
  const h52=meta.fiftyTwoWeekHigh; const l52=meta.fiftyTwoWeekLow;

  const metrics=[
    {l:'52W High',v:h52?`$${h52.toFixed(2)}`:'—',s:h52?fmtPct((price-h52)/h52*100)+' from high':'',c:h52?(price/h52<0.8?'dn':''):''},
    {l:'52W Low',v:l52?`$${l52.toFixed(2)}`:'—',s:l52?fmtPct((price-l52)/l52*100)+' from low':'',c:''},
    {l:'Market Cap',v:fmtBig(meta.marketCap),s:'',c:''},
    {l:'Volume',v:meta.regularMarketVolume!=null?`${fmtShares(meta.regularMarketVolume)} sh`:'—',s:meta.averageDailyVolume3Month?`${(meta.regularMarketVolume/meta.averageDailyVolume3Month).toFixed(2)}x avg`:'',c:''},
    {l:'RSI (14)',v:rsiNow?rsiNow.toFixed(1):'—',s:rsiNow?(rsiNow<30?'Oversold':rsiNow>70?'Overbought':'Neutral'):'',c:rsiNow?(rsiNow<30?'up':rsiNow>70?'dn':''):''},
    {l:'MA 50',v:ma50Now?`$${ma50Now.toFixed(2)}`:'—',s:ma50Now?(price>ma50Now?'Above (Bullish)':'Below (Bearish)'):'',c:ma50Now?(price>ma50Now?'up':'dn'):''},
    {l:'MA 200',v:ma200Now?`$${ma200Now.toFixed(2)}`:'—',s:ma200Now?(price>ma200Now?'Above (Bullish)':'Below (Bearish)'):'',c:ma200Now?(price>ma200Now?'up':'dn'):''},
    {l:'Volatility',v:`${stdDev.toFixed(1)}%`,s:'Annualized',c:stdDev>40?'dn':stdDev<20?'up':''},
  ];
  const METRIC_TIPS={
    '52W High':'The highest price this stock reached in the past 52 weeks.',
    '52W Low':'The lowest price this stock reached in the past 52 weeks.',
    'Market Cap':'Total market value of all outstanding shares.',
    'Volume':'Number of shares traded today vs 3-month average.',
    'RSI (14)':'Relative Strength Index. Below 30 = oversold, above 70 = overbought.',
    'MA 50':'50-day moving average. Price above it is generally bullish.',
    'MA 200':'200-day moving average. Price above it signals long-term uptrend.',
    'Volatility':'Annualized standard deviation of daily returns. Higher = more risk.',
  };
  document.getElementById('metrics-grid').innerHTML=metrics.map(m=>{
    const tip=METRIC_TIPS[m.l]||'';
    const tipHtml=tip?`<span class="tip-wrap"><span class="tip-icon">?</span><span class="tip-box">${tip}</span></span>`:'';
    return `<div class="metric-card"><div class="m-lbl">${m.l}${tipHtml}</div><div class="m-val ${m.c}">${m.v}</div>${m.s?`<div class="m-sub">${m.s}</div>`:''}</div>`;
  }).join('');

  // Sector benchmark comparison panel
  if (isPro()) (async () => {
    try {
      const profResp = await fetch('/api/analyst/'+encodeURIComponent(ticker), {credentials:'same-origin'});
      const profData = profResp.ok ? await profResp.json() : {};
      const sector = profData.sector || (S.estimates && S.estimates.sector) || null;
      const bm = getSectorBenchmark(sector);
      const benchEl = document.getElementById('metrics-bench');
      if (!bm || !benchEl) return;
      const peVal = meta.trailingPE || null;
      const pbVal = meta.priceToBook || null;
      const psVal = meta.priceToSalesTrailing12Months || null;
      const vsRow = (label, val, bmVal, higherBetter=false) => {
        if (!val || !bmVal) return '';
        const diff = ((val - bmVal) / bmVal * 100);
        const better = higherBetter ? diff > 0 : diff < 0;
        const color = Math.abs(diff) < 10 ? 'var(--text4)' : better ? 'var(--market-up)' : 'var(--market-down)';
        const arrow = diff > 5 ? '↑' : diff < -5 ? '↓' : '→';
        return `<div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--t-acc-border);">
          <span style="font-size:.72rem;color:var(--text4);">${label}</span>
          <span style="font-size:.72rem;">
            <span style="color:var(--text);font-weight:600;">${val.toFixed(1)}x</span>
            <span style="color:var(--text5);"> vs </span>
            <span style="color:var(--text5);">${bmVal}x</span>
            <span style="color:${color};margin-left:4px;">${arrow} ${Math.abs(diff).toFixed(0)}%</span>
          </span>
        </div>`;
      };
      benchEl.innerHTML = `
        <div style="margin-top:1rem;background:var(--t-metric-bg);border:1px solid var(--t-metric-border);border-radius:8px;padding:10px 14px;">
          <div style="font-size:.62rem;color:var(--gold);font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;">vs ${sector||'Sector'} Median</div>
          ${vsRow('P/E Ratio', peVal, bm.pe)}
          ${vsRow('P/B Ratio', pbVal, bm.pb)}
          ${vsRow('P/S Ratio', psVal, bm.ps)}
          <div style="font-size:.6rem;color:var(--text5);margin-top:6px;">↓ below sector = cheaper · ↑ above = premium</div>
        </div>`;
    } catch(_) {}
  })();

  const peNow=Math.round(meta.trailingPE||25);
  const quickCurrentPe=document.getElementById('proj-pe-now');
  const quickBasePe=document.getElementById('proj-pe-base');
  if(quickCurrentPe && !quickCurrentPe.dataset.userEdited) quickCurrentPe.value=peNow;
  if(quickBasePe && !quickBasePe.dataset.userEdited) quickBasePe.value=peNow;
  // Auto-fill advanced projection + DCF fields
  if(document.getElementById('dcf-price')) document.getElementById('dcf-price').value=price.toFixed(2);
  // Re-seed Projection Lab for the newly loaded ticker if its section is open.
  if(document.getElementById('sec-projection')?.classList.contains('open')) { try { mountProjectionLab(); } catch(e){} }
  if(document.getElementById('sec-dcf')?.classList.contains('open')) { try { mountValuationLab(); } catch(e){} }

  // Async: fetch analyst consensus estimates and auto-fill projection defaults
  if (isPro()) (async () => {
    try {
      const er = await fetch('/api/estimates/' + encodeURIComponent(ticker), { credentials:'same-origin' });
      if (!er.ok) return;
      const est = await er.json();

      // Use consensus as a starting point for Base only. Bear and Bull remain user-controlled.
      const growthEl = document.getElementById('proj-g-base');
      const projectionGrowth = est.epsGrowth !== null ? est.epsGrowth : est.revenueGrowth;
      if (projectionGrowth !== null && growthEl && !growthEl.dataset.userEdited) {
        const g = Math.max(-50, Math.min(200, projectionGrowth));
        growthEl.value = g.toFixed(1);
        growthEl.title = est.epsGrowth !== null ? 'Base case starting point from analyst consensus EPS growth' : 'Base case EPS proxy from analyst consensus revenue growth';
      }

      // Forward P/E -> use as the Base starting point only.
      const peEl = document.getElementById('proj-pe-base');
      if (est.forwardPE && est.forwardPE > 0 && est.forwardPE < 500 && peEl && !peEl.dataset.userEdited) {
        peEl.value = Math.round(est.forwardPE);
        peEl.title = 'Base case starting point from forward P/E estimate';
      }

      S.estimates = est;

      // ── DCF: auto-fill EPS + WACC + growth ──
      if (est.nextYearEPS) {
        ['dcf-eps','qdcf-eps'].forEach(id => {
          const el = document.getElementById(id);
          if (el) { el.value = est.nextYearEPS.toFixed(2); el.title = 'Forward EPS from analyst consensus'; }
        });
      }
      if (est.suggestedWACC) {
        ['dcf-wacc','qdcf-wacc'].forEach(id => {
          const el = document.getElementById(id);
          if (el) { el.value = est.suggestedWACC.toFixed(1); el.title = 'CAPM-based discount-rate proxy = 4.5% risk-free rate + Beta x 5.5% equity risk premium'; }
        });
      }
      if (est.epsGrowth !== null) {
        const g1 = Math.max(0, Math.min(100, est.epsGrowth));
        const g2 = Math.max(0, Math.min(50, g1 * 0.55));
        ['dcf-g1','qdcf-g1'].forEach(id => { const el=document.getElementById(id); if(el) el.value=g1.toFixed(1); });
        ['dcf-g2','qdcf-g2'].forEach(id => { const el=document.getElementById(id); if(el) el.value=g2.toFixed(1); });
      }

      // Advanced Projection: use consensus for Base only; never derive Bear or Bull from it.
      if (est.epsGrowth !== null || est.revenueGrowth !== null) {
        const baseG = est.epsGrowth !== null ? est.epsGrowth : est.revenueGrowth;
        const advBase = document.getElementById('adv-g-base');
        if(advBase && !advBase.dataset.userEdited) advBase.value = baseG.toFixed(1);
      }
      if (est.forwardPE) {
        const peBase = document.getElementById('adv-pe-base');
        const fpe = Math.round(est.forwardPE);
        if(peBase && !peBase.dataset.userEdited) peBase.value = fpe;
      }

      // ── Badge ──
      const badge = document.getElementById('proj-est-badge');
      if (!badge) {
        const btn = document.querySelector('button[onclick="runProjection()"]');
        if (btn && btn.parentNode) {
          const b = document.createElement('div');
          b.id = 'proj-est-badge';
          b.style.cssText = 'font-size:.63rem;color:var(--gold);font-family:var(--mono);margin-bottom:.5rem;letter-spacing:.04em;';
          b.textContent = '\u2736 Base case seeded from analyst consensus; Bear and Bull stay custom';
          btn.parentNode.insertBefore(b, btn);
        }
      }
    } catch(_) {}
  })();

  // Chart.js must measure a visible container; reveal results before creating canvases.
  document.getElementById('stock-result').style.display='block';
  buildPriceChart(aligned.result,c,ts);
  buildRSIChart(rsiVals,ts);
  buildMACDChart(c,ts);
  buildVolChart(vols,ts,c);
  buildDistChart(returns);
  buildOBVChart(c,vols,ts);
  buildATRChart(highs,lows,c,ts);
  S.meta = meta;
  updateNavTickerBar();
  updateStatsFooter();
  updateSectionHeader('analyze');
  renderRiskPanel(c,meta);
  renderNews(ticker,meta.longName||ticker);
  if (isPro()) loadAnalyst(ticker);

  document.getElementById('proj-results').style.display='none';
  renderSavedAnalyses();
}


/* =====================================================
   FEATURED STOCKS GRID
===================================================== */

// ── Sector benchmark data (industry medians) ──
const SECTOR_BENCHMARKS = {
  'Technology':        { pe:28, pb:6.5, ps:5.5, roe:22, grossMargin:55, debtEq:0.6 },
  'Healthcare':        { pe:22, pb:4.2, ps:3.8, roe:16, grossMargin:58, debtEq:0.8 },
  'Financial Services':{ pe:13, pb:1.4, ps:2.2, roe:12, grossMargin:65, debtEq:2.1 },
  'Consumer Cyclical': { pe:20, pb:3.8, ps:1.2, roe:18, grossMargin:38, debtEq:1.1 },
  'Consumer Defensive':{ pe:22, pb:4.5, ps:1.8, roe:20, grossMargin:42, debtEq:0.9 },
  'Industrials':       { pe:20, pb:3.2, ps:1.6, roe:15, grossMargin:35, debtEq:1.0 },
  'Energy':            { pe:12, pb:1.8, ps:1.2, roe:14, grossMargin:45, debtEq:0.6 },
  'Utilities':         { pe:18, pb:1.6, ps:2.0, roe:10, grossMargin:40, debtEq:1.4 },
  'Real Estate':       { pe:35, pb:2.0, ps:5.5, roe: 8, grossMargin:62, debtEq:1.5 },
  'Communication':     { pe:18, pb:2.8, ps:2.2, roe:15, grossMargin:50, debtEq:0.9 },
  'Basic Materials':   { pe:15, pb:2.2, ps:1.4, roe:12, grossMargin:30, debtEq:0.7 },
};
function getSectorBenchmark(sector) {
  if (!sector) return null;
  const key = Object.keys(SECTOR_BENCHMARKS).find(k => sector.toLowerCase().includes(k.toLowerCase()));
  return key ? SECTOR_BENCHMARKS[key] : null;
}

/* ══ HOME DASHBOARD JS v3 ══ */
let _moversCache={},_moversActive='gainers',_marketOverviewChart=null,_globeRAF=null;

function heroSearch(){const v=(document.getElementById('hero-search')||{}).value;if(!v||!v.trim())return;const mi=document.getElementById('main-ticker');if(mi)mi.value=v.trim().toUpperCase();navGoTo('analyze');if(typeof fetchAndRender==='function')fetchAndRender();}
function heroLoadTicker(t){const mi=document.getElementById('main-ticker');if(mi)mi.value=t;navGoTo('analyze');if(typeof fetchAndRender==='function')fetchAndRender();}
// Load a ticker from within a lab (Projection/Valuation) empty state WITHOUT leaving the current section.
// fetchAndRender re-mounts whichever lab section is open once data arrives.
function loadTickerInLab(inputId){
  const el=document.getElementById(inputId); if(!el)return;
  const t=(el.value||'').trim().toUpperCase();
  if(!t){ if(typeof toast==='function')toast('Enter a ticker symbol','red'); el.focus(); return; }
  const mi=document.getElementById('main-ticker'); if(mi)mi.value=t;
  if(typeof fetchAndRender==='function') fetchAndRender();
}
window.loadTickerInLab=loadTickerInLab;
function landingSearch(){const v=(document.getElementById('landing-search')||{}).value;if(!v||!v.trim())return;heroLoadTicker(v.trim().toUpperCase());}
(function(){const hi=document.getElementById('hero-search');if(hi)hi.addEventListener('keydown',e=>{if(e.key==='Enter')heroSearch();});})();
window._pricingAnnual=false;
function setPricingPeriod(period){
  const annual=period==='annual';window._pricingAnnual=annual;
  document.getElementById('pricing-period-monthly')?.classList.toggle('active',!annual);
  document.getElementById('pricing-period-annual')?.classList.toggle('active',annual);
  const amount=document.getElementById('pricing-pro-amount'),per=document.getElementById('pricing-pro-period'),note=document.getElementById('pricing-pro-note');
  const btn=document.getElementById('pricing-pro-btn');
  if(amount)amount.textContent=annual?'59.99':'7.99';
  if(per)per.textContent=annual?'/year':'/month';
  if(note)note.textContent=annual?'Equivalent to about $5/month. Save 37% versus monthly billing. Discount codes can be entered in Checkout.':'Start with a 7-day free trial. Have a discount code? Enter it in Stripe Checkout for offers like a $0.99 paid month.';
  if(btn)btn.textContent=annual?'Start annual Pro \u2192':'Start 7-day free trial \u2192';
}

async function initGlobe(){
  const canvas=document.getElementById('globe-canvas');
  if(!canvas)return;

  const W=480,H=340;
  canvas.width=W*2;canvas.height=H*2;
  canvas.style.width=W+'px';canvas.style.height=H+'px';
  const ctx=canvas.getContext('2d');
  ctx.scale(2,2);

  const GCX=200,GCY=162,GR=148;

  let land,graticule;
  try {
    const world=await fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json').then(r=>r.json());
    land=topojson.feature(world,world.objects.land);
    graticule=d3.geoGraticule().step([30,30])();
  } catch(e){ console.warn('Globe load failed',e); return; }

  const projection=d3.geoOrthographic()
    .scale(GR)
    .translate([GCX,GCY])
    .clipAngle(90)
    .rotate([0,-20,0]);
  const geoPath=d3.geoPath(projection,ctx);
  let yaw=0;

  function drawHandle(){
    const ang=Math.PI*0.25;
    const sx=GCX+(GR+20)*Math.cos(ang), sy=GCY+(GR+20)*Math.sin(ang);
    const ex=sx+125*Math.cos(ang),      ey=sy+125*Math.sin(ang);
    const px=-Math.sin(ang), py=Math.cos(ang);
    const HW=13;
    ctx.save();
    ctx.shadowColor='rgba(0,0,0,.7)';ctx.shadowBlur=20;ctx.shadowOffsetX=5;ctx.shadowOffsetY=6;
    ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(ex,ey);
    ctx.strokeStyle='rgba(20,8,2,.95)';ctx.lineWidth=HW*2+6;ctx.lineCap='round';ctx.stroke();
    ctx.restore();
    const f1x=sx,f1y=sy,f2x=sx+Math.cos(ang)*20,f2y=sy+Math.sin(ang)*20;
    const fg=ctx.createLinearGradient(f1x+px*HW,f1y+py*HW,f1x-px*HW,f1y-py*HW);
    fg.addColorStop(0,'#7A5010');fg.addColorStop(0.3,'#E8B030');
    fg.addColorStop(0.55,'#F5CC50');fg.addColorStop(0.75,'#C09020');fg.addColorStop(1,'#5F461C');
    ctx.beginPath();
    ctx.moveTo(f1x+px*HW,f1y+py*HW);ctx.lineTo(f2x+px*HW,f2y+py*HW);
    ctx.lineTo(f2x-px*HW,f2y-py*HW);ctx.lineTo(f1x-px*HW,f1y-py*HW);
    ctx.closePath();ctx.fillStyle=fg;ctx.fill();
    const bStart=20;
    const bsx=sx+Math.cos(ang)*bStart,bsy=sy+Math.sin(ang)*bStart;
    const cg=ctx.createLinearGradient(bsx+px*HW,bsy+py*HW,bsx-px*HW,bsy-py*HW);
    cg.addColorStop(0,'#0E0502');cg.addColorStop(0.15,'#2E1208');
    cg.addColorStop(0.38,'#6B2E10');cg.addColorStop(0.52,'#8B3E18');
    cg.addColorStop(0.68,'#5A2810');cg.addColorStop(0.85,'#2E1208');
    cg.addColorStop(1,'#0E0502');
    ctx.beginPath();
    ctx.moveTo(bsx+px*HW,bsy+py*HW);ctx.lineTo(ex+px*(HW-3),ey+py*(HW-3));
    ctx.lineTo(ex-px*(HW-3),ey-py*(HW-3));ctx.lineTo(bsx-px*HW,bsy-py*HW);
    ctx.closePath();ctx.fillStyle=cg;ctx.fill();
    const tipG=ctx.createRadialGradient(ex-px*3,ey-py*3,0,ex,ey,HW+1);
    tipG.addColorStop(0,'#7A3818');tipG.addColorStop(1,'#0E0502');
    ctx.beginPath();ctx.arc(ex,ey,HW-2,0,Math.PI*2);ctx.fillStyle=tipG;ctx.fill();
    ctx.beginPath();
    ctx.moveTo(bsx+px*(HW*.6),bsy+py*(HW*.6));ctx.lineTo(ex+px*(HW*.5),ey+py*(HW*.5));
    ctx.strokeStyle='rgba(160,80,35,.3)';ctx.lineWidth=3;ctx.lineCap='round';ctx.stroke();
    for(let g=0;g<6;g++){
      const t=0.1+g*0.14;
      const gx=bsx+(ex-bsx)*t,gy=bsy+(ey-bsy)*t;
      ctx.beginPath();
      ctx.moveTo(gx+px*(HW*.85),gy+py*(HW*.85));ctx.lineTo(gx-px*(HW*.85),gy-py*(HW*.85));
      ctx.strokeStyle='rgba(0,0,0,.14)';ctx.lineWidth=0.7;ctx.stroke();
    }
  }

  function drawRing(){
    const RW=20,R2=GR+RW*.5;
    ctx.save();
    ctx.shadowColor='rgba(0,0,0,.75)';ctx.shadowBlur=28;ctx.shadowOffsetX=4;ctx.shadowOffsetY=8;
    ctx.beginPath();ctx.arc(GCX,GCY,R2,0,Math.PI*2);
    ctx.strokeStyle='rgba(0,0,0,.01)';ctx.lineWidth=RW+6;ctx.stroke();
    ctx.restore();
    ctx.beginPath();ctx.arc(GCX,GCY,R2,0,Math.PI*2);
    ctx.strokeStyle='#2A1A04';ctx.lineWidth=RW+4;ctx.stroke();
    const rg=ctx.createLinearGradient(GCX-GR-RW,GCY-GR-RW,GCX+GR+RW,GCY+GR+RW);
    rg.addColorStop(0,'#F8D060');rg.addColorStop(0.18,'#EFC040');
    rg.addColorStop(0.38,'#D4A020');rg.addColorStop(0.58,'#9A7018');
    rg.addColorStop(0.78,'#6A4C10');rg.addColorStop(1,'#3A2808');
    ctx.beginPath();ctx.arc(GCX,GCY,R2,0,Math.PI*2);
    ctx.strokeStyle=rg;ctx.lineWidth=RW;ctx.stroke();
    ctx.save();
    ctx.beginPath();ctx.arc(GCX,GCY,R2,Math.PI*1.05,Math.PI*1.9);
    ctx.strokeStyle='rgba(255,240,150,.65)';ctx.lineWidth=RW*.28;ctx.lineCap='butt';ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.beginPath();ctx.arc(GCX,GCY,R2,Math.PI*1.35,Math.PI*1.65);
    ctx.strokeStyle='rgba(255,255,200,.35)';ctx.lineWidth=RW*.15;ctx.lineCap='butt';ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.beginPath();ctx.arc(GCX,GCY,R2,Math.PI*0.05,Math.PI*0.95);
    ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=RW*.35;ctx.lineCap='butt';ctx.stroke();
    ctx.restore();
    ctx.beginPath();ctx.arc(GCX,GCY,GR+2,0,Math.PI*2);
    ctx.strokeStyle='rgba(255,210,80,.2)';ctx.lineWidth=1.5;ctx.stroke();
    ctx.beginPath();ctx.arc(GCX,GCY,GR+RW+2,0,Math.PI*2);
    ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=2;ctx.stroke();
  }

  function drawGlobe(){
    ctx.save();
    ctx.beginPath();ctx.arc(GCX,GCY,GR,0,Math.PI*2);ctx.clip();
    const bg=ctx.createRadialGradient(GCX-GR*.22,GCY-GR*.26,GR*.04,GCX,GCY,GR);
    bg.addColorStop(0,'#201808');bg.addColorStop(0.45,'#0e0b04');bg.addColorStop(1,'#050402');
    ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
    projection.rotate([yaw,-20,0]);
    ctx.beginPath();geoPath(graticule);
    ctx.strokeStyle='rgba(185,138,61,.12)';ctx.lineWidth=0.5;ctx.stroke();
    ctx.beginPath();geoPath(land);
    const lg=ctx.createRadialGradient(GCX-GR*.15,GCY-GR*.15,0,GCX,GCY,GR);
    lg.addColorStop(0,'rgba(210,145,40,.88)');
    lg.addColorStop(0.5,'rgba(185,120,28,.80)');
    lg.addColorStop(1,'rgba(140,90,18,.70)');
    ctx.fillStyle=lg;ctx.fill();
    ctx.strokeStyle='rgba(240,175,55,.38)';ctx.lineWidth=0.45;ctx.stroke();
    const rim=ctx.createRadialGradient(GCX,GCY,GR*.82,GCX,GCY,GR);
    rim.addColorStop(0,'rgba(185,138,61,0)');
    rim.addColorStop(.6,'rgba(185,138,61,.06)');
    rim.addColorStop(1,'rgba(185,138,61,.28)');
    ctx.fillStyle=rim;ctx.beginPath();ctx.arc(GCX,GCY,GR,0,Math.PI*2);ctx.fill();
    const spec=ctx.createRadialGradient(GCX-GR*.42,GCY-GR*.44,0,GCX-GR*.2,GCY-GR*.24,GR*.65);
    spec.addColorStop(0,'rgba(255,235,150,.12)');spec.addColorStop(1,'rgba(255,235,150,0)');
    ctx.fillStyle=spec;ctx.beginPath();ctx.arc(GCX,GCY,GR,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }

  function drawCandles(){
    const candleData=[
      {h:58,o:20,c:44,lo:8,up:true},
      {h:40,o:32,c:16,lo:7,up:false},
      {h:72,o:44,c:64,lo:30,up:true},
      {h:48,o:22,c:40,lo:10,up:true},
      {h:90,o:60,c:82,lo:46,up:true},
      {h:35,o:28,c:12,lo:5,up:false},
    ];
    const bX=GCX+GR+38,bY=GCY+GR*.55;
    candleData.forEach((b,i)=>{
      const x=bX+i*15;
      const col=b.up?'rgba(74,222,128,.9)':'rgba(248,113,113,.9)';
      ctx.beginPath();ctx.moveTo(x+5,bY-b.h);ctx.lineTo(x+5,bY-b.lo);
      ctx.strokeStyle=col;ctx.lineWidth=1.5;ctx.stroke();
      const bt=bY-Math.max(b.o,b.c),bh=Math.max(2,Math.abs(b.c-b.o));
      ctx.fillStyle=col;
      ctx.beginPath();ctx.roundRect(x,bt,9,bh,1.5);ctx.fill();
    });
  }

  function frame(){
    ctx.clearRect(0,0,W,H);
    drawHandle();
    drawGlobe();
    drawRing();
    drawCandles();
    yaw+=0.13;
    _globeRAF=requestAnimationFrame(frame);
  }
  frame();
}

async function initModernGlobe(){
  const canvas=document.getElementById('globe-canvas');if(!canvas)return;
  if(window.matchMedia?.('(max-width:900px)').matches)return;
  if(_globeRAF){cancelAnimationFrame(_globeRAF);_globeRAF=null;}
  const W=480,H=310,dpr=Math.min(window.devicePixelRatio||1,2);
  canvas.width=W*dpr;canvas.height=H*dpr;canvas.style.width=W+'px';canvas.style.height=H+'px';
  const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);
  const cx=205,cy=142,r=108,handleAngle=.54;
  let land,borders,graticule;
  const ensureScript=(src,ready)=>ready()?Promise.resolve():new Promise((resolve,reject)=>{
    const script=document.createElement('script');
    script.src=src;script.async=true;script.onload=resolve;script.onerror=reject;
    document.head.appendChild(script);
  });
  try{
    const [world]=await Promise.all([
      fetch('/vendor/countries-110m.json?v=2').then(res=>res.json()),
      ensureScript('/vendor/d3.min.js?v=7',()=>typeof window.d3!=='undefined'),
      ensureScript('/vendor/topojson-client.min.js?v=3',()=>typeof window.topojson!=='undefined')
    ]);
    land=topojson.feature(world,world.objects.land);
    borders=topojson.mesh(world,world.objects.countries,(a,b)=>a!==b);
    graticule=d3.geoGraticule().step([15,15])();
  }catch(_){return}
  const projection=d3.geoOrthographic().scale(r).translate([cx,cy]).clipAngle(90);
  const geoPath=d3.geoPath(projection,ctx);
  const hubs=[[-74,40.7],[0,51.5],[103.8,1.35],[139.7,35.7],[-122.4,37.8],[151.2,-33.8],[72.8,19.1]];
  const routes=[[-74,40.7,0,51.5],[0,51.5,103.8,1.35],[103.8,1.35,139.7,35.7],[-122.4,37.8,139.7,35.7],[-74,40.7,72.8,19.1]].map(route=>{
    const interpolate=d3.geoInterpolate([route[0],route[1]],[route[2],route[3]]);
    return {type:'LineString',coordinates:Array.from({length:28},(_,i)=>interpolate(i/27))};
  });
  let yaw=20,frameNo=0,lastFrame=performance.now(),isVisible=true;
  const reduceMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  function palette(){
    return isDark()?{
      ocean0:'#28434a',ocean1:'#142c34',ocean2:'#09191f',
      grid:'rgba(215,184,119,.12)',land0:'#d0aa61',land1:'#80602d',coast:'rgba(247,218,157,.68)',border:'rgba(244,222,178,.2)',
      atmosphere:'rgba(198,160,82,.35)',shade:'rgba(1,7,10,.55)',route:'rgba(230,194,122,.24)',
      frameDeep:'#674615',frameMid:'#b88432',frameBright:'#f0d38c',frameEdge:'#38250b',
      wood0:'#080a0b',wood1:'#292d2d',wood2:'#111516',reflection:'rgba(255,248,220,.15)'
    }:{
      ocean0:'#3d565a',ocean1:'#263e43',ocean2:'#162b30',
      grid:'rgba(235,211,161,.12)',land0:'#ddc181',land1:'#a27b3d',coast:'rgba(255,232,180,.62)',border:'rgba(73,55,29,.24)',
      atmosphere:'rgba(160,119,48,.3)',shade:'rgba(7,19,23,.5)',route:'rgba(246,211,142,.22)',
      frameDeep:'#72501a',frameMid:'#b98736',frameBright:'#f2d58d',frameEdge:'#4a310d',
      wood0:'#090b0c',wood1:'#303434',wood2:'#111516',reflection:'rgba(255,250,225,.17)'
    };
  }
  function metalGradient(p,x0,y0,x1,y1){
    const gradient=ctx.createLinearGradient(x0,y0,x1,y1);
    gradient.addColorStop(0,p.frameEdge);gradient.addColorStop(.18,p.frameMid);
    gradient.addColorStop(.42,p.frameBright);gradient.addColorStop(.58,p.frameMid);
    gradient.addColorStop(.82,p.frameDeep);gradient.addColorStop(1,p.frameEdge);
    return gradient;
  }
  function drawHandle(p){
    const sx=cx+(r+5)*Math.cos(handleAngle),sy=cy+(r+5)*Math.sin(handleAngle);
    const collarLength=34,woodLength=116,woodWidth=24;
    ctx.save();
    ctx.translate(sx,sy);ctx.rotate(handleAngle);
    ctx.shadowColor=isDark()?'rgba(0,0,0,.24)':'rgba(29,24,15,.16)';
    ctx.shadowBlur=7;ctx.shadowOffsetY=3;
    const wood=ctx.createLinearGradient(0,-woodWidth/2,0,woodWidth/2);
    wood.addColorStop(0,p.wood0);wood.addColorStop(.24,p.wood1);wood.addColorStop(.52,p.wood2);wood.addColorStop(.78,p.wood1);wood.addColorStop(1,p.wood0);
    ctx.beginPath();ctx.roundRect(collarLength-2,-woodWidth/2,woodLength,woodWidth,woodWidth/2);
    ctx.fillStyle=wood;ctx.fill();
    ctx.shadowColor='transparent';
    for(let i=0;i<8;i++){
      const y=-8+i*2.1;
      ctx.beginPath();ctx.moveTo(collarLength+9,y);ctx.bezierCurveTo(collarLength+42,y+1.5,collarLength+76,y-1.4,collarLength+woodLength-13,y+.6);
      ctx.strokeStyle=i%2?'rgba(255,255,255,.032)':'rgba(0,0,0,.16)';ctx.lineWidth=.7;ctx.stroke();
    }
    const capX=collarLength+woodLength-10;
    ctx.beginPath();ctx.roundRect(capX,-woodWidth*.57,18,woodWidth*1.14,8);
    ctx.fillStyle=metalGradient(p,capX,-woodWidth*.6,capX+18,woodWidth*.6);ctx.fill();
    ctx.strokeStyle='rgba(34,23,8,.48)';ctx.lineWidth=1;ctx.stroke();
    ctx.beginPath();ctx.roundRect(-4,-15,collarLength+11,30,9);
    ctx.fillStyle=metalGradient(p,-4,-15,collarLength+7,15);ctx.fill();
    ctx.strokeStyle=p.frameEdge;ctx.lineWidth=1.2;ctx.stroke();
    ctx.beginPath();ctx.moveTo(collarLength-1,-11);ctx.lineTo(collarLength-1,11);
    ctx.strokeStyle='rgba(255,235,178,.55)';ctx.lineWidth=1.2;ctx.stroke();
    ctx.restore();
  }
  function drawFrame(p){
    ctx.save();
    ctx.beginPath();ctx.arc(cx,cy,r+7,0,Math.PI*2);
    ctx.strokeStyle=isDark()?'rgba(0,0,0,.28)':'rgba(54,40,16,.16)';
    ctx.shadowColor=isDark()?'rgba(0,0,0,.25)':'rgba(44,33,15,.14)';
    ctx.shadowBlur=8;ctx.shadowOffsetY=3;ctx.lineWidth=22;ctx.stroke();
    ctx.shadowColor='transparent';
    ctx.beginPath();ctx.arc(cx,cy,r+6,0,Math.PI*2);
    ctx.strokeStyle=p.frameEdge;ctx.lineWidth=20;ctx.stroke();
    let ring;
    if(ctx.createConicGradient){
      ring=ctx.createConicGradient(-1.15,cx,cy);
      ring.addColorStop(0,p.frameDeep);ring.addColorStop(.12,p.frameBright);ring.addColorStop(.27,p.frameMid);
      ring.addColorStop(.46,p.frameEdge);ring.addColorStop(.61,p.frameMid);ring.addColorStop(.77,p.frameBright);ring.addColorStop(1,p.frameDeep);
    }else ring=metalGradient(p,cx-r,cy-r,cx+r,cy+r);
    ctx.beginPath();ctx.arc(cx,cy,r+6,0,Math.PI*2);ctx.strokeStyle=ring;ctx.lineWidth=16;ctx.stroke();
    ctx.beginPath();ctx.arc(cx,cy,r-1,0,Math.PI*2);ctx.strokeStyle='rgba(255,235,177,.62)';ctx.lineWidth=2.2;ctx.stroke();
    ctx.beginPath();ctx.arc(cx,cy,r+15,0,Math.PI*2);ctx.strokeStyle='rgba(48,32,8,.5)';ctx.lineWidth=1.2;ctx.stroke();
    ctx.beginPath();ctx.arc(cx,cy,r+7,Math.PI*1.08,Math.PI*1.64);ctx.strokeStyle='rgba(255,244,200,.72)';ctx.lineWidth=2.3;ctx.lineCap='round';ctx.stroke();
    ctx.restore();
  }
  function drawGlobe(p){
    projection.rotate([yaw,-18,0]);
    ctx.save();ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.clip();
    const ocean=ctx.createRadialGradient(cx-r*.34,cy-r*.4,3,cx,cy,r);
    ocean.addColorStop(0,p.ocean0);ocean.addColorStop(.58,p.ocean1);ocean.addColorStop(1,p.ocean2);
    ctx.fillStyle=ocean;ctx.fillRect(cx-r,cy-r,r*2,r*2);
    ctx.beginPath();geoPath(graticule);ctx.strokeStyle=p.grid;ctx.lineWidth=.45;ctx.stroke();
    const landFill=ctx.createLinearGradient(cx-r*.6,cy-r*.7,cx+r*.65,cy+r*.7);
    landFill.addColorStop(0,p.land0);landFill.addColorStop(1,p.land1);
    ctx.beginPath();geoPath(land);ctx.fillStyle=landFill;ctx.fill();ctx.strokeStyle=p.coast;ctx.lineWidth=.62;ctx.stroke();
    ctx.beginPath();geoPath(borders);ctx.strokeStyle=p.border;ctx.lineWidth=.32;ctx.stroke();
    routes.forEach(route=>{ctx.beginPath();geoPath(route);ctx.strokeStyle=p.route;ctx.lineWidth=.7;ctx.stroke();});
    hubs.forEach((hub,i)=>{
      const point=projection(hub);if(!point||d3.geoDistance(hub,projection.invert([cx,cy]))>=Math.PI/2)return;
      const pulse=2.4+Math.sin(frameNo*.035+i)*.7;
      ctx.beginPath();ctx.arc(point[0],point[1],pulse*2.1,0,Math.PI*2);ctx.fillStyle='rgba(198,160,82,.08)';ctx.fill();
      ctx.beginPath();ctx.arc(point[0],point[1],1.8,0,Math.PI*2);ctx.fillStyle=i%3===0?'#769985':'#d0aa61';ctx.fill();
    });
    const limb=ctx.createRadialGradient(cx-r*.3,cy-r*.34,r*.18,cx,cy,r);
    limb.addColorStop(.55,'rgba(0,0,0,0)');limb.addColorStop(.86,'rgba(0,0,0,.08)');limb.addColorStop(1,p.shade);
    ctx.fillStyle=limb;ctx.fillRect(cx-r,cy-r,r*2,r*2);
    const glass=ctx.createLinearGradient(cx-r*.7,cy-r*.78,cx+r*.12,cy+r*.18);
    glass.addColorStop(0,p.reflection);glass.addColorStop(.3,'rgba(255,255,255,.045)');glass.addColorStop(.58,'rgba(255,255,255,0)');
    ctx.fillStyle=glass;ctx.beginPath();ctx.ellipse(cx-r*.28,cy-r*.38,r*.5,r*.17,-.63,0,Math.PI*2);ctx.fill();
    ctx.restore();
    ctx.beginPath();ctx.arc(cx,cy,r-.5,0,Math.PI*2);ctx.strokeStyle=p.atmosphere;ctx.lineWidth=2;ctx.stroke();
  }
  function draw(now=performance.now()){
    _globeRAF=null;
    if(!isVisible||document.hidden||!canvas.isConnected)return;
    if(!reduceMotion&&now-lastFrame<30){_globeRAF=requestAnimationFrame(draw);return;}
    const p=palette();
    ctx.clearRect(0,0,W,H);
    drawHandle(p);
    drawGlobe(p);
    drawFrame(p);
    const elapsed=Math.min(80,Math.max(0,now-lastFrame));
    lastFrame=now;
    if(!reduceMotion)yaw+=elapsed*.0075;
    frameNo++;
    if(!reduceMotion)_globeRAF=requestAnimationFrame(draw);
  }
  const start=()=>{if(!_globeRAF&&isVisible&&!document.hidden&&!reduceMotion){lastFrame=performance.now();_globeRAF=requestAnimationFrame(draw)}};
  if('IntersectionObserver'in window){
    new IntersectionObserver(entries=>{
      isVisible=!!entries[0]?.isIntersecting;
      if(isVisible)start();
      else if(_globeRAF){cancelAnimationFrame(_globeRAF);_globeRAF=null;}
    },{threshold:.05}).observe(canvas);
  }
  document.addEventListener('visibilitychange',start,{passive:true});
  draw();
}

function buildSparklineSVG(data,up){if(!data||data.length<2)return'';const w=100,h=22,min=Math.min(...data),max=Math.max(...data),rng=max-min||1;const pts=data.map((v,i)=>`${((i/(data.length-1))*w).toFixed(1)},${(h-((v-min)/rng)*h).toFixed(1)}`).join(' ');const palette=cp();const col=up?palette.positive:palette.negative;return`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" style="width:100%;height:100%;display:block;"><polyline points="${pts}" fill="none" stroke="${col}" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/></svg>`;}

async function loadHomeTickerStrip(){
  const el=document.getElementById('home-ticker-strip');if(!el)return;
  const TICKERS=['AAPL','NVDA','MSFT','TSLA','AMZN','META','GOOGL','SPY'];
  const LOGOS={AAPL:'https://www.google.com/s2/favicons?sz=64&domain=apple.com',NVDA:'https://www.google.com/s2/favicons?sz=64&domain=nvidia.com',MSFT:'https://www.google.com/s2/favicons?sz=64&domain=microsoft.com',TSLA:'https://www.google.com/s2/favicons?sz=64&domain=tesla.com',AMZN:'https://www.google.com/s2/favicons?sz=64&domain=amazon.com',META:'https://www.google.com/s2/favicons?sz=64&domain=meta.com',GOOGL:'https://www.google.com/s2/favicons?sz=64&domain=google.com',SPY:'https://www.google.com/s2/favicons?sz=64&domain=ssga.com'};
  el.innerHTML=TICKERS.map(t=>`<div class="ht-card" style="opacity:.3;"><div class="ht-sym">${t}</div></div>`).join('');
  const results=await Promise.allSettled(TICKERS.map(t=>fetch(`/api/quote/${t}?range=1d&preview=1`,{credentials:'same-origin'}).then(r=>r.ok?r.json():null).catch(()=>null)));
  const watchData=[];
  el.innerHTML=results.map((res,i)=>{
    const t=TICKERS[i],data=res.status==='fulfilled'?res.value:null,meta=data?.chart?.result?.[0]?.meta,closes=data?.chart?.result?.[0]?.indicators?.quote?.[0]?.close?.filter(x=>x!=null)||[];
    watchData.push({t,meta});
    if(!meta)return`<div class="ht-card" onclick="heroLoadTicker('${t}')"><div class="ht-top"><span class="ht-sym">${t}</span></div><div class="ht-price">—</div></div>`;
    const price=meta.regularMarketPrice??meta.chartPreviousClose,prev=meta.chartPreviousClose||price,chg=price-prev,pct=prev?(chg/prev*100):0,up=chg>=0;
    const logo=LOGOS[t]?`<img class="ht-logo" src="${LOGOS[t]}" onerror="this.style.display='none'" alt="">`:''
    return`<div class="ht-card" onclick="heroLoadTicker('${t}')"><div class="ht-top">${logo}<span class="ht-sym">${t}</span></div><div class="ht-price">$${price>=1000?price.toFixed(0):price.toFixed(2)}</div><div class="ht-chg ${up?'up':'dn'}">${up?'▲':'▼'} ${Math.abs(pct).toFixed(2)}%</div><div class="ht-spark">${buildSparklineSVG(closes,up)}</div></div>`;
  }).join('');
  loadAnalystSignals(TICKERS.slice(0,5));
  loadHomeWatchlist(watchData);
  // populate legacy featured-grid
  const fg=document.getElementById('featured-grid');
  if(fg)fg.innerHTML=results.map((res,i)=>{const t=TICKERS[i],data=res.status==='fulfilled'?res.value:null,meta=data?.chart?.result?.[0]?.meta;if(!meta)return`<div class="fstock-card" onclick="loadTicker('${t}')"><div class="fstock-sym">${t}</div><div class="fstock-price">—</div></div>`;const price=meta.regularMarketPrice??meta.chartPreviousClose,prev=meta.chartPreviousClose||price,chg=price-prev,pct=prev?(chg/prev*100):0,up=chg>=0;return`<div class="fstock-card" onclick="loadTicker('${t}')"><div class="fstock-sym">${t}</div><div class="fstock-price">$${price>=1000?price.toFixed(0):price.toFixed(2)}</div><div class="fstock-chg ${up?'up':'dn'}">${up?'▲':'▼'} ${Math.abs(pct).toFixed(2)}%</div></div>`;}).join('');
}

async function loadMarketOverview(range,btn){
  if(btn){document.querySelectorAll('.mo-tab').forEach(b=>b.classList.remove('on'));btn.classList.add('on');}
  const IDXS=[
    {t:'^GSPC', col:'#148BFF', vi:'ri-sp', vc:'ri-sp-c', label:'S&P 500'},
    {t:'^IXIC', col:'#00A85A', vi:'ri-nq', vc:'ri-nq-c', label:'Nasdaq Composite'},
    {t:'^DJI', col:'#8B5CF6', vi:'ri-dj', vc:'ri-dj-c', label:'Dow Jones'}
  ];
  // Map range to correct interval for intraday granularity
  const intervalMap={'1d':'5m','5d':'15m','1mo':'1d','3mo':'1d','ytd':'1d','1y':'1d','5y':'1wk'};
  const interval=intervalMap[range||'1d']||'1d';
  const results=await Promise.allSettled(IDXS.map(idx=>
    fetch(`/api/quote/${encodeURIComponent(idx.t)}?range=${range||'1d'}&interval=${interval}&preview=1`,{credentials:'same-origin'})
    .then(r=>r.ok?r.json():null).catch(()=>null)
  ));
  let labels=[];
  const canvas=document.getElementById('market-overview-chart');
  if(!canvas)return;
  canvas.style.height='200px';
  const datasets=results.map((res,i)=>{
    const idx=IDXS[i],result=res.value?.chart?.result?.[0],
          meta=result?.meta,
          closes=result?.indicators?.quote?.[0]?.close||[],
          ts=result?.timestamp||[];
    const first=meta?.chartPreviousClose||closes.find(x=>x!=null);
    const norm=closes.map(v=>v!=null&&first!=null?((v-first)/first*100):null);
    if(i===0)labels=ts.map(t2=>{
      const d=new Date(t2*1000);
      return(!range||range==='1d'||range==='5d')
        ?d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true})
        :d.toLocaleDateString('en-US',{month:'short',day:'numeric'});
    });
    if(meta){
      const price=meta.regularMarketPrice??meta.chartPreviousClose,
            prev=meta.chartPreviousClose||price,
            pct=prev?((price-prev)/prev*100):0,up=(price-prev)>=0;
      const vEl=document.getElementById(idx.vi),cEl=document.getElementById(idx.vc);
      if(vEl)vEl.textContent=price>=1000?price.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):price.toFixed(2);
      if(cEl){cEl.textContent=`${up?'▲':'▼'} ${Math.abs(pct).toFixed(2)}%`;cEl.className='mo-idx-chg '+(up?'up':'dn');}
    }
    return{
      label:idx.label, data:norm,
      borderColor:idx.col, borderWidth:2.2,
      pointRadius:0, pointHoverRadius:5,
      fill:false,
      tension:.3, spanGaps:true
    };
  });
  if(_marketOverviewChart){_marketOverviewChart.destroy();_marketOverviewChart=null;}
  // End-of-line pill labels plugin
  const endLabelPlugin={
    id:'moEndLabels',
    afterDraw(chart){
      const {ctx,chartArea}=chart;
      if(!chartArea)return;
      const colors=['#148BFF','#00A85A','#8B5CF6'];
      chart.data.datasets.forEach((ds,i)=>{
        const pts=ds.data.filter(x=>x!=null);
        if(!pts.length)return;
        const last=pts[pts.length-1];
        const meta2=chart.getDatasetMeta(i);
        const visiblePts=meta2.data.filter(p=>p&&!isNaN(p.x)&&!isNaN(p.y));
        if(!visiblePts.length)return;
        const lastPt=visiblePts[visiblePts.length-1];
        const txt=`${last>=0?'+':''}${last.toFixed(2)}%`;
        ctx.save();
        ctx.font='bold 10px ui-monospace,monospace';
        const tw=ctx.measureText(txt).width;
        const pw=tw+14,ph=17,px=chartArea.right+6,py=lastPt.y-ph/2;
        // pill background
        ctx.fillStyle=colors[i].replace(')',',0.2)').replace('rgb','rgba').replace('rgba(rgba','rgba');
        // simple rect fill (roundRect not reliable cross-browser in canvas)
        ctx.beginPath();
        const r=3;
        ctx.moveTo(px+r,py);ctx.lineTo(px+pw-r,py);
        ctx.arcTo(px+pw,py,px+pw,py+r,r);
        ctx.lineTo(px+pw,py+ph-r);
        ctx.arcTo(px+pw,py+ph,px+pw-r,py+ph,r);
        ctx.lineTo(px+r,py+ph);
        ctx.arcTo(px,py+ph,px,py+ph-r,r);
        ctx.lineTo(px,py+r);
        ctx.arcTo(px,py,px+r,py,r);
        ctx.closePath();
        ctx.fillStyle=colors[i].includes('#4a')?'rgba(74,159,212,.2)':
                      colors[i].includes('#D4')?'rgba(198,160,82,.2)':'rgba(167,139,250,.2)';
        ctx.fill();
        // text
        ctx.fillStyle=colors[i];
        ctx.textBaseline='middle';
        ctx.fillText(txt,px+7,lastPt.y);
        ctx.restore();
      });
    }
  };
  const t2=ct();
  _marketOverviewChart=new Chart(canvas,{
    type:'line',
    data:{labels,datasets},
    plugins:[endLabelPlugin],
    options:{
      responsive:true,
      maintainAspectRatio:false,
      animation:{duration:500},
      layout:{padding:{right:80,top:8,bottom:4}},
      interaction:{mode:'index',intersect:false},
      scales:{
        x:{
          ticks:{color:t2.text,font:{size:9},maxTicksLimit:8,maxRotation:0},
          grid:{color:t2.grid},
          border:{display:false}
        },
        y:{
          ticks:{color:t2.text,font:{size:9},callback:v=>`${v>=0?'+':''}${v.toFixed(1)}%`},
          grid:{color:t2.grid},
          border:{display:false}
        }
      },
      plugins:{
        legend:{display:false},
        tooltip:{
          backgroundColor:t2.ttBg,
          titleColor:t2.ttTitle,
          bodyColor:t2.ttBody,
          borderColor:t2.ttBorder,
          borderWidth:1,
          padding:10,
          callbacks:{label:c=>` ${c.dataset.label}: ${c.raw>=0?'+':''}${Number(c.raw||0).toFixed(2)}%`}
        }
      }
    }
  });
  fetchBreadth(results);
}

function fetchBreadth(results){
  try{
    const advEl=document.getElementById('mo-advancing'),decEl=document.getElementById('mo-declining');
    const advBar=document.getElementById('mo-adv-bar'),decBar=document.getElementById('mo-dec-bar');
    const advPctEl=document.getElementById('mo-adv-pct'),decPctEl=document.getElementById('mo-dec-pct');
    if(advEl)advEl.textContent='—';
    if(decEl)decEl.textContent='—';
    if(advBar)advBar.style.width='0%';
    if(decBar)decBar.style.width='0%';
    if(advPctEl)advPctEl.textContent='Index direction proxy';
    if(decPctEl)decPctEl.textContent='Index direction proxy';
    // New highs/lows and volume require a dedicated data feed — show dashes
    const hiEl=document.getElementById('mo-highs'),loEl=document.getElementById('mo-lows');
    const hiSub=document.getElementById('mo-highs-sub'),loSub=document.getElementById('mo-lows-sub');
    const volEl=document.getElementById('mo-vol'),volSub=document.getElementById('mo-vol-sub');
    if(hiEl)hiEl.textContent='—';
    if(loEl)loEl.textContent='—';
    if(hiSub)hiSub.textContent='52-week highs';
    if(loSub)loSub.textContent='52-week lows';
    if(volEl)volEl.textContent='—';
    if(volSub)volSub.textContent='NYSE volume';
    const ts=document.getElementById('mo-timestamp');
    if(ts)ts.textContent=`Market data as of ${new Date().toLocaleString('en-US',{month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit',hour12:true,timeZone:'America/New_York',timeZoneName:'short'})}`;
  }catch(_){}
  // VIX — live from Finnhub via our own server
  fetch('/api/quote/%5EVIX?range=1d&preview=1',{credentials:'same-origin'}).then(r=>r.ok?r.json():null).catch(()=>null).then(d=>{
    const meta=d?.chart?.result?.[0]?.meta;
    const v=meta?.regularMarketPrice;
    if(v){
      const el=document.getElementById('mo-vix'),sub=document.getElementById('mo-vix-sub');
      if(el){el.textContent=v.toFixed(1);el.className=`mo-bv2-val ${v>25?'dn':v>18?'neu':'up'}`;}
      const prev=meta?.chartPreviousClose||meta?.previousClose;
      if(sub && prev){
        const chg=v-prev, pct=(chg/prev*100);
        sub.innerHTML=`<span style="color:${chg<=0?'var(--market-up)':'var(--market-down)'}">${chg>=0?'+':''}${chg.toFixed(1)} (${pct>=0?'+':''}${pct.toFixed(2)}%)</span>`;
      } else if(sub){
        sub.textContent='Volatility index';
      }
    }
  });
}

async function loadAnalystSignals(tickers){
  // Calls server-side proxy — Finnhub key never exposed in the browser.
  let buy=0,hold=0,sell=0;
  try{
    const r=await fetch(`/api/market/analyst-signals?tickers=${tickers.map(t=>encodeURIComponent(t)).join(',')}`,{credentials:'same-origin'});
    if(r.ok){const d=await r.json();buy=d.buy||0;hold=d.hold||0;sell=d.sell||0;}
  }catch(_){}
  const total=buy+hold+sell||1,buyPct=Math.round(buy/total*100),holdPct=Math.round(hold/total*100),sellPct=100-buyPct-holdPct;
  ['analyst-bull-pct','abl-buy','abl-hold','abl-sell','analyst-note'].forEach((id,i)=>{const el=document.getElementById(id);if(el)el.textContent=[buyPct+'%',buy+' Buy',hold+' Hold',sell+' Sell',`Based on ${buy+hold+sell} analyst ratings`][i];});
  const c2=document.getElementById('analyst-donut-chart');if(!c2)return;
  if(window._analystDonut){window._analystDonut.destroy();} window._analystDonut=new Chart(c2,{type:'doughnut',data:{datasets:[{data:[buyPct,holdPct,sellPct],backgroundColor:[cp().positive,cp().neutral,cp().negative],borderWidth:0}]},options:{responsive:false,cutout:'70%',animation:{duration:400},plugins:{legend:{display:false},tooltip:{enabled:false}}}});
}

async function loadHomeInsights(){
  const el=document.getElementById('home-insights-list');if(!el)return;
  const cats=['MARKET BRIEF','STOCK INSIGHT','SECTOR UPDATE','EARNINGS TAKEAWAY'],icons=['📰','📊','🏭','💰'];
  try{
    const r=await fetch('/api/news/SPY',{credentials:'same-origin'});if(!r.ok)throw new Error();
    const news=await r.json();const items=(Array.isArray(news)?news:news.data||[]).slice(0,4);if(!items.length)throw new Error();
    el.innerHTML=items.map((n,i)=>{const title=escapeHtml((n.headline||n.title||'Market Update').substring(0,68));const ts=escapeHtml(n.datetime?timeAgo(n.datetime*1000):'Recently');const url=safeExternalUrl(n.url);const tag=url?'a':'div';const attrs=url?` href="${url}" target="_blank" rel="noopener noreferrer"`:'';return`<${tag} class="insight-item"${attrs}><div class="insight-thumb">${icons[i%4]}</div><div class="insight-body"><div class="insight-cat">${cats[i%4]}</div><div class="insight-title">${title}</div><div class="insight-time">${ts}</div></div></${tag}>`;}).join('');
  }catch(_){el.innerHTML='<div class="insight-item" style="cursor:default"><div class="insight-thumb"><i class="ti ti-cloud-off"></i></div><div class="insight-body"><div class="insight-cat">MARKET NEWS</div><div class="insight-title">Headlines are refreshing.</div><div class="insight-time">Open a ticker for company-specific research or check again shortly.</div></div></div>';}
}
function timeAgo(ms){const d=(Date.now()-ms)/1000;if(d<3600)return`${Math.round(d/60)}m ago`;if(d<86400)return`${Math.round(d/3600)}h ago`;return`${Math.round(d/86400)}d ago`;}

function loadPortfolioSparklines(){
  [['mp-cg',[100,103,101,106,108,105,112,115,113,118,120,112],true],['mp-di',[100,102,101,103,105,104,107,106,108,107,110,108],true],['mp-at',[100,105,102,110,115,108,120,125,118,130,135,119],true]].forEach(([id,d,up])=>{const el=document.getElementById(id);if(el)el.innerHTML=buildSparklineSVG(d,up);});
}

async function loadMarketMovers(){
  const[g,l,a]=await Promise.allSettled([fetch('/api/market/movers?type=gainers',{credentials:'same-origin'}).then(r=>r.ok?r.json():null).catch(()=>null),fetch('/api/market/movers?type=losers',{credentials:'same-origin'}).then(r=>r.ok?r.json():null).catch(()=>null),fetch('/api/market/movers?type=active',{credentials:'same-origin'}).then(r=>r.ok?r.json():null).catch(()=>null)]);
  _moversCache.gainers=g.value||[];_moversCache.losers=l.value||[];_moversCache.active=a.value||[];
  renderMovers(_moversActive);
}
function switchMovers(type,btn){_moversActive=type;document.querySelectorAll('.movers-tab').forEach(b=>b.classList.remove('on'));if(btn)btn.classList.add('on');renderMovers(type);}

function renderMovers(type) {
  const el = document.getElementById('home-movers-list'); if (!el) return;
  const items = (_moversCache[type] || []).slice(0, 5);
  if (!items.length) { el.innerHTML = '<div style="color:var(--text5);font-size:.67rem;text-align:center;padding:.8rem 0;">Market movers are refreshing</div>'; return; }
  el.innerHTML = items.map(m => {
    const up = m.chgPct >= 0;
    const price = m.price >= 1000 ? m.price.toLocaleString('en-US',{maximumFractionDigits:0}) : m.price.toFixed(2);
    const symbol = escapeHtml(m.symbol);
    return `<div class="mover-row" data-ticker="${symbol}" onclick="loadTicker(this.dataset.ticker)" style="cursor:pointer;">
      <div><div class="mover-sym">${symbol}</div><div class="mover-co">${escapeHtml((m.name||'').substring(0,26))}</div></div>
      <div class="mover-price">$${price}</div>
      <div class="mover-pct ${up?'up':'dn'}">${up?'+':''}${m.chgPct.toFixed(2)}%</div>
    </div>`;
  }).join('');
}

function loadHomeWatchlist(watchData) {
  const el = document.getElementById('home-watchlist-body'); if (!el) return;
  const starred = ['AAPL','NVDA','TSLA','MSFT','AMZN'];
  const LOGOS = {AAPL:'apple.com',NVDA:'nvidia.com',MSFT:'microsoft.com',TSLA:'tesla.com',AMZN:'amazon.com',META:'meta.com',GOOGL:'google.com',SPY:'ssga.com'};
  const NAMES = {AAPL:'Apple Inc.',NVDA:'NVIDIA Corp.',MSFT:'Microsoft Corp.',TSLA:'Tesla, Inc.',AMZN:'Amazon.com, Inc.',META:'Meta Platforms',GOOGL:'Alphabet Inc.',SPY:'S&P 500 ETF'};
  const rows = (watchData || []).filter(d => starred.includes(d.t)).slice(0, 5);
  if (!rows.length) { el.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:.9rem 0;color:var(--text5);font-size:.67rem;">Sign in to see your watchlist</td></tr>'; return; }
  el.innerHTML = rows.map(({t, meta}) => {
    if (!meta) return '';
    const price = meta.regularMarketPrice ?? meta.chartPreviousClose;
    const prev = meta.chartPreviousClose || price;
    const pct = prev ? ((price - prev) / prev * 100) : 0;
    const up = pct >= 0;
    const pFmt = price >= 1000 ? price.toLocaleString('en-US',{maximumFractionDigits:0}) : price.toFixed(2);
    const svg = buildSparklineSVG([prev*0.998,prev*1.001,prev*0.999,prev*1.002,price*0.998,price],up);
    return `<tr>
      <td><div class="wl-sym">${t}</div><div class="wl-co">${NAMES[t]||t}</div></td>
      <td class="wl-price">$${pFmt}</td>
      <td class="wl-pct ${up?'up':'dn'}">${up?'▲':'▼'} ${Math.abs(pct).toFixed(2)}%</td>
      <td class="wl-spark">${svg}</td>
      <td><span class="wl-star lit" title="Starred">★</span></td>
    </tr>`;
  }).join('');
}

const FEATURED_TICKERS = ['AAPL','NVDA','MSFT','TSLA','AMZN','META','GOOGL','SPY'];
async function loadFeaturedGrid() {
  const el = document.getElementById('featured-grid');
  if (!el) return;
  // Show skeleton placeholders
  el.innerHTML = FEATURED_TICKERS.map(t =>
    `<div class="fstock-card" style="opacity:.4;"><div class="fstock-sym">${t}</div><div class="fstock-price">—</div><div class="fstock-chg">Loading…</div></div>`
  ).join('');
  // Fetch all tickers in parallel
  const results = await Promise.allSettled(
    FEATURED_TICKERS.map(t =>
      fetch(`/api/quote/${t}?range=1d&preview=1`, { credentials:'same-origin' })
        .then(r => r.ok ? r.json() : null)
        .catch(() => null)
    )
  );
  const FG_LOGOS={AAPL:'https://www.google.com/s2/favicons?sz=32&domain=apple.com',NVDA:'https://www.google.com/s2/favicons?sz=32&domain=nvidia.com',MSFT:'https://www.google.com/s2/favicons?sz=32&domain=microsoft.com',TSLA:'https://www.google.com/s2/favicons?sz=32&domain=tesla.com',AMZN:'https://www.google.com/s2/favicons?sz=32&domain=amazon.com',META:'https://www.google.com/s2/favicons?sz=32&domain=meta.com',GOOGL:'https://www.google.com/s2/favicons?sz=32&domain=google.com',SPY:'https://www.google.com/s2/favicons?sz=32&domain=ssga.com'};
  el.innerHTML = results.map((res, i) => {
    const t = FEATURED_TICKERS[i];
    const data = res.status === 'fulfilled' ? res.value : null;
    const meta = data?.chart?.result?.[0]?.meta;
    const closes = data?.chart?.result?.[0]?.indicators?.quote?.[0]?.close?.filter(x=>x!=null)||[];
    if (!meta) {
      return `<div class="fstock-card" onclick="loadTicker('${t}')"><div class="fstock-top"><span class="fstock-sym">${t}</span></div><div class="fstock-price">—</div></div>`;
    }
    const price = meta.regularMarketPrice ?? meta.chartPreviousClose;
    const prev  = meta.chartPreviousClose || price;
    const chg   = price - prev;
    const chgPct = prev ? (chg / prev * 100) : 0;
    const up = chg >= 0;
    const logo = FG_LOGOS[t]?`<img class="fstock-logo" src="${FG_LOGOS[t]}" onerror="this.style.display='none'" alt="">`:''
    return `<div class="fstock-card" onclick="loadTicker('${t}')">
      <div class="fstock-top">${logo}<span class="fstock-sym">${t}</span></div>
      <div class="fstock-price">$${price >= 1000 ? price.toFixed(0) : price.toFixed(2)}</div>
      <div class="fstock-chg ${up?'up':'dn'}">${up?'▲':'▼'} ${Math.abs(chgPct).toFixed(2)}%</div>
      <div class="fstock-spark">${buildSparklineSVG(closes,up)}</div>
    </div>`;
  }).join('');
}

function loadTicker(ticker) {
  document.getElementById('main-ticker').value = ticker;
  navGoTo('analyze');
  fetchAndRender();
}

function updateThemeControl() {
  window.syncBrowserChrome?.();
  const btn = document.getElementById('theme-toggle-btn');
  if (!btn) return;
  const dark = isDark();
  const nextMode = dark ? 'light' : 'dark';
  btn.setAttribute('aria-pressed', String(dark));
  btn.setAttribute('aria-label', `Switch to ${nextMode} mode`);
  btn.title = `Switch to ${nextMode} mode`;
}

function toggleTheme() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  if (isDark) {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('il-theme', 'light');
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('il-theme', 'dark');
  }
  updateThemeControl();
  requestAnimationFrame(() => {
    Chart.defaults.color = ct().text;
    const themeCharts = [...new Set([...Object.values(S.charts || {}), _marketOverviewChart].filter(Boolean))];
    themeCharts.forEach(chart => {
      if (!chart) return;
      const t = ct();
      Object.values(chart.options?.scales||{}).forEach(scale=>{
        if(scale?.ticks)scale.ticks.color=t.text;
        if(scale?.grid)scale.grid.color=t.grid;
        if(scale?.border)scale.border.color=t.grid;
        if(scale?.title)scale.title.color=t.muted;
        if(scale?.pointLabels)scale.pointLabels.color=t.text;
      });
      if (chart.options?.plugins?.tooltip) {
        chart.options.plugins.tooltip.backgroundColor = t.ttBg;
        chart.options.plugins.tooltip.titleColor = t.ttTitle;
        chart.options.plugins.tooltip.bodyColor = t.ttBody;
        chart.options.plugins.tooltip.borderColor = t.ttBorder;
      }
      if(chart.options?.plugins?.legend?.labels)chart.options.plugins.legend.labels.color=t.text;
      chart.update('none');
    });
    if(_expandedChart){
      const t=ct();
      Object.values(_expandedChart.options?.scales||{}).forEach(scale=>{if(scale?.ticks)scale.ticks.color=t.text;if(scale?.grid)scale.grid.color=t.grid;if(scale?.border)scale.border.color=t.grid;});
      if(_expandedChart.options?.plugins?.legend?.labels)_expandedChart.options.plugins.legend.labels.color=t.text;
      _expandedChart.update('none');
    }
  });
}

const EDU_LESSONS = {
  'site-tour':{title:'Use Implied Lens as one decision workflow',body:'The product is organized around a repeatable sequence. Start with the company and chart, verify the business evidence, test valuation, then record the decision. You do not need to visit every tab for every stock.',points:['Research: load a ticker and confirm the company, price, source badges, and as-of dates.','Chart and LensScore: identify trend, key zones, tactical setup, long-term value, confidence, and active caps.','Financials, Metrics, and Earnings: verify the operating evidence behind the score.','Value or Projection: test a range of assumptions; do not treat one model output as truth.','Saved or Planner: record the thesis, risks, failure condition, and review date.'],formula:'Workflow = Identify → Verify → Value → Decide → Review',example:'If LensValue is high but LensSetup is weak, add the company to Saved with a price zone and review date instead of forcing an entry.',warning:'Do not jump from a green score to a trade. Confirm source dates, missing fields, and the evidence that could invalidate the idea.',tool:'analyze',toolLabel:'Open Research'},
  'lens-score':{title:'Read the two lenses before the combined score',body:'LensScore is a 0–10 buyability metric, not a prediction. LensValue measures the long-term opportunity; LensSetup measures the current technical entry. The combined score is useful only when you can explain what each lens is saying.',points:['LensValue covers business quality, valuation, embedded expectations, and downside risk over roughly 1–3 years.','LensTiming measures entry pressure: 10 means the most favorable buyer-side pressure and 0 means an extended, seller-dominated entry. LensTrend separately measures direction.','LensSetup combines timing, support/resistance location, trend, structure, volume, technical risk, and reversal confirmation over roughly 2–12 weeks.','The combined score weights LensValue 70% and LensSetup 30%, then considers agreement and severe risks.','Confidence reports evidence coverage. A cap means one attractive feature—such as oversold momentum or a lower price—cannot erase a falling knife, weak quality, leverage, or missing evidence.'],formula:'LensScore = 70% LensValue + 30% LensSetup ± alignment, subject to caps',example:'A 9.1 LensValue and 5.0 LensSetup can describe an attractive business at a technically weak entry. Use each lens independently.',warning:'Golden Lens is deliberately rare. It requires both lenses to be exceptional, adequate confidence, and no active quality cap.',tool:'lens-score',toolLabel:'Open LensScore'},
  charts:{title:'Use technical indicators as a system, not isolated signals',body:'Technical analysis describes price behavior and risk. Start with trend and price structure, then use momentum, volume, and volatility to confirm or challenge that reading.',points:['Support and resistance are zones created from repeated price reactions, not exact promises.','The 20-, 50-, and 200-day moving averages describe short-, intermediate-, and long-term trend structure.','RSI and Stochastic RSI describe momentum location; extreme readings can persist in strong trends.','MACD describes changes in trend momentum. Confirm crossovers with price structure and volume.','ATR/price and drawdown describe risk. Use them to size expectations and avoid treating all charts as equally stable.'],formula:'Technical case = Structure + Trend + Momentum + Volume − Volatility risk',example:'A support retest is stronger when the long-term trend is positive, selling volume fades, and momentum begins improving.',warning:'One oversold reading is not a floor. A broken trend with heavy volume can keep falling through prior support.',tool:'analyze',toolLabel:'Open the chart'},
  financials:{title:'Separate company facts from valuation assumptions',body:'Financial analysis is most useful when every number has a clear status. Implied Lens distinguishes observed provider data, derived calculations, modeled estimates, and user scenarios.',points:['Observed: revenue, net income, cash flow, balance-sheet values, price, and reported earnings from named sources.','Derived: growth rates, margins, ROIC, leverage, dilution, and multiples calculated from observed inputs.','Modeled: fair multiples, value ranges, and expectations gaps produced by disclosed Implied Lens assumptions.','Scenario: your changed price, growth, margin, or discount-rate inputs; it never replaces reported history.','Always read the source badge, as-of date, EPS basis, unavailable-field message, and sensitivity before acting.'],formula:'Per-share value = Business economics × defensible assumptions ÷ diluted shares',example:'If annual EPS is stale but four newer reported quarters are complete, the valuation can use disclosed trailing-four-quarter actual EPS instead.',warning:'Revenue growth without cash flow, returns on capital, balance-sheet context, and dilution can create a misleading quality impression.',tool:'financials',toolLabel:'Open Financials'},
  thesis:{title:'Build a falsifiable stock thesis',body:'A useful stock thesis states what the market may be missing, identifies the operating evidence that should close the gap, and defines what would prove the idea wrong. It is a testable decision record, not a prediction that the price will rise.',points:['Variant view: state what you believe differently from the market.','Business driver: connect the view to revenue, margins, cash flow, or per-share value.','Evidence: name the result or catalyst that would support the view.','Failure condition: write the measurable fact that would invalidate it.'],formula:'Thesis = Variant view + Business driver + Evidence + Failure condition',example:'Example: recurring-revenue mix lifts operating margin faster than expected over the next four quarters.',warning:'“The stock looks cheap” is not a thesis unless you explain why earnings or cash-flow expectations are wrong.',tool:'analyze',toolLabel:'Choose a stock to research'}
};

function eduCompleted(){try{return JSON.parse(localStorage.getItem('il-edu-complete')||'[]')}catch(_){return[]}}
function updateEduProgress(){
  const lessonIds=[...document.querySelectorAll('.edu-path[data-lesson]')].map(card=>card.dataset.lesson);
  const done=eduCompleted().filter(id=>lessonIds.includes(id));
  document.querySelectorAll('.edu-path').forEach(card=>card.classList.toggle('done',done.includes(card.dataset.lesson)));
  const label=document.getElementById('edu-progress-label'),fill=document.getElementById('edu-progress-fill');
  if(label)label.textContent=`${done.length} / ${lessonIds.length}`;
  if(fill)fill.style.width=`${lessonIds.length ? done.length/lessonIds.length*100 : 0}%`;
}
function openLesson(card){
  if(!card)return;
  if(card.dataset.lesson==='thesis'&&typeof window.openLearnWorkshop==='function'){
    document.querySelectorAll('.edu-path').forEach(el=>el.classList.toggle('active',el===card));
    window.openLearnWorkshop();
    return;
  }
  const lesson=EDU_LESSONS[card.dataset.lesson],host=document.getElementById('edu-workshop');if(!lesson||!host)return;
  host.innerHTML='<div id="edu-lesson-panel"></div>';
  const panel=document.getElementById('edu-lesson-panel');
  document.querySelectorAll('.edu-path').forEach(el=>el.classList.toggle('active',el===card));
  panel.innerHTML=`<div class="edu-lesson-content"><div class="edu-kicker">Practical lesson</div><h3>${lesson.title}</h3><p>${lesson.body}</p><div class="edu-lesson-points">${lesson.points.map(p=>`<div>${p}</div>`).join('')}</div><div class="edu-lesson-notes"><div class="edu-lesson-note"><strong>Formula</strong>${lesson.formula}</div><div class="edu-lesson-note"><strong>Worked use</strong>${lesson.example}</div><div class="edu-lesson-note"><strong>Failure mode</strong>${lesson.warning}</div></div><div class="edu-lesson-actions"><button onclick="completeLesson('${card.dataset.lesson}')"><i class="ti ti-check"></i> Mark complete</button><button class="secondary" onclick="navGoTo('${lesson.tool}')">${lesson.toolLabel} <i class="ti ti-arrow-right"></i></button></div></div>`;
}
function completeLesson(id){
  const checks=[...document.querySelectorAll('.edu-checklist input')];
  if(checks.length&&checks.some(el=>!el.checked)){toast('Complete the module exercise first','err');return;}
  const done=new Set(eduCompleted());done.add(id);localStorage.setItem('il-edu-complete',JSON.stringify([...done]));updateEduProgress();toast('Module completed','ok');
}
function filterGlossary(value){
  const q=String(value||'').trim().toLowerCase();
  document.querySelectorAll('.edu-term').forEach(el=>el.style.display=!q||el.dataset.term.includes(q)||el.textContent.toLowerCase().includes(q)?'':'none');
}
function resetEduChecklist(){document.querySelectorAll('.edu-checklist input').forEach(el=>el.checked=false)}
document.addEventListener('DOMContentLoaded',updateEduProgress);

async function loadAnalyst(ticker) {
  if (!isPro()) return;
  try {
    const r = await fetch(`/api/analyst/${encodeURIComponent(ticker)}`, { credentials: 'same-origin' });
    if (!r.ok) return;
    const d = await r.json();

    // ── Price targets → overlay on chart ──
    const pt = d.priceTarget || {};
    const mean = pt.targetMean || null;
    const high = pt.targetHigh || null;
    const low  = pt.targetLow  || null;
    if (mean || high || low) {
      S.analystTarget = { mean, high, low };
      rebuildPriceChart();
    }

    // ── Consensus bar → sidebar ──
    const sideEl = document.getElementById('analyst-sidebar');
    if (!sideEl) return;

    const recs = Array.isArray(d.recommendations) ? d.recommendations : [];
    // Aggregate last 3 months of recommendation data
    const counts = { strongBuy:0, buy:0, hold:0, sell:0, strongSell:0 };
    recs.slice(0, 3).forEach(r2 => {
      counts.strongBuy  += (r2.strongBuy  || 0);
      counts.buy        += (r2.buy        || 0);
      counts.hold       += (r2.hold       || 0);
      counts.sell       += (r2.sell       || 0);
      counts.strongSell += (r2.strongSell || 0);
    });
    const totalRec = counts.strongBuy + counts.buy + counts.hold + counts.sell + counts.strongSell;

    // Price target row
    let ptHtml = '';
    if (mean) {
      const curPrice = S.meta ? S.meta.regularMarketPrice : null;
      const upside = curPrice ? ((mean - curPrice) / curPrice * 100).toFixed(1) : null;
      ptHtml = `
        <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;">
          <span style="font-size:.72rem;color:var(--text4);">Analyst Price Target</span>
          <span style="font-size:1.05rem;font-weight:700;color:var(--gold);">$${mean.toFixed(2)}</span>
        </div>
        ${upside!==null?`<div style="font-size:.7rem;color:${parseFloat(upside)>=0?'var(--market-up)':'var(--market-down)'};margin-bottom:8px;">${parseFloat(upside)>=0?'▲':'▼'} ${Math.abs(upside)}% from current price</div>`:''}
        ${high||low?`<div style="font-size:.68rem;color:var(--text5);margin-bottom:10px;">Range: ${low?'$'+low.toFixed(2):'—'} – ${high?'$'+high.toFixed(2):'—'}</div>`:''}`;
    } else {
      // Provider doesn't include street targets — say so, and offer the model instead
      ptHtml = `<div style="font-size:.68rem;color:var(--text5);margin-bottom:10px;line-height:1.5;">Street price targets aren't included by the current data provider. Use the <a href="#" onclick="openSection('dcf');return false;" style="color:var(--gold);">intrinsic-value model</a> or <a href="#" onclick="openSection('projection');return false;" style="color:var(--gold);">Scenario Lab</a> to build your own range.</div>`;
    }

    // Consensus bar
    let barHtml = '';
    if (totalRec > 0) {
      const pSB = (counts.strongBuy  / totalRec * 100).toFixed(1);
      const pB  = (counts.buy        / totalRec * 100).toFixed(1);
      const pH  = (counts.hold       / totalRec * 100).toFixed(1);
      const pS  = (counts.sell       / totalRec * 100).toFixed(1);
      const pSS = (counts.strongSell / totalRec * 100).toFixed(1);

      const bullPct = (counts.strongBuy + counts.buy) / totalRec * 100;
      const bearPct = (counts.sell + counts.strongSell) / totalRec * 100;
      const palette=cp();
      let consensus = 'Hold', consColor = palette.price;
      if (bullPct >= 60) { consensus = 'Buy'; consColor = palette.positive; }
      if (bullPct >= 80) { consensus = 'Strong Buy'; consColor = palette.positive; }
      if (bearPct >= 50) { consensus = 'Sell'; consColor = palette.negative; }

      barHtml = `
        <div style="font-size:.7rem;color:var(--text4);margin-bottom:4px;">Analyst Consensus <span style="float:right;font-weight:700;color:${consColor};">${consensus}</span></div>
        <div class="consensus-bar-row">
          ${pSB>0?`<div style="flex:${pSB};background:${palette.positive};border-radius:3px;" title="Strong Buy ${pSB}%"></div>`:''}
          ${pB>0?`<div style="flex:${pB};background:${colorAlpha(palette.positive,.72)};border-radius:3px;" title="Buy ${pB}%"></div>`:''}
          ${pH>0?`<div style="flex:${pH};background:${palette.price};border-radius:3px;" title="Hold ${pH}%"></div>`:''}
          ${pS>0?`<div style="flex:${pS};background:${colorAlpha(palette.negative,.72)};border-radius:3px;" title="Sell ${pS}%"></div>`:''}
          ${pSS>0?`<div style="flex:${pSS};background:${palette.negative};border-radius:3px;" title="Strong Sell ${pSS}%"></div>`:''}
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.65rem;color:var(--text5);margin-top:3px;">
          <span>🟢 ${counts.strongBuy+counts.buy} Buy</span>
          <span>🟡 ${counts.hold} Hold</span>
          <span>🔴 ${counts.sell+counts.strongSell} Sell</span>
        </div>
        <div style="font-size:.62rem;color:var(--text5);margin-top:4px;">Based on ${totalRec} analyst ratings</div>`;
    }

    if (ptHtml || barHtml) {
      sideEl.innerHTML = `<div class="sidebar-card">${ptHtml}${barHtml}</div>`;
    }
  } catch (_) {}
}

const candleWickPlugin = {
  id: 'candleWick',
  afterDatasetsDraw(chart) {
    if(S.chartType !== 'candle') return;
    const ds0 = chart.getDatasetMeta(0);
    const q = chart.data.datasets[0]?._quote || S.data?.indicators?.quote?.[0];
    if(!ds0 || !q) return;
    const highs = q.high||[], lows = q.low||[], opens = q.open||[], closes2 = q.close||[];
    const ctx2 = chart.ctx;
    ctx2.save();
    ds0.data.forEach((bar, i) => {
      if(!bar || highs[i]==null || lows[i]==null) return;
      const x = bar.x;
      const yH = chart.scales.y.getPixelForValue(highs[i]);
      const yL = chart.scales.y.getPixelForValue(lows[i]);
      const yO = chart.scales.y.getPixelForValue(opens[i]||closes2[i]);
      const yC = chart.scales.y.getPixelForValue(closes2[i]);
      const isUp = (closes2[i]||0) >= (opens[i]||0);
      const palette=cp();
      ctx2.strokeStyle = isUp ? palette.positive : palette.negative;
      ctx2.lineWidth = 1;
      ctx2.beginPath(); ctx2.moveTo(x, yH); ctx2.lineTo(x, Math.min(yO,yC)); ctx2.stroke();
      ctx2.beginPath(); ctx2.moveTo(x, yL); ctx2.lineTo(x, Math.max(yO,yC)); ctx2.stroke();
    });
    ctx2.restore();
  }
};

function buildPriceChart(result,closes,timestamps) {
  destroyChart('price-chart');
  const t=ct();
  const p=cp();
  const count=Math.min(closes.length,timestamps.length);
  const vc=closes.slice(0,count).map(Number);
  const _tsArr=timestamps.slice(0,count);
  const _multiYear=_tsArr.length>1&&(new Date(_tsArr[_tsArr.length-1]*1000).getFullYear()!==new Date(_tsArr[0]*1000).getFullYear());
  const _intraday=S.range==='1d'||S.range==='5d';
  const vl=_tsArr.map(ts=>{
    const d=new Date(ts*1000);
    if(_intraday)return d.toLocaleDateString('en-US',{month:'short',day:'numeric'})+' '+d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true});
    if(_multiYear)return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'2-digit'}).replace(', '," '");
    return d.toLocaleDateString('en-US',{month:'short',day:'numeric'});
  });
  const _lbD=_lookbackDaily();
  syncIndicatorAvailability(_lbD ? Math.max(vc.length,_lbD.close.length) : vc.length);
  let ma50v, ma200v, bbv;
  { const _s50=_lbSeries('sma',50), _s200=_lbSeries('sma',200), _sbb=_lbSeries('bb',20);
    ma50v  = _s50  ? _alignToVisible(_s50.ts,_s50.vals,_tsArr)   : sma(vc,50);
    ma200v = _s200 ? _alignToVisible(_s200.ts,_s200.vals,_tsArr) : sma(vc,200);
    bbv    = _sbb  ? _alignToVisible(_sbb.ts,_sbb.vals,_tsArr).map(x=>x||{u:null,l:null,mid:null}) : bollinger(vc,20);
  }
  const hp={pointRadius:0,pointHoverRadius:6,pointHoverBorderWidth:2,pointHoverBorderColor:'#fff'};
  const fillGrad=ctx=>{const h=ctx.chart.chartArea?.bottom||260;const g=ctx.chart.ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,colorAlpha(p.price,.28));g.addColorStop(.55,colorAlpha(p.price,.10));g.addColorStop(1,colorAlpha(p.price,0));return g;};
  const strongGrad=ctx=>{const h=ctx.chart.chartArea?.bottom||260;const g=ctx.chart.ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,colorAlpha(p.price,.40));g.addColorStop(.62,colorAlpha(p.price,.13));g.addColorStop(1,colorAlpha(p.price,.02));return g;};
  let ds;
  if(S.chartType==='candle') {
    const q2=result.indicators.quote[0];
    const opens2=(q2.open||[]).slice(0,count), closes2=vc;
    const candleColors=closes2.map((c2,i)=>(c2||0)>=(opens2[i]||0)?colorAlpha(p.positive,.88):colorAlpha(p.negative,.88));
    ds=[{label:'Price',data:closes2.map((c2,i)=>[Math.min(opens2[i],c2),Math.max(opens2[i],c2)]),backgroundColor:candleColors,borderColor:candleColors,borderWidth:0,borderRadius:1,order:10,_quote:q2}];
  } else if(S.chartType==='area') {
    ds=[{label:'Price',data:vc,borderColor:p.price,borderWidth:2.7,...hp,pointHoverBackgroundColor:p.price,fill:true,backgroundColor:strongGrad,tension:.22,order:10}];
  } else {
    ds=[{label:'Price',data:vc,borderColor:p.price,borderWidth:2.4,...hp,pointHoverBackgroundColor:p.price,fill:false,tension:.22,order:10}];
  }
  const lineType = S.chartType==='candle' ? {type:'line'} : {};
  if(S.inds.ma50&&ma50v.some(v=>v!=null))  ds.push({...lineType,label:'50D average', data:ma50v, borderColor:p.ma50,borderWidth:2,...hp,pointHoverBackgroundColor:p.ma50,fill:false,tension:.2,order:9});
  if(S.inds.ma200&&ma200v.some(v=>v!=null)) ds.push({...lineType,label:'200D average',data:ma200v,borderColor:p.ma200,borderWidth:2,...hp,pointHoverBackgroundColor:p.ma200,fill:false,tension:.2,order:8});
  if(S.inds.bb&&bbv.some(x=>x&&x.u!=null)) {
    ds.push({...lineType,label:'Upper band',data:bbv.map(x=>x.u),borderColor:colorAlpha(p.bands,.62),borderWidth:1,pointRadius:0,fill:false,tension:.2,order:7,borderDash:[4,3]});
    ds.push({...lineType,label:'Lower band',data:bbv.map(x=>x.l),borderColor:colorAlpha(p.bands,.62),borderWidth:1,pointRadius:0,fill:false,tension:.2,order:6,borderDash:[4,3]});
  }
  if(S.analystTarget){
    const n=vl.length;
    if(S.analystTarget.mean) ds.push({...lineType,label:`Analyst target $${S.analystTarget.mean.toFixed(0)}`,data:Array(n).fill(S.analystTarget.mean),borderColor:colorAlpha(p.price,.82),borderWidth:1.5,borderDash:[6,4],pointRadius:0,fill:false,tension:0,order:5});
    if(S.analystTarget.high) ds.push({...lineType,label:`Target high $${S.analystTarget.high.toFixed(0)}`,data:Array(n).fill(S.analystTarget.high),borderColor:colorAlpha(p.positive,.52),borderWidth:1,borderDash:[3,4],pointRadius:0,fill:false,tension:0,order:4});
    if(S.analystTarget.low)  ds.push({...lineType,label:`Target low $${S.analystTarget.low.toFixed(0)}`,data:Array(n).fill(S.analystTarget.low),borderColor:colorAlpha(p.negative,.52),borderWidth:1,borderDash:[3,4],pointRadius:0,fill:false,tension:0,order:3});
  }
  const opts=baseOpts({
    y:{
      title:{display:true,text:'Price (USD)',color:t.muted,font:{size:9,weight:'500'},padding:{bottom:4}},
      ticks:{color:t.text,font:{size:10},callback:v=>fmtChartPrice(v)},
      grid:{color:t.grid}
    },
    x:{ticks:{color:t.text,font:{size:10},maxTicksLimit:8},grid:{color:t.grid}}
  });
  opts.layout={padding:{top:8,right:54,bottom:20,left:4}};
  opts.plugins.legend={display:false};
  opts.datasets={bar:{barPercentage:.72,categoryPercentage:.9,maxBarThickness:12}};
  opts.plugins.zoom=chartZoomOptions();
  opts.plugins.tooltip={...opts.plugins.tooltip,callbacks:{
    title:items=>items[0]?.label||'',
    label:ctx=>` ${ctx.dataset.label||''}: ${fmtChartPrice(ctx.raw)}`
  }};
  const chartJsType = S.chartType==='candle' ? 'bar' : 'line';
  const pluginsArr = S.chartType==='candle' ? [candleWickPlugin] : [];
  const _pc=new Chart(document.getElementById('price-chart'),{type:chartJsType,data:{labels:vl,datasets:ds},options:opts,plugins:pluginsArr});
  _pc._crosshairAxes=true;
  _pc._crosshairFmt=(v)=>fmtChartPrice(v);
  S.charts['price-chart']=_pc;
}

function buildRSIChart(rsiVals,timestamps) {
  destroyChart('rsi-chart');
  const t=ct();
  const p=cp();
  const labels=chartXLabels(timestamps);
  const last=rsiVals[rsiVals.length-1];
  document.getElementById('rsi-readout').textContent=last?`${last.toFixed(1)} — ${last<30?'Oversold':last>70?'Overbought':'Neutral'}`:'';
  const n=labels.length;
  S.charts['rsi-chart']=new Chart(document.getElementById('rsi-chart'),{
    type:'line',
    data:{labels,datasets:[
      {label:'Overbought · 70',data:Array(n).fill(70),borderColor:colorAlpha(p.negative,.48),borderWidth:1,borderDash:[4,3],pointRadius:0,fill:false,tension:0,order:1},
      {label:'Oversold · 30', data:Array(n).fill(30),borderColor:colorAlpha(p.positive,.48), borderWidth:1,borderDash:[4,3],pointRadius:0,fill:false,tension:0,order:2},
      {label:'RSI · 14',data:rsiVals,borderWidth:1.5,pointRadius:0,pointHoverRadius:5,pointHoverBorderWidth:2,pointHoverBorderColor:'#fff',pointHoverBackgroundColor:p.price,fill:false,tension:.2,order:3,
       segment:{borderColor:ctx=>{const v=ctx.p0?.parsed?.y;return v<30?p.positive:v>70?p.negative:p.price;}}},
    ]},
    options:{
      ...baseOpts(),
      scales:{
        x:{ticks:{color:t.text,font:{size:9},maxTicksLimit:6},grid:{color:t.grid},
           title:{display:true,text:'Date',color:t.muted,font:{size:9}}},
        y:{min:0,max:100,
           ticks:{color:t.text,font:{size:10},stepSize:20,callback:v=>v},
           grid:{color:t.grid},
           title:{display:true,text:'RSI',color:t.muted,font:{size:9}}}
      },
      plugins:{
        legend:{display:false},
        tooltip:{mode:'index',intersect:false,backgroundColor:t.ttBg,titleColor:t.ttTitle,bodyColor:t.ttBody,borderColor:t.ttBorder,borderWidth:1,callbacks:{
          label:ctx=>ctx.dataset.label==='RSI · 14'?` RSI: ${Number(ctx.raw).toFixed(1)}`:null
        }}
      }
    }
  });
}

function buildMACDChart(closes,timestamps) {
  destroyChart('macd-chart');
  const t=ct();
  const p=cp();
  const labels=chartXLabels(timestamps);
  const {line,sig,hist}=macd(closes);
  const last=hist[hist.length-1];
  document.getElementById('macd-readout').textContent=last!=null?`Histogram ${last>0?'+':''}${last.toFixed(3)} — ${last>0?'Bullish':'Bearish'}`:'';
  S.charts['macd-chart']=new Chart(document.getElementById('macd-chart'),{
    type:'bar',
    data:{labels,datasets:[
      {type:'bar', label:'Momentum',data:hist,backgroundColor:hist.map(v=>v>=0?colorAlpha(p.positive,.42):colorAlpha(p.negative,.42)),borderWidth:0,order:3},
      {type:'line',label:'MACD',data:line,borderColor:p.ma50,borderWidth:1.5,pointRadius:0,pointHoverRadius:5,pointHoverBorderColor:'#fff',pointHoverBackgroundColor:p.ma50,fill:false,tension:.2,order:1},
      {type:'line',label:'Signal',data:sig,borderColor:p.bands,borderWidth:1.5,pointRadius:0,pointHoverRadius:5,pointHoverBorderColor:'#fff',pointHoverBackgroundColor:p.bands,fill:false,tension:.2,order:2,borderDash:[4,3]},
    ]},
    options:{
      ...baseOpts(),
      scales:{
        x:{ticks:{color:t.text,font:{size:9},maxTicksLimit:6},grid:{color:t.grid},
           title:{display:true,text:'Date',color:t.muted,font:{size:9}}},
        y:{ticks:{color:t.text,font:{size:10}},grid:{color:t.grid},
           title:{display:true,text:'Value',color:t.muted,font:{size:9}}}
      },
      plugins:{
        legend:{display:false},
        tooltip:{mode:'index',intersect:false,backgroundColor:t.ttBg,titleColor:t.ttTitle,bodyColor:t.ttBody,borderColor:t.ttBorder,borderWidth:1,callbacks:{
          label:ctx=>` ${ctx.dataset.label}: ${Number(ctx.raw).toFixed(4)}`
        }}
      }
    }
  });
}

function buildVolChart(vols,timestamps,closes) {
  destroyChart('vol-chart');
  const t=ct();
  const p=cp();
  const labels=chartXLabels(timestamps);
  const bg=vols.map((_,i)=>closes[i]>=closes[i-1]?colorAlpha(p.positive,.46):colorAlpha(p.negative,.46));
  S.charts['vol-chart']=new Chart(document.getElementById('vol-chart'),{
    type:'bar',
    data:{labels,datasets:[{label:'Volume',data:vols,backgroundColor:bg,borderWidth:0,borderRadius:1}]},
    options:{
      ...baseOpts(),
      scales:{
        x:{ticks:{color:t.text,font:{size:9},maxTicksLimit:6},grid:{color:t.grid},
           title:{display:true,text:'Date',color:t.muted,font:{size:9}}},
        y:{ticks:{color:t.text,font:{size:10},callback:v=>{if(v>=1e9)return(v/1e9).toFixed(1)+'B';if(v>=1e6)return(v/1e6).toFixed(0)+'M';if(v>=1e3)return(v/1e3).toFixed(0)+'K';return v;}},
           grid:{color:t.grid},
           title:{display:true,text:'Shares Traded',color:t.muted,font:{size:9}}}
      },
      plugins:{
        legend:{display:false},
        tooltip:{mode:'index',intersect:false,backgroundColor:t.ttBg,titleColor:t.ttTitle,bodyColor:t.ttBody,borderColor:t.ttBorder,borderWidth:1,callbacks:{
          label:ctx=>{const v=ctx.raw;if(v>=1e9)return ` Volume: ${(v/1e9).toFixed(2)}B`;if(v>=1e6)return ` Volume: ${(v/1e6).toFixed(2)}M`;return ` Volume: ${v?.toLocaleString()}`;}
        }}
      }
    }
  });
}

function buildDistChart(returns) {
  destroyChart('dist-chart');
  const t=ct();
  const p=cp();
  const bins=[]; for(let i=-10;i<=10;i++) bins.push(i);
  const counts=bins.map(b=>returns.filter(r=>r>=b&&r<b+1).length);
  const bg=bins.map(b=>b>=0?colorAlpha(p.positive,.46):colorAlpha(p.negative,.46));
  S.charts['dist-chart']=new Chart(document.getElementById('dist-chart'),{
    type:'bar',
    data:{labels:bins.map(b=>`${b>0?'+':''}${b}%`),datasets:[{label:'Days',data:counts,backgroundColor:bg,borderWidth:0,borderRadius:2}]},
    options:{
      ...baseOpts(),
      scales:{
        x:{ticks:{color:t.text,font:{size:9}},grid:{color:t.grid},
           title:{display:true,text:'Daily Return (%)',color:t.muted,font:{size:9}}},
        y:{ticks:{color:t.text,font:{size:10},stepSize:1},grid:{color:t.grid},
           title:{display:true,text:'Days',color:t.muted,font:{size:9}}}
      },
      plugins:{
        legend:{display:false},
        tooltip:{mode:'index',intersect:false,backgroundColor:t.ttBg,titleColor:t.ttTitle,bodyColor:t.ttBody,borderColor:t.ttBorder,borderWidth:1,callbacks:{
          title:items=>`Return: ${items[0]?.label||''}`,
          label:ctx=>` ${ctx.raw} trading day${ctx.raw!==1?'s':''}`
        }}
      }
    }
  });
}

function buildOBVChart(closes,vols,timestamps) {
  destroyChart('obv-chart');
  const el=document.getElementById('obv-chart'); if(!el) return;
  const t=ct();
  const p=cp();
  const labels=timestamps.map(ts2=>new Date(ts2*1000).toLocaleDateString('en-US',{month:'short',day:'numeric'}));
  const c2=closes.filter(x=>x!=null); const v2=vols.filter(x=>x!=null);
  const obvData=calcOBV(c2,v2);
  const last=obvData[obvData.length-1]||0;
  const el2=document.getElementById('obv-readout'); if(el2) el2.textContent=`${last>=0?'Accumulation':'Distribution'} (${(Math.abs(last)/1e6).toFixed(1)}M)`;
  const fillG=ctx2=>{const g=ctx2.chart.ctx.createLinearGradient(0,0,0,145);g.addColorStop(0,colorAlpha(p.ma50,.18));g.addColorStop(1,colorAlpha(p.ma50,0));return g;};
  S.charts['obv-chart']=new Chart(el,{type:'line',data:{labels,datasets:[{label:'On-balance volume',data:obvData,borderColor:p.ma50,borderWidth:1.5,pointRadius:0,pointHoverRadius:5,fill:true,backgroundColor:fillG,tension:.2}]},options:{...baseOpts(),scales:{x:{ticks:{color:t.text,font:{size:9},maxTicksLimit:6},grid:{color:t.grid},title:{display:true,text:'Date',color:t.muted,font:{size:9}}},y:{ticks:{color:t.text,font:{size:9},callback:v=>`${v>=0?'':'-'}${(Math.abs(v)/1e6).toFixed(0)}M`},grid:{color:t.grid},title:{display:true,text:'OBV',color:t.muted,font:{size:9}}}},plugins:{legend:{display:false},tooltip:{mode:'index',intersect:false,backgroundColor:t.ttBg,titleColor:t.ttTitle,bodyColor:t.ttBody,borderColor:t.ttBorder,borderWidth:1,callbacks:{label:ctx3=>` OBV: ${(ctx3.raw/1e6).toFixed(2)}M`}}}}});
}
function buildATRChart(highs,lows,closes,timestamps) {
  destroyChart('atr-chart');
  const el=document.getElementById('atr-chart'); if(!el) return;
  const t=ct();
  const p=cp();
  const labels=timestamps.map(ts2=>new Date(ts2*1000).toLocaleDateString('en-US',{month:'short',day:'numeric'}));
  const atrData=calcATR(highs.filter(x=>x!=null),lows.filter(x=>x!=null),closes.filter(x=>x!=null));
  const last=atrData.filter(x=>x!=null).pop()||0;
  const avg=atrData.filter(x=>x!=null).reduce((a,b)=>a+b,0)/atrData.filter(x=>x!=null).length;
  const el2=document.getElementById('atr-readout'); if(el2) el2.textContent=`$${last.toFixed(2)} — ${last>avg?'High Volatility':'Low Volatility'}`;
  const fillG=ctx2=>{const g=ctx2.chart.ctx.createLinearGradient(0,0,0,145);g.addColorStop(0,colorAlpha(p.bands,.18));g.addColorStop(1,colorAlpha(p.bands,0));return g;};
  S.charts['atr-chart']=new Chart(el,{type:'line',data:{labels,datasets:[{label:'Average true range · 14',data:atrData,borderColor:p.bands,borderWidth:1.5,pointRadius:0,pointHoverRadius:5,fill:true,backgroundColor:fillG,tension:.2,spanGaps:true}]},options:{...baseOpts(),scales:{x:{ticks:{color:t.text,font:{size:9},maxTicksLimit:6},grid:{color:t.grid},title:{display:true,text:'Date',color:t.muted,font:{size:9}}},y:{ticks:{color:t.text,font:{size:9},callback:v=>`$${v.toFixed(2)}`},grid:{color:t.grid},title:{display:true,text:'ATR',color:t.muted,font:{size:9}}}},plugins:{legend:{display:false},tooltip:{mode:'index',intersect:false,backgroundColor:t.ttBg,titleColor:t.ttTitle,bodyColor:t.ttBody,borderColor:t.ttBorder,borderWidth:1,callbacks:{label:ctx3=>` ATR: $${Number(ctx3.raw||0).toFixed(2)}`}}}}});
}

function toggleInd(btn,ind) {
  const requirement=INDICATOR_REQUIREMENTS[ind];
  const bars=S.data?.timestamp?.length||0;
  if(requirement&&bars<requirement.bars){
    toast(`${requirement.label} needs ${requirement.bars} trading days. Choose a longer range.`,'red');
    return;
  }
  S.inds[ind]=!S.inds[ind]; btn.classList.toggle('on',S.inds[ind]); btn.setAttribute('aria-pressed',String(S.inds[ind]));
  document.querySelectorAll(`[data-ind="${ind}"], #ind-${ind}-btn`).forEach(control=>{
    control.classList.toggle('on',S.inds[ind]);
    control.setAttribute('aria-pressed',String(S.inds[ind]));
  });
  rebuildPriceChart();
}

async function changeRange(range,btn) {
  document.querySelectorAll('.tf-pill').forEach(p=>{const r=p.getAttribute('onclick')||'';const selected=r.includes("'"+range+"'");p.classList.toggle('on',selected);p.classList.remove('active');p.setAttribute('aria-pressed',String(selected));});
  document.querySelectorAll('.rpill').forEach(p=>{const r=p.getAttribute('onclick')||'';const selected=r.includes("'"+range+"'");p.classList.toggle('active',selected);p.setAttribute('aria-pressed',String(selected));});
  S.range=range;
  if(!S.ticker) return false;
  try {
    const result=await yahooFetch(S.ticker,range);
    const aligned=alignQuoteSeries(result);
    S.data=aligned.result;
    const q=aligned.quote;
    buildPriceChart(aligned.result,aligned.closes,aligned.timestamps);
    buildRSIChart(rsi(aligned.closes),aligned.timestamps);
    buildMACDChart(aligned.closes,aligned.timestamps);
    buildVolChart(q.volume,aligned.timestamps,aligned.closes);
    buildOBVChart(aligned.closes,q.volume,aligned.timestamps);
    buildATRChart(q.high||[],q.low||[],aligned.closes,aligned.timestamps);
    return true;
  } catch(e){ toast('Range unavailable','red'); return false; }
}

/* ══════════════════════════════════════════════════════
   PROJECTION
══════════════════════════════════════════════════════ */
function clearProjectionFeedback(errorId,resultId,chartId) {
  const error=document.getElementById(errorId);
  const results=document.getElementById(resultId);
  if(error){error.textContent='';error.classList.remove('show');}
  if(results) results.style.display='none';
  document.querySelectorAll('.projection-invalid').forEach(function(field){field.classList.remove('projection-invalid');});
  if(chartId) destroyChart(chartId);
}
function showProjectionError(errorId,message,fieldIds) {
  const error=document.getElementById(errorId);
  (fieldIds||[]).forEach(function(id){document.getElementById(id)?.classList.add('projection-invalid');});
  if(error){error.textContent=message;error.classList.add('show');}
  toast(message,'red');
}
function runProjection() {
  clearProjectionFeedback('proj-error','proj-results','proj-chart');
  if(!S.data){ showProjectionError('proj-error','Load a stock before calculating custom cases.'); return; }
  const price=parseFloat(document.getElementById('r-price').textContent.replace('$',''));
  const years=parseInt(document.getElementById('proj-years').value);
  const currentPE=Number(document.getElementById('proj-pe-now').value);
  const scenarios=[
    {key:'bear',l:'Bear',cls:'sc-bear'},
    {key:'base',l:'Base',cls:'sc-base'},
    {key:'bull',l:'Bull',cls:'sc-bull'},
  ];
  const invalidFields=[];
  if(!Number.isFinite(price)||price<=0) invalidFields.push('r-price');
  if(!Number.isFinite(currentPE)||currentPE<=0) invalidFields.push('proj-pe-now');
  scenarios.forEach(function(s){
    s.growth=Number(document.getElementById('proj-g-'+s.key).value)/100;
    s.exitPE=Number(document.getElementById('proj-pe-'+s.key).value);
    if(!Number.isFinite(s.growth)||s.growth<=-1) invalidFields.push('proj-g-'+s.key);
    if(!Number.isFinite(s.exitPE)||s.exitPE<=0) invalidFields.push('proj-pe-'+s.key);
  });
  if(invalidFields.length){
    showProjectionError('proj-error','Each custom case needs earnings growth above -100% and an exit P/E above 0.',invalidFields);
    return;
  }
  const results=scenarios.map(s=>{
    const model=ImpliedLensMath.projectScenario({price,currentPE,exitPE:s.exitPE,growth:s.growth,years});
    return{...s,model,price:model.ok?model.terminalPrice:NaN,tot:model.ok?model.totalReturn*100:NaN,cagr:model.ok?model.cagr*100:NaN};
  });
  const invalid=results.find(result=>!result.model.ok);
  if(invalid){showProjectionError('proj-error',invalid.model.error);return;}
  document.getElementById('scenario-cards').innerHTML=results.map(r=>`
    <div class="sc-card ${r.cls}">
      <div class="sc-lbl">${r.l} Case</div>
      <div class="sc-price">$${r.price.toFixed(2)}</div>
      <div class="sc-pct">${r.tot>=0?'+':''}${r.tot.toFixed(1)}% total</div>
      <div class="sc-irr">CAGR: ${r.cagr.toFixed(1)}% / yr · Exit P/E: ${r.exitPE.toFixed(1)}x</div>
    </div>`).join('');

  destroyChart('proj-chart');
  const labels=['Now',...Array.from({length:years},(_,i)=>`Year ${i+1}`)];
  const ds=results.map((r,i)=>({
    label:r.l,
    data:r.model.pricePath,
    borderColor:[cp().negative,cp().price,cp().positive][i],
    borderWidth:2,pointRadius:4,pointBackgroundColor:[cp().negative,cp().price,cp().positive][i],
    fill:false,tension:.3,
  }));
  ds.unshift({label:'Current Price',data:Array(years+1).fill(price),borderColor:isDark()?'rgba(255,255,255,.2)':'rgba(0,0,0,.2)',borderWidth:1.5,borderDash:[5,4],pointRadius:0,fill:false});
  S.charts['proj-chart']=new Chart(document.getElementById('proj-chart'),{
    type:'line',data:{labels,datasets:ds},
    options:(()=>{const _t=ct();return{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:true,position:'top',align:'end',labels:{color:_t.text,font:{size:10},boxWidth:18,boxHeight:2,usePointStyle:false,padding:10}},tooltip:{mode:'index',intersect:false,backgroundColor:_t.ttBg,titleColor:_t.ttTitle,bodyColor:_t.ttBody,borderColor:_t.ttBorder,borderWidth:1,callbacks:{label:ctx=>` ${ctx.dataset.label}: $${Number(ctx.raw).toFixed(2)}`}}},scales:{x:{ticks:{color:_t.text,font:{size:11}},grid:{color:_t.grid},title:{display:true,text:'Year',color:_t.muted,font:{size:9}}},y:{ticks:{color:_t.text,font:{size:10},callback:v=>`$${v.toFixed(0)}`},grid:{color:_t.grid},title:{display:true,text:'Price (USD)',color:_t.muted,font:{size:9}}}}}})()
  });
  document.getElementById('proj-results').style.display='block';
}

/* ══════════════════════════════════════════════════════
   COMPARE TAB
══════════════════════════════════════════════════════ */
async function runCompare() {
  const enteredTickers=['cmp1','cmp2','cmp3','cmp4']
    .map(id=>document.getElementById(id).value.trim().toUpperCase())
    .filter(Boolean);
  const tickers=[...new Set(enteredTickers)];
  if(tickers.length!==enteredTickers.length){ toast('Remove duplicate tickers before comparing','red'); return; }
  if(tickers.length<2){ toast('Enter at least 2 tickers','red'); return; }
  document.getElementById('cmp-loading').style.display='flex';
  document.getElementById('cmp-results').style.display='none';
  try {
    const [results, analystArr] = await Promise.all([
      Promise.all(tickers.map(t=>yahooFetch(t,'1y'))),
      Promise.all(tickers.map(t=>proAwareFetch('/api/analyst/'+encodeURIComponent(t),'compare').then(r=>r.json()).catch(()=>({}))))
    ]);
    const alignedResults=results.map(result=>alignQuoteSeries(result).result);
    buildCompareTable(tickers, alignedResults, analystArr);
    buildPerfChart(tickers, alignedResults);
    buildRadarChart(tickers, alignedResults, analystArr);
    document.getElementById('cmp-results').style.display='block';
  } catch(e){ toast('Failed to load one or more tickers','red'); }
  finally { document.getElementById('cmp-loading').style.display='none'; }
}

function buildCompareTable(tickers, results, analystArr=[]) {
  const metas=results.map(r=>r.meta);
  const closes=results.map(r=>r.indicators.quote[0].close.filter(x=>x!=null));
  const prices=metas.map(m=>m.regularMarketPrice||0);
  const prevs=metas.map(m=>m.previousClose||0);
  const dayChg=prices.map((p,i)=>((p-(prevs[i]||p))/(prevs[i]||p)*100));
  const yr1=closes.map(c=>c.length>1?((c[c.length-1]-c[0])/c[0]*100):0);
  const rsiVals=closes.map(c=>{const v=rsi(c);return v[v.length-1];});
  const stdDevs=closes.map(c=>ImpliedLensMath.annualizedVolatility(c,252)*100);
  // Merge analyst/Yahoo fundamental data per ticker
  const afds = analystArr.map(a => a.yahooFd || {});
  const getMarketCap = (m,afd) => (afd&&afd.marketCap) || m.marketCap || null;
  const getPE = (m,afd) => (afd&&afd.trailingPE) || m.trailingPE || null;
  const getForwardPE = (m,afd) => afd.forwardPE || m.forwardPE || null;
  const getPS = (m,afd) => afd.priceToSales || null;
  const rows=[
    {l:'Price',vals:prices.map(p=>`$${p.toFixed(2)}`),nums:prices,hi:true},
    {l:'Day Change',vals:dayChg.map(fmtPct),nums:dayChg,hi:true},
    {l:'1Y Return',vals:yr1.map(fmtPct),nums:yr1,hi:true},
    {l:'Market Cap',vals:metas.map((m,i)=>{const c=getMarketCap(m,afds[i]);return c?fmtBig(c):'—';}),nums:metas.map((m,i)=>getMarketCap(m,afds[i])||0),hi:true},
    {l:'52W High',vals:metas.map(m=>m.fiftyTwoWeekHigh?`$${m.fiftyTwoWeekHigh.toFixed(2)}`:'—'),nums:null,hi:false},
    {l:'52W Low',vals:metas.map(m=>m.fiftyTwoWeekLow?`$${m.fiftyTwoWeekLow.toFixed(2)}`:'—'),nums:null,hi:false},
    {l:'P/E (TTM)',vals:metas.map((m,i)=>{const pe=getPE(m,afds[i]);return pe?pe.toFixed(1)+'x':'—';}),nums:metas.map((m,i)=>{const pe=getPE(m,afds[i]);return pe||999;}),hi:false},
    {l:'Fwd P/E',vals:metas.map((m,i)=>{const pe=getForwardPE(m,afds[i]);return pe?pe.toFixed(1)+'x':'—';}),nums:metas.map((m,i)=>{const pe=getForwardPE(m,afds[i]);return pe||999;}),hi:false},
    {l:'P/S Ratio',vals:metas.map((m,i)=>{const ps=getPS(m,afds[i]);return ps?ps.toFixed(2)+'x':'—';}),nums:metas.map((m,i)=>{const ps=getPS(m,afds[i]);return ps||999;}),hi:false},
    {l:'RSI (14)',vals:rsiVals.map(r=>r?r.toFixed(1):'—'),nums:rsiVals.map(r=>r||50),hi:false},
    {l:'Volatility',vals:stdDevs.map(v=>`${v.toFixed(1)}%`),nums:stdDevs,hi:false},
    {l:'Exchange',vals:metas.map(m=>m.exchangeName||'—'),nums:null,hi:false},
  ];
  let html='<thead><tr><th>Metric</th>';
  tickers.forEach((t,i)=>{ html+=`<th class="cmp-hdr"><span class="t-dot" style="background:${COLORS[i]}"></span>${t}</th>`; });
  html+='</tr></thead><tbody>';
  rows.forEach(row=>{
    html+=`<tr><td>${row.l}</td>`;
    row.vals.forEach((v,i)=>{
      let cls='';
      if(row.nums){const nums=row.nums.filter(x=>x&&x>0&&x<900);const best=row.hi?Math.max(...nums):Math.min(...nums);const worst=row.hi?Math.min(...nums):Math.max(...nums);if(row.nums[i]===best)cls='td-best';else if(row.nums[i]===worst)cls='td-worst';}
      html+=`<td class="${cls}">${v}</td>`;
    });
    html+='</tr>';
  });
  html+='</tbody>';
  document.getElementById('cmp-table').innerHTML=html;
}

function buildPerfChart(tickers,results) {
  destroyChart('cmp-perf-chart');
  const el=document.getElementById('cmp-perf-chart'); if(!el)return;
  const allCloses=results.map(r=>r.indicators.quote[0].close.filter(x=>x!=null));
  const minLen=Math.min(...allCloses.map(c=>c.length));
  const labels=results[0].timestamp.slice(-minLen).map(ts=>new Date(ts*1000).toLocaleDateString('en-US',{month:'short',day:'numeric'}));
  const datasets=tickers.map((t,i)=>{
    const c=allCloses[i].slice(-minLen);
    const base=c[0];
    return{label:t,data:c.map(v=>parseFloat(((v-base)/base*100).toFixed(2))),borderColor:COLORS[i],borderWidth:2,pointRadius:0,fill:false,tension:.2};
  });
  const _pt=ct();
  var perfOpts=baseOpts({
    x:{ticks:{color:_pt.text,font:{size:10},maxTicksLimit:8},grid:{color:_pt.grid},title:{display:true,text:'Date',color:_pt.muted,font:{size:9}}},
    y:{ticks:{color:_pt.text,font:{size:10},callback:function(v){return (v>0?'+':'')+v.toFixed(0)+'%';}},grid:{color:_pt.grid},title:{display:true,text:'Return (%)',color:_pt.muted,font:{size:9}}}
  });
  perfOpts.plugins={legend:{display:true,position:'top',align:'end',labels:{color:_pt.text,font:{size:10},boxWidth:18,boxHeight:2,usePointStyle:false,padding:12}},tooltip:{mode:'index',intersect:false,backgroundColor:_pt.ttBg,titleColor:_pt.ttTitle,bodyColor:_pt.ttBody,borderColor:_pt.ttBorder,borderWidth:1,callbacks:{label:ctx=>` ${ctx.dataset.label}: ${ctx.raw>0?'+':''}${ctx.raw.toFixed(2)}%`}}};
  S.charts['cmp-perf-chart']=new Chart(el,{type:'line',data:{labels:labels,datasets:datasets},options:perfOpts});
}

function buildRadarChart(tickers, results, analystArr=[]) {
  destroyChart('cmp-radar-chart');
  const el=document.getElementById('cmp-radar-chart'); if(!el)return;
  const metas=results.map(r=>r.meta);
  const closes=results.map(r=>r.indicators.quote[0].close.filter(x=>x!=null));
  // Normalize 0-100: 1Y return, RSI, inverse volatility, inverse P/E, market cap rank
  const yr1=closes.map(c=>c.length>1?((c[c.length-1]-c[0])/c[0]*100):0);
  const rsiVals=closes.map(c=>{const v=rsi(c);return v[v.length-1]||50;});
  const vols=closes.map(c=>ImpliedLensMath.annualizedVolatility(c,252)*100);
  const afdsR=analystArr.map(a=>a.yahooFd||{});
  const caps=metas.map((m,i)=>afdsR[i].marketCap||m.marketCap||0);
  const pes=metas.map((m,i)=>afdsR[i].trailingPE||m.trailingPE||50);
  const norm=(arr,invert=false)=>{const mn=Math.min(...arr),mx=Math.max(...arr);return arr.map(v=>mx===mn?50:invert?(1-(v-mn)/(mx-mn))*100:((v-mn)/(mx-mn))*100);};
  const nYr1=norm(yr1); const nRsi=norm(rsiVals); const nVol=norm(vols,true); const nCap=norm(caps); const nPe=norm(pes,true);
  const datasets=tickers.map((t,i)=>({
    label:t,
    data:[nYr1[i],nRsi[i],nVol[i],nCap[i],nPe[i]].map(v=>Math.round(v)),
    borderColor:COLORS[i],backgroundColor:colorAlpha(COLORS[i],.12),
    borderWidth:2,pointRadius:3,
  }));
  S.charts['cmp-radar-chart']=new Chart(el,{
    type:'radar',data:{labels:['1Y Return','RSI','Low Vol','Mkt Cap','Value (P/E)'],datasets},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:true,position:'top',labels:{color:ct().text,font:{size:10},boxWidth:18,boxHeight:2,usePointStyle:false,padding:12}}},
      scales:{r:{min:0,max:100,ticks:{display:false},grid:{color:ct().grid},pointLabels:{color:ct().text,font:{size:10,weight:'500'}},angleLines:{color:ct().grid}}},
    }
  });
}
/* =====================================================
   DCF VALUATION
===================================================== */
function calcDCF(eps,g1,g2,tg,wacc) {
  return ImpliedLensMath.epsDcf({eps:eps,growth1:g1,growth2:g2,terminalGrowth:tg,discountRate:wacc});
}
function renderDCFOutput(result,currentPrice,elId) {
  var el=document.getElementById(elId);
  if(!result||!result.ok){el.innerHTML='<div style="color:#d96a70;font-size:.8rem;padding:.5rem;">'+(result?.error||'Check the model assumptions.')+'</div>';return;}
  var pvCF=result.pvCF,pvTv=result.pvTv,intrinsic=result.intrinsic;
  var upside=currentPrice>0?((intrinsic-currentPrice)/currentPrice*100):null;
  var mos=upside===null?'N/A':upside>20?'Undervalued':upside>-10?'Fairly Valued':'Overvalued';
  var mosClass=upside===null?'':upside>20?'up':upside>-10?'gold':'dn';
  var html='<div class="dcf-out">';
  html+='<div class="dcf-row"><span class="dcf-lbl">PV of Projected EPS (10yr)</span><span class="dcf-val">$'+pvCF.toFixed(2)+'</span></div>';
  html+='<div class="dcf-row"><span class="dcf-lbl">PV of Terminal Value</span><span class="dcf-val">$'+pvTv.toFixed(2)+'</span></div>';
  html+='<div class="dcf-row"><span class="dcf-lbl">Terminal Value Share</span><span class="dcf-val '+(result.terminalShare>.75?'dn':'')+'">'+(result.terminalShare*100).toFixed(1)+'%</span></div>';
  html+='<div class="dcf-row"><span class="dcf-lbl">Intrinsic Value (EPS-based)</span><span class="dcf-val gold">$'+intrinsic.toFixed(2)+'</span></div>';
  if(currentPrice>0){
    html+='<div class="dcf-row"><span class="dcf-lbl">Current Price</span><span class="dcf-val">$'+currentPrice.toFixed(2)+'</span></div>';
    html+='<div class="dcf-row"><span class="dcf-lbl">Upside / Downside</span><span class="dcf-val '+(upside>=0?'up':'dn')+'">'+(upside>=0?'+':'')+upside.toFixed(1)+'%</span></div>';
    html+='<div class="dcf-row"><span class="dcf-lbl">Assessment</span><span class="dcf-val '+mosClass+'">'+mos+'</span></div>';
  }
  html+='</div>';
  el.innerHTML=html;
}
function renderDCFSensitivity(eps,g1,g2,tg,wacc) {
  var el=document.getElementById('dcf-sensitivity');
  if(!el) return;
  var discountRates=[wacc-.02,wacc-.01,wacc,wacc+.01,wacc+.02];
  var terminalRates=[tg-.01,tg-.005,tg,tg+.005,tg+.01];
  var html='<div class="sensitivity-wrap"><table class="sensitivity-table"><caption>Sensitivity: intrinsic value by discount rate and terminal growth</caption><thead><tr><th>Discount \\ Terminal</th>';
  terminalRates.forEach(function(rate){html+='<th>'+((rate)*100).toFixed(1)+'%</th>';});
  html+='</tr></thead><tbody>';
  discountRates.forEach(function(discount){
    html+='<tr><th>'+((discount)*100).toFixed(1)+'%</th>';
    terminalRates.forEach(function(terminal){
      var result=calcDCF(eps,g1,g2,terminal,discount);
      var current=Math.abs(discount-wacc)<0.00001&&Math.abs(terminal-tg)<0.00001;
      html+='<td class="'+(current?'current':'')+'">'+(result.ok?'$'+result.intrinsic.toFixed(2):'--')+'</td>';
    });
    html+='</tr>';
  });
  html+='</tbody></table></div>';
  el.innerHTML=html;
}
function runDCF() {
  var eps=parseFloat(document.getElementById('dcf-eps').value)||0;
  var g1=parseFloat(document.getElementById('dcf-g1').value)/100||0;
  var g2=parseFloat(document.getElementById('dcf-g2').value)/100||0;
  var tg=parseFloat(document.getElementById('dcf-tg').value)/100||0;
  var wacc=parseFloat(document.getElementById('dcf-wacc').value)/100||0;
  var priceEl=document.getElementById('dcf-price').value;
  var cp=priceEl?parseFloat(priceEl):(S.data?parseFloat((document.getElementById('r-price')||{}).textContent||'0'):0);
  if(!eps){document.getElementById('dcf-output').innerHTML='<div style="color:#d96a70;font-size:.8rem;padding:.5rem;">Enter a positive starting EPS value.</div>';return;}
  renderDCFOutput(calcDCF(eps,g1,g2,tg,wacc),cp,'dcf-output');
  renderDCFSensitivity(eps,g1,g2,tg,wacc);
}
function runQuickDCF() {
  var eps=parseFloat(document.getElementById('qdcf-eps').value)||0;
  var g1=parseFloat(document.getElementById('qdcf-g1').value)/100||0;
  var g2=parseFloat(document.getElementById('qdcf-g2').value)/100||0;
  var tg=parseFloat(document.getElementById('qdcf-tg').value)/100||0;
  var wacc=parseFloat(document.getElementById('qdcf-wacc').value)/100||0;
  var cp=S.data?parseFloat((document.getElementById('r-price')||{}).textContent||'0'):0;
  if(!eps){document.getElementById('qdcf-output').innerHTML='<div style="color:#d96a70;font-size:.8rem;padding:.5rem;">Enter a positive starting EPS value.</div>';return;}
  renderDCFOutput(calcDCF(eps,g1,g2,tg,wacc),cp,'qdcf-output');
}

/* =====================================================
   ADVANCED PROJECTION MODEL
===================================================== */
function runAdvancedProjection() {
  clearProjectionFeedback('adv-proj-error','adv-proj-results','adv-proj-chart');
  var years=Number(document.getElementById('adv-years').value);
  var price0=Number(document.getElementById('adv-price').value);
  var peNow=Number(document.getElementById('adv-pe-now').value);
  var cases=[
    {key:'bear',l:'Bear',cls:'sc-bear',color:cp().negative},
    {key:'base',l:'Base',cls:'sc-base',color:cp().price},
    {key:'bull',l:'Bull',cls:'sc-bull',color:cp().positive},
  ];
  var scenarios=cases.map(function(s){
    return Object.assign({},s,{
      name:s.l,
      growth:Number(document.getElementById('adv-g-'+s.key).value)/100,
      exitPE:Number(document.getElementById('adv-pe-'+s.key).value),
      dividendYield:Number(document.getElementById('adv-div-'+s.key).value)/100,
      dividendGrowth:Number(document.getElementById('adv-div-g-'+s.key).value)/100,
      annualDilution:Number(document.getElementById('adv-dil-'+s.key).value)/100,
      probability:Number(document.getElementById('adv-prob-'+s.key).value)/100,
    });
  });
  var invalidFields=[];
  if(!Number.isFinite(price0)||price0<=0) invalidFields.push('adv-price');
  if(!Number.isFinite(peNow)||peNow<=0) invalidFields.push('adv-pe-now');
  scenarios.forEach(function(s){
    if(!Number.isFinite(s.growth)||s.growth<=-1) invalidFields.push('adv-g-'+s.key);
    if(!Number.isFinite(s.exitPE)||s.exitPE<=0) invalidFields.push('adv-pe-'+s.key);
    if(!Number.isFinite(s.dividendYield)||s.dividendYield<0) invalidFields.push('adv-div-'+s.key);
    if(!Number.isFinite(s.dividendGrowth)||s.dividendGrowth<=-1) invalidFields.push('adv-div-g-'+s.key);
    if(!Number.isFinite(s.annualDilution)||s.annualDilution<=-1) invalidFields.push('adv-dil-'+s.key);
    if(!Number.isFinite(s.probability)||s.probability<0||s.probability>1) invalidFields.push('adv-prob-'+s.key);
  });
  var probabilityTotal=scenarios.reduce(function(sum,s){return sum+s.probability;},0);
  if(Math.abs(probabilityTotal-1)>0.0001){
    scenarios.forEach(function(s){invalidFields.push('adv-prob-'+s.key);});
  }
  if(invalidFields.length){
    showProjectionError('adv-proj-error',Math.abs(probabilityTotal-1)>0.0001
      ? 'Probabilities must total 100%. Check the highlighted assumptions before calculating.'
      : 'Check the highlighted assumptions. Exit P/E and shared values must be above 0; growth and buybacks must remain above -100%.',invalidFields);
    updateScenarioProbabilityStatus();
    return;
  }
  var projection=ImpliedLensMath.projectCases({price:price0,currentPE:peNow,years:years,scenarios:scenarios});
  updateScenarioProbabilityStatus();
  if(!projection.ok){showProjectionError('adv-proj-error',projection.error);return;}
  var results=projection.scenarios.map(function(result){
    return Object.assign({},result,{
      l:result.name,priceN:result.model.terminalPrice,divTotal:result.model.dividends,
      totalReturn:result.model.totalValue,tot:result.model.totalReturn*100,cagr:result.model.cagr*100,
    });
  });
  document.getElementById('adv-expected-value').innerHTML=[
    ['Expected total value','$'+projection.expectedTotalValue.toFixed(2)],
    ['Expected terminal price','$'+projection.expectedTerminalPrice.toFixed(2)],
    ['Expected total return',(projection.expectedTotalReturn>=0?'+':'')+(projection.expectedTotalReturn*100).toFixed(1)+'%'],
    ['Expected CAGR',(projection.expectedCagr*100).toFixed(1)+'% / yr'],
  ].map(function(item){return '<div class="expected-value-metric"><span>'+item[0]+'</span><strong>'+item[1]+'</strong></div>';}).join('');
  document.getElementById('adv-scenario-cards').innerHTML=results.map(function(r){
    return '<div class="sc-card '+r.cls+'">'
      +'<div class="sc-lbl">'+r.l+' Case &middot; '+(r.probability*100).toFixed(0)+'%</div>'
      +'<div class="sc-price">$'+r.priceN.toFixed(2)+'</div>'
      +'<div class="sc-pct">'+(r.tot>=0?'+':'')+r.tot.toFixed(1)+'% total</div>'
      +'<div class="sc-irr">CAGR: '+r.cagr.toFixed(1)+'%/yr &middot; Dividends: $'+r.divTotal.toFixed(2)+'</div>'
      +'</div>';
  }).join('');
  destroyChart('adv-proj-chart');
  var labels=['Now'];
  for(var y=1;y<=years;y++) labels.push('Yr '+y);
  var datasets=results.map(function(r){
    return{label:r.l,data:r.model.totalValuePath.map(function(value){return parseFloat(value.toFixed(2));}),borderColor:r.color,borderWidth:2,pointRadius:4,pointBackgroundColor:r.color,fill:false,tension:.3};
  });
  datasets.push({label:'Expected value',data:projection.expectedTotalValuePath.map(function(value){return parseFloat(value.toFixed(2));}),borderColor:cp().price,borderWidth:2.5,borderDash:[5,4],pointRadius:0,fill:false,tension:.3});
  datasets.unshift({label:'Cost Basis',data:Array(years+1).fill(price0),borderColor:isDark()?'rgba(255,255,255,.2)':'rgba(0,0,0,.2)',borderWidth:1.5,borderDash:[5,4],pointRadius:0,fill:false});
  S.charts['adv-proj-chart']=new Chart(document.getElementById('adv-proj-chart'),{
    type:'line',data:{labels:labels,datasets:datasets},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:(()=>{const _t=ct();return{legend:{display:true,position:'top',align:'end',labels:{color:_t.text,font:{size:10},boxWidth:12,usePointStyle:true,pointStyleWidth:8,padding:8}},tooltip:{mode:'index',intersect:false,backgroundColor:_t.ttBg,titleColor:_t.ttTitle,bodyColor:_t.ttBody,borderColor:_t.ttBorder,borderWidth:1,callbacks:{label:ctx=>` ${ctx.dataset.label}: $${Number(ctx.raw).toFixed(2)}`}}};})(),
      scales:(()=>{const _t=ct();return{x:{ticks:{color:_t.text,font:{size:11}},grid:{color:_t.grid},title:{display:true,text:'Year',color:_t.muted,font:{size:9}}},y:{ticks:{color:_t.text,font:{size:10},callback:function(v){return '$'+v.toFixed(0);}},grid:{color:_t.grid},title:{display:true,text:'Total value (USD)',color:_t.muted,font:{size:9}}}};})()}
  });
  var irrHtml='<div class="dcf-out"><div class="dcf-row" style="background:var(--t-acc-header-bg);"><span class="dcf-lbl" style="font-weight:600;color:var(--text3);">Scenario</span><span class="dcf-val" style="font-weight:600;">Price</span><span class="dcf-val" style="font-weight:600;">Total Return</span><span class="dcf-val" style="font-weight:600;">CAGR</span></div>';
  results.forEach(function(r){
    irrHtml+='<div class="dcf-row"><span class="dcf-lbl">'+r.l+'</span><span class="dcf-val">$'+r.priceN.toFixed(2)+'</span><span class="dcf-val '+(r.tot>=0?'up':'dn')+'">'+(r.tot>=0?'+':'')+r.tot.toFixed(1)+'%</span><span class="dcf-val">'+r.cagr.toFixed(1)+'%/yr</span></div>';
  });
  irrHtml+='</div>';
  document.getElementById('adv-irr-table').innerHTML=irrHtml;
  document.getElementById('adv-proj-results').style.display='block';
}
function updateScenarioProbabilityStatus() {
  var status=document.getElementById('adv-prob-status');
  if(!status) return;
  var total=['bear','base','bull'].reduce(function(sum,key){return sum+(Number(document.getElementById('adv-prob-'+key)?.value)||0);},0);
  status.textContent='Probabilities total '+total.toFixed(0)+'%'+(Math.abs(total-100)<0.01?'':' - adjust to 100% before calculating');
  status.classList.toggle('invalid',Math.abs(total-100)>=0.01);
}
document.addEventListener('input',function(event){
  if(!event.target || !event.target.id) return;
  var id=event.target.id;
  if(id.indexOf('proj-')===0 || id.indexOf('adv-')===0){
    event.target.dataset.userEdited='true';
    event.target.classList.remove('projection-invalid');
    if(id.indexOf('adv-')===0){
      const advancedResults=document.getElementById('adv-proj-results');
      const advancedError=document.getElementById('adv-proj-error');
      if(advancedResults) advancedResults.style.display='none';
      if(advancedError) advancedError.classList.remove('show');
    } else {
      const quickResults=document.getElementById('proj-results');
      const quickError=document.getElementById('proj-error');
      if(quickResults) quickResults.style.display='none';
      if(quickError) quickError.classList.remove('show');
    }
  }
  if(id.indexOf('adv-prob-')===0) updateScenarioProbabilityStatus();
});

/* =====================================================
   STOCK SCREENER
===================================================== */
var screenerLoaded=false;
async function loadScreener() {
  if(screenerLoaded && S.screenerData) {
    applyScreener();
    return;
  }
  var loading=document.getElementById('scr-loading');
  if(loading) loading.style.display='flex';
  try {
    var r=await fetch('/api/screener');
    if(!r.ok) throw new Error('Screener request failed ('+r.status+')');
    S.screenerData=await r.json();
    screenerLoaded=true;
    applyScreener();
  } catch(e){ toast('Screener load failed','red'); }
  finally {
    loading=document.getElementById('scr-loading');
    if(loading) loading.style.display='none';
  }
}
function applyScreener() {
  if(!S.screenerData) return;
  var peEl=document.getElementById('scr-pe');
  var pbEl=document.getElementById('scr-pb');
  var divEl=document.getElementById('scr-div');
  var capEl=document.getElementById('scr-cap');
  var retEl=document.getElementById('scr-ret');
  var tbody=document.getElementById('scr-body');
  if(!peEl||!pbEl||!divEl||!capEl||!retEl||!tbody) return;
  var maxPE=parseFloat(peEl.value);
  var maxPB=parseFloat(pbEl.value);
  var minDiv=parseFloat(divEl.value);
  var minCap=parseFloat(capEl.value)*1e9;
  var minRet=parseFloat(retEl.value);
  var sectorEl=document.getElementById('scr-sector');
  var sector=sectorEl?sectorEl.value:'ALL';
  var filtered=S.screenerData.filter(function(s){
    if(s.pe!=null && s.pe>0 && s.pe>maxPE) return false;
    if(s.pb!=null && s.pb>0 && s.pb>maxPB) return false;
    if((s.dividendYield||0)<minDiv) return false;
    if(s.marketCap!=null && s.marketCap<minCap) return false;
    if(s.change1Y!=null && s.change1Y<minRet) return false;
    if(sector!=='ALL' && (s.sector||'')!==sector) return false;
    return true;
  });
  var col=S.screenerSort.col, dir=S.screenerSort.dir;
  filtered.sort(function(a,b){
    var av=a[col]!=null?a[col]:-Infinity, bv=b[col]!=null?b[col]:-Infinity;
    if(typeof av==='string') return dir*av.localeCompare(bv);
    return dir*(av-bv);
  });
  var count=document.getElementById('scr-result-count');
  if(count) count.textContent=filtered.length+' of '+S.screenerData.length+' stocks match the current filters';
  renderScreenerTable(filtered);
}
function resetScreener() {
  var defaults={ 'scr-sector':'ALL','scr-pe':'50','scr-pb':'20','scr-div':'0','scr-cap':'0','scr-ret':'-50' };
  Object.keys(defaults).forEach(function(id){var el=document.getElementById(id);if(el) el.value=defaults[id];});
  document.getElementById('scr-pe-val').textContent='50x';
  document.getElementById('scr-pb-val').textContent='20x';
  document.getElementById('scr-div-val').textContent='0%';
  document.getElementById('scr-cap-val').textContent='$0B';
  document.getElementById('scr-ret-val').textContent='-50%';
  S.screenerSort={col:'marketCap',dir:-1};
  applyScreener();
}
function loadFromScreener(el){var t=el.getAttribute('data-ticker');if(t){quickLoad(t);navGoTo('analyze');}}
function sortScreener(col) {
  if(S.screenerSort.col===col) S.screenerSort.dir*=-1;
  else { S.screenerSort.col=col; S.screenerSort.dir=-1; }
  document.querySelectorAll('.scr-sort-btn').forEach(function(btn){
    if(btn.dataset.sort===col) btn.setAttribute('aria-sort',S.screenerSort.dir===1?'ascending':'descending');
    else btn.removeAttribute('aria-sort');
  });
  applyScreener();
}
function renderScreenerTable(stocks) {
  var tbody=document.getElementById('scr-body');
  if(!tbody) return;
  if(!stocks.length){tbody.innerHTML='<tr><td colspan="11" style="text-align:center;color:var(--text5);padding:2rem;">No stocks match the current filters.</td></tr>';return;}
  tbody.innerHTML=stocks.map(function(s){
    var chg1D=s.change1D||0;
    var chg1Y=s.change1Y;
    var revGr=s.revenueGrowth;
    var cap=s.marketCap?fmtBig(s.marketCap):'--';
    var ticker=escapeHtml(s.ticker||'');
    var sector=escapeHtml(s.sector||'--');
    var revGrStr=revGr==null?'--':(revGr>0?'<span style="color:var(--market-up)">+'+revGr.toFixed(1)+'%</span>':'<span style="color:var(--market-down)">'+revGr.toFixed(1)+'%</span>');
    var signal=chg1Y==null?'--':chg1Y>20?'<span class="tag tag-up">Bullish</span>':chg1Y<-15?'<span class="tag tag-dn">Bearish</span>':'<span class="tag tag-neu">Neutral</span>';
    return '<tr role="button" tabindex="0" aria-label="Analyze '+ticker+'" style="cursor:pointer" onclick="loadFromScreener(this)" onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();loadFromScreener(this)}" data-ticker="'+ticker+'">'
      +'<td><span class="scr-ticker">'+ticker+'</span></td>'
      +'<td>$'+(s.price||0).toFixed(2)+'</td>'
      +'<td style="color:'+(chg1D>=0?'var(--market-up)':'var(--market-down)')+'">'+(chg1D>=0?'+':'')+chg1D.toFixed(2)+'%</td>'
      +'<td style="color:'+(chg1Y==null?'inherit':chg1Y>=0?'var(--market-up)':'var(--market-down)')+'">'+(chg1Y!=null?(chg1Y>=0?'+':'')+chg1Y.toFixed(1)+'%':'--')+'</td>'
      +'<td>'+revGrStr+'</td>'
      +'<td style="font-size:.72rem;color:var(--text4)">'+sector+'</td>'
      +'<td>'+cap+'</td>'
      +'<td>'+(s.pe!=null&&s.pe>0?s.pe.toFixed(1)+'x':'--')+'</td>'
      +'<td>'+(s.pb!=null&&s.pb>0?s.pb.toFixed(1)+'x':'--')+'</td>'
      +'<td>'+(s.dividendYield!=null?s.dividendYield.toFixed(2)+'%':'--')+'</td>'
      +'<td>'+(s.beta!=null?s.beta.toFixed(2):'--')+'</td>'
      +'</tr>';
  }).join('');
}


/* =====================================================
   RISK PANEL
===================================================== */
function renderRiskPanel(closes, meta) {
  const el = document.getElementById('risk-content');
  if (!el || !closes || closes.length < 20) return;

  // Daily returns
  const returns = [];
  for (let i = 1; i < closes.length; i++) {
    if (closes[i-1] > 0) returns.push((closes[i] - closes[i-1]) / closes[i-1] * 100);
  }
  if (!returns.length) return;

  const n = returns.length;
  const mean   = returns.reduce((a,b) => a+b, 0) / n;
  const variance = returns.reduce((a,b) => a + Math.pow(b - mean, 2), 0) / Math.max(1,n-1);
  const stdDev = Math.sqrt(variance);
  const annualVol = (stdDev * Math.sqrt(252)).toFixed(1);
  const annualReturn = ((Math.pow(closes[closes.length-1]/closes[0],252/n)-1)*100).toFixed(1);

  // Risk-free rate ~4.5% annual → 0.01746 daily
  const rfDaily = 0.01746;
  const rfAnnual = 4.5;

  // Sharpe ratio
  const sharpe = stdDev > 0 ? (((mean - rfDaily) * 252) / (stdDev * Math.sqrt(252))).toFixed(2) : '--';

  // Sortino ratio (downside deviation)
  const downReturns = returns.filter(r => r < rfDaily);
  const downVar = downReturns.length > 0 ? downReturns.reduce((a,b) => a + Math.pow(b - rfDaily, 2), 0) / downReturns.length : 0;
  const downDev = Math.sqrt(downVar);
  const sortino = downDev > 0 ? (((mean - rfDaily) * 252) / (downDev * Math.sqrt(252))).toFixed(2) : '--';

  // Max drawdown & Calmar ratio
  let peak = closes[0], maxDDraw = 0;
  for (const c of closes) { if (c > peak) peak = c; maxDDraw = Math.min(maxDDraw, (c - peak) / peak * 100); }
  const maxDD = maxDDraw.toFixed(1);
  const calmar = maxDDraw < 0 ? (parseFloat(annualReturn) / Math.abs(maxDDraw)).toFixed(2) : '--';

  // Beta
  const betaRaw = meta.beta ? Number(meta.beta) : null;
  const beta = betaRaw != null ? betaRaw.toFixed(2) : '--';

  // Alpha (Jensen's) = annualReturn - [rfAnnual + beta*(marketReturn - rfAnnual)]
  // Assume S&P 500 long-run ~10% annual
  const marketReturn = 10;
  const alpha = betaRaw != null
    ? (parseFloat(annualReturn) - (rfAnnual + betaRaw * (marketReturn - rfAnnual))).toFixed(2)
    : '--';

  // Treynor ratio = (annualReturn - rfAnnual) / beta
  const treynor = betaRaw != null && betaRaw !== 0
    ? ((parseFloat(annualReturn) - rfAnnual) / betaRaw).toFixed(2)
    : '--';

  // VaR & CVaR (95% confidence, historical)
  const sortedR = [...returns].sort((a,b) => a - b);
  const var95Idx = Math.floor(n * 0.05);
  const var95 = sortedR[var95Idx]?.toFixed(2) || '--';
  const cvar95 = var95Idx > 0
    ? (sortedR.slice(0, var95Idx).reduce((a,b) => a+b, 0) / var95Idx).toFixed(2)
    : var95;

  // Mirror key stats into sidebar-risk
  const sideRisk = document.getElementById('sidebar-risk');
  const sideRiskContent = document.getElementById('sidebar-risk-content');
  if (sideRisk && sideRiskContent) {
    sideRisk.style.display = 'block';
    sideRiskContent.innerHTML = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:.72rem;">
        <div><div style="color:var(--text5);">Ann. Volatility</div><div style="font-weight:700;color:${parseFloat(annualVol)<25?'#46b184':'#d96a70'};">${annualVol}%</div></div>
        <div><div style="color:var(--text5);">Ann. Return</div><div style="font-weight:700;color:${parseFloat(annualReturn)>=0?'#46b184':'#d96a70'};">${annualReturn}%</div></div>
        <div><div style="color:var(--text5);">Max Drawdown</div><div style="font-weight:700;color:${parseFloat(maxDD)>-20?'#46b184':'#d96a70'};">${maxDD}%</div></div>
        <div><div style="color:var(--text5);">Sharpe</div><div style="font-weight:700;color:${parseFloat(sharpe)>0.5?'#46b184':parseFloat(sharpe)<0?'#d96a70':'#C6A052'};">${sharpe}</div></div>
        <div><div style="color:var(--text5);">Beta</div><div style="font-weight:700;">${beta}</div></div>
        <div><div style="color:var(--text5);">VaR 95%</div><div style="font-weight:700;color:#d96a70;">${var95}%</div></div>
      </div>`;
  }
  const col = v => parseFloat(v) >= 0 ? 'var(--market-up)' : 'var(--market-down)';
  const posCol = v => { const f=parseFloat(v); return isNaN(f)?'var(--text4)':f>=0?'var(--market-up)':'var(--market-down)'; };
  const ratingScore = [parseFloat(annualVol) < 25, maxDDraw > -20, parseFloat(sharpe) > 0.5].filter(Boolean).length;
  const rating = ['High Risk','Moderate Risk','Moderate','Low–Moderate Risk'][ratingScore] || 'Moderate';
  const ratingColor = ['var(--market-down)','#C6A052','#C6A052','var(--market-up)'][ratingScore] || '#C6A052';

  const stat = (label, val, valColor, note='') =>
    `<div class="risk-stat">
      <div class="risk-stat-label">${label}${note?`<span style="font-size:.6rem;color:var(--text5);margin-left:4px;">${note}</span>`:''}</div>
      <div class="risk-stat-val" style="color:${valColor}">${val}</div>
    </div>`;

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
      ${stat('Annual Volatility', annualVol+'%', parseFloat(annualVol)<25?'#46b184':parseFloat(annualVol)<45?'#C6A052':'#d96a70')}
      ${stat('Annual Return', annualReturn+'%', posCol(annualReturn), 'est.')}
      ${stat('Beta', beta, betaRaw!=null?(betaRaw<0.8?'#46b184':betaRaw>1.4?'#d96a70':'var(--gold)'):'var(--text4)')}
      ${stat('Alpha', alpha!=='--'?alpha+'%':'--', posCol(alpha), 'vs S&P 500')}
      ${stat('Sharpe Ratio', sharpe, posCol(sharpe), 'rf 4.5%')}
      ${stat('Sortino Ratio', sortino, posCol(sortino), 'downside')}
      ${stat('Treynor Ratio', treynor!=='--'?treynor+'%':'--', posCol(treynor))}
      ${stat('Calmar Ratio', calmar, posCol(calmar), '1Y')}
      ${stat('Max Drawdown', maxDD+'%', '#d96a70')}
      ${stat('1-Day VaR 95%', var95!=='--'?var95+'%':'--', '#d96a70')}
      ${stat('CVaR (ES) 95%', cvar95!=='--'?cvar95+'%':'--', '#d96a70', 'avg tail')}
      ${stat('Risk Rating', rating, ratingColor)}
    </div>`;
}

/* =====================================================
   NEWS
===================================================== */
async function renderNews(ticker, name) {
  const el = document.getElementById('news-items');
  if (!el) return;
  el.innerHTML = '<div style="color:var(--text5);font-size:.78rem;">Loading news…</div>';
  try {
    const res  = await fetch('/api/news/' + ticker, { credentials: 'same-origin' });
    const data = await res.json();
    if (!Array.isArray(data) || !data.length) {
      el.innerHTML = '<div style="color:var(--text5);font-size:.78rem;">No recent news found.</div>';
      return;
    }
    const POS_WORDS = /surges?|soars?|beats?|strong|rises?|record|gains?|upgrades?|bullish|profit|growth|rally|buy|outperform|expands?|exceeds?/i;
    const NEG_WORDS = /falls?|drops?|misses?|weak|loss|declines?|downgrades?|bearish|plunges?|cuts?|layoffs?|sell|underperform|concerns?|risks?|disappoints?/i;
    el.innerHTML = data.slice(0, 8).map(item => {
      const h = item.headline || 'No title';
      let cls = 'news-neu';
      if (item.sentiment === 'positive' || POS_WORDS.test(h)) cls = 'news-pos';
      else if (item.sentiment === 'negative' || NEG_WORDS.test(h)) cls = 'news-neg';
      const url = safeExternalUrl(item.url);
      if (!url) return '';
      return `<a class="news-item ${cls}" href="${url}" target="_blank" rel="noopener noreferrer">
        <div class="news-headline">${escapeHtml(h)}</div>
        <div class="news-meta">${escapeHtml(item.source || '')} · ${item.datetime ? new Date(item.datetime * 1000).toLocaleDateString() : ''}</div>
      </a>`;
    }).join('');
  } catch(e) {
    el.innerHTML = '<div style="color:var(--text5);font-size:.78rem;">News unavailable.</div>';
  }
}

/* =====================================================
   FINANCIALS TAB
===================================================== */
async function loadFinancials(ticker) {
  const loading = document.getElementById('fin-loading');
  const error   = document.getElementById('fin-error');
  const cont    = document.getElementById('fin-content');
  const nostock = document.getElementById('fin-nostock');
  if (!ticker) { if(nostock) nostock.style.display='block'; if(cont) cont.style.display='none'; return; }
  if(nostock) nostock.style.display='none';
  if(loading) loading.style.display='block';
  if(error)   error.style.display='none';
  if(cont)    cont.style.display='none';
  try {
    const res  = await proAwareFetch('/api/financials/' + ticker, 'financials');
    const data = await res.json();
    showDataSource('fin-source', data.impliedLens, 'SEC EDGAR XBRL');

    // ETF / fund: no XBRL statements available
    if (data.noStatements) {
      if(loading) loading.style.display='none';
      if(error) { error.textContent = `Financial statements are not available for ${ticker} — this is likely an ETF or fund. Use the Metrics tab for key statistics.`; error.style.display='block'; }
      return;
    }

    const r    = data.quoteSummary && data.quoteSummary.result && data.quoteSummary.result[0];
    if (!r) throw new Error('No data');
    if (window.S) S.financialsRaw = r;   // cache for Projection Lab seeding
    if (document.getElementById('sec-projection')?.classList.contains('open')) { try { mountProjectionLab(); } catch(e){} }
    const inc  = (r.incomeStatementHistory  && r.incomeStatementHistory.incomeStatementHistory  && r.incomeStatementHistory.incomeStatementHistory.length  ? r.incomeStatementHistory.incomeStatementHistory  : (r.incomeStatementHistoryQuarterly  && r.incomeStatementHistoryQuarterly.incomeStatementHistory))  || [];
    const bal  = (r.balanceSheetHistory     && r.balanceSheetHistory.balanceSheetStatements     && r.balanceSheetHistory.balanceSheetStatements.length     ? r.balanceSheetHistory.balanceSheetStatements     : (r.balanceSheetHistoryQuarterly     && r.balanceSheetHistoryQuarterly.balanceSheetStatements))     || [];
    const cf   = (r.cashflowStatementHistory && r.cashflowStatementHistory.cashflowStatements   && r.cashflowStatementHistory.cashflowStatements.length    ? r.cashflowStatementHistory.cashflowStatements    : (r.cashflowStatementHistoryQuarterly && r.cashflowStatementHistoryQuarterly.cashflowStatements))    || [];

    function fmt(v){
      if(v==null) return '—';
      const n = (v.raw!=null) ? v.raw : (typeof v==='number' ? v : null);
      if(n==null||isNaN(n)) return '—';
      if(Math.abs(n)>=1e9) return '$'+(n/1e9).toFixed(2)+'B';
      if(Math.abs(n)>=1e6) return '$'+(n/1e6).toFixed(1)+'M';
      if(Math.abs(n)>=1e3) return '$'+(n/1e3).toFixed(0)+'K';
      return '$'+n.toFixed(2);
    }
    function fmtPct(v){
      if(v==null) return '—';
      const n = (v.raw!=null) ? v.raw : (typeof v==='number' ? v : null);
      if(n==null||isNaN(n)) return '—';
      return (n*100).toFixed(1)+'%';
    }

    function getRaw(v){ return v==null ? null : (v.raw!=null ? v.raw : (typeof v==='number' ? v : null)); }

    function buildTable(rows, statements) {
      if (!statements.length) return '<div style="color:var(--text5);font-size:.8rem;">No data available.</div>';
      const years = statements.map(s => s.endDate ? (s.endDate.fmt ? s.endDate.fmt.slice(0,4) : String(s.endDate).slice(0,4)) : '');
      let html = '<div style="overflow-x:auto;"><table class="fin-table"><thead><tr><th>Item</th>' + years.map(y=>'<th>'+y+'</th>').join('') + '</tr></thead><tbody>';
      for (const row of rows) {
        const cls = row.header ? ' class="fin-row-header"' : '';
        html += '<tr'+cls+'><td>'+(row.label||'')+'</td>';
        for (const stmt of statements) {
          let rawObj = row.key ? stmt[row.key] : null;
          // support computed rows
          if (!rawObj && row.compute) rawObj = row.compute(stmt);
          let val = rawObj ? fmt(rawObj) : '—';
          if (row.pct && rawObj) val = fmtPct(rawObj);
          const rawNum = getRaw(rawObj);
          const color = (rawNum!=null && rawNum < 0) ? ' class="fin-negative"' : (rawNum!=null && rawNum > 0 && row.highlight) ? ' class="fin-positive"' : '';
          html += '<td'+color+'>'+val+'</td>';
        }
        html += '</tr>';
      }
      html += '</tbody></table></div>';
      return html;
    }

    const incRows = [
      {label:'Total Revenue',           key:'totalRevenue'},
      {label:'Cost of Revenue',         key:'costOfRevenue'},
      {label:'Gross Profit',            key:'grossProfit',  highlight:true},
      {label:'Operating Expense',       key:'totalOperatingExpenses'},
      {label:'Operating Income',        key:'operatingIncome', highlight:true},
      {label:'Net Income',              key:'netIncome',    highlight:true},
      {label:'EPS (Basic)',             key:'basicEps'},
      {label:'EPS (Diluted)',           key:'dilutedEps'},
    ];
    const balRows = [
      {label:'Cash & Equivalents',      key:'cash',               highlight:true},
      {label:'Short-term Investments',  key:'shortTermInvestments'},
      {label:'Total Current Assets',    key:'totalCurrentAssets'},
      {label:'Total Assets',            key:'totalAssets'},
      {label:'Short-term Debt',         key:'shortLongTermDebt'},
      {label:'Long-term Debt',          key:'longTermDebt'},
      {label:'Total Liabilities',       key:'totalLiab'},
      {label:'Shareholder Equity',      key:'totalStockholderEquity', highlight:true},
    ];
    const cfRows = [
      {label:'Operating Cash Flow',     key:'totalCashFromOperatingActivities', highlight:true},
      {label:'Capital Expenditures',    key:'capitalExpenditures'},
      {label:'Free Cash Flow',          highlight:true,
        compute: s => {
          const op = getRaw(s.totalCashFromOperatingActivities);
          const cx = getRaw(s.capitalExpenditures);
          if (op==null || cx==null) return null;
          return op - Math.abs(cx); // SEC XBRL capex is generally reported as a positive cash outflow
        }
      },
      {label:'Investing Activities',    key:'totalCashflowsFromInvestingActivities'},
      {label:'Financing Activities',    key:'totalCashFromFinancingActivities'},
      {label:'Net Change in Cash',      key:'changeInCash'},
    ];

    document.getElementById('fin-income').innerHTML   = buildTable(incRows, inc);
    document.getElementById('fin-balance').innerHTML  = buildTable(balRows, bal);
    document.getElementById('fin-cashflow').innerHTML = buildTable(cfRows,  cf);

    if(loading) loading.style.display='none';
    if(cont)    cont.style.display='block';
  } catch(e) {
    if(loading) loading.style.display='none';
    handleSectionError(e, 'financials', cont);
    if(e.code !== 'PRO_REQUIRED' && e.code !== 'LOGIN_REQUIRED') console.error('financials error', e);
  }
}

let _finTab = 'income';
function showFinTab(name, btn) {
  _finTab = name;
  document.querySelectorAll('.fin-tab-btn').forEach(b => {
    b.classList.remove('active');
    b.style.background = '';
    b.style.color = '';
  });
  if(btn) { btn.classList.add('active'); }
  document.querySelectorAll('.fin-subtab').forEach(d => d.style.display='none');
  const el = document.getElementById('fin-'+name);
  if(el) el.style.display='block';
}

/* =====================================================
   ADVANCED METRICS TAB
===================================================== */
async function loadAdvMetrics(ticker) {
  const cont    = document.getElementById('advm-content');
  const loading = document.getElementById('advm-loading');
  const error   = document.getElementById('advm-error');
  const nostock = document.getElementById('advm-nostock');
  if (!ticker) { if(nostock) nostock.style.display='block'; return; }
  if(nostock) nostock.style.display='none';
  if(loading) loading.style.display='block';
  if(error)   error.style.display='none';
  try {
    const [finResult, metResult] = await Promise.allSettled([
      proAwareFetch('/api/financials/' + ticker, 'advmetrics'),
      proAwareFetch('/api/metrics/' + ticker, 'advmetrics'),
    ]);
    if (finResult.status === 'rejected' && metResult.status === 'rejected') throw finResult.reason;
    const finData = finResult.status === 'fulfilled' ? await finResult.value.json() : {};
    const metData = metResult.status === 'fulfilled' ? await metResult.value.json() : {};
    showDataSource(
      'advm-source',
      metData.impliedLens || finData.impliedLens,
      'SEC EDGAR XBRL + Finnhub metrics'
    );
    // finData may be a noStatements (ETF) response or a full quoteSummary response
    const r = finData.quoteSummary && finData.quoteSummary.result && finData.quoteSummary.result[0];
    const ks  = (r && r.defaultKeyStatistics) || {};
    const fd  = (r && r.financialData)        || {};
    // Prefer Finnhub metric data; merge in any finData.metric (ETF path) too
    const m   = Object.assign({}, finData.metric || {}, metData.metric || {});

    function v(val, suffix, decimals=2) {
      if (val == null || val === '' || isNaN(val)) return '—';
      const n = parseFloat(val);
      if (isNaN(n)) return '—';
      if (suffix === 'x') return n.toFixed(decimals) + 'x';
      if (suffix === '%') return n.toFixed(decimals) + '%';
      if (suffix === 'B') return '$' + n.toFixed(2) + 'B';
      if (suffix === 'M') return '$' + n.toFixed(0) + 'M';
      return n.toFixed(decimals);
    }
    function raw(obj) { return obj && obj.raw != null ? obj.raw : null; }

    const sections = [
      {
        title: 'Valuation Multiples',
        cards: [
          {lbl:'EV / EBITDA',     val:v(raw(ks.enterpriseToEbitda),'x'), sub:'Enterprise Value basis'},
          {lbl:'EV / Revenue',    val:v(raw(ks.enterpriseToRevenue),'x'), sub:'Enterprise Value basis'},
          {lbl:'P/E (TTM)',        val:v(raw(ks.trailingPE)!=null?raw(ks.trailingPE):m['peNormalizedAnnual'],'x'), sub:'Price to earnings'},
          {lbl:'Forward P/E',     val:v(raw(ks.forwardPE),'x'), sub:'Next 12 months est.'},
          {lbl:'Price / Book',    val:v(raw(ks.priceToBook),'x'), sub:'P/B ratio'},
          {lbl:'Price / Sales',   val:v(m['psTTM']!=null?m['psTTM']:raw(ks.priceToSalesTrailing12Months),'x'), sub:'TTM'},
        ]
      },
      {
        title: 'Profitability & Returns',
        cards: [
          {lbl:'Gross Margin',    val:v(raw(fd.grossMargins)!=null ? raw(fd.grossMargins)*100 : null,'%'), sub:'Revenue − COGS'},
          {lbl:'Operating Margin',val:v(raw(fd.operatingMargins)!=null ? raw(fd.operatingMargins)*100 : null,'%'), sub:'Operating income / revenue'},
          {lbl:'Net Margin',      val:v(raw(fd.profitMargins)!=null ? raw(fd.profitMargins)*100 : null,'%'), sub:'Net income / revenue'},
          {lbl:'Return on Equity',val:v(raw(fd.returnOnEquity)!=null ? raw(fd.returnOnEquity)*100 : null,'%'), sub:'ROE'},
          {lbl:'Return on Assets',val:v(raw(fd.returnOnAssets)!=null ? raw(fd.returnOnAssets)*100 : null,'%'), sub:'ROA'},
          {lbl:'ROIC',            val:v(m['roicTTM']!=null?m['roicTTM']:raw(fd.roic)!=null?raw(fd.roic)*100:m['roeRfy'],'%'), sub:'Return on invested capital'},
        ]
      },
      {
        title: 'Growth',
        cards: [
          {lbl:'Revenue Growth',  val:v(raw(fd.revenueGrowth)!=null ? raw(fd.revenueGrowth)*100 : null,'%'), sub:'YoY'},
          {lbl:'Earnings Growth', val:v(raw(fd.earningsGrowth)!=null ? raw(fd.earningsGrowth)*100 : null,'%'), sub:'YoY'},
          {lbl:'Rev Growth 5Y',   val:v(m['revenueGrowth5Y'],'%'), sub:'5-year CAGR'},
          {lbl:'EPS Growth 5Y',   val:v(m['epsGrowth5Y'],'%'), sub:'5-year CAGR'},
          {lbl:'Rev Growth 3Y',   val:v(m['revenueGrowth3Y'],'%'), sub:'3-year CAGR'},
          {lbl:'EPS Growth TTM',  val:v(m['epsGrowthTTMYoy'],'%'), sub:'TTM YoY'},
        ]
      },
      {
        title: 'Financial Health & Leverage',
        cards: [
          {lbl:'Debt / Equity',   val:v(raw(fd.debtToEquity),'x',1), sub:'Total debt / equity'},
          {lbl:'Current Ratio',   val:v(raw(fd.currentRatio),'x'), sub:'Current assets / liabilities'},
          {lbl:'Quick Ratio',     val:v(raw(fd.quickRatio),'x'), sub:'Liquid assets / liabilities'},
          {lbl:'FCF / Share',     val:v(raw(fd.freeCashflow) && raw(ks.sharesOutstanding) ? raw(fd.freeCashflow)/raw(ks.sharesOutstanding) : null,''), sub:'Free cash flow per share'},
          {lbl:'Cash per Share',  val:v(m['cashPerSharePerShare']!=null?m['cashPerSharePerShare']:raw(fd.totalCash)&&raw(ks.sharesOutstanding)?raw(fd.totalCash)/raw(ks.sharesOutstanding):null,''), sub:'Cash / shares outstanding'},
          {lbl:'Interest Coverage',val:v(m['netInterestCoverageAnnual']!=null?m['netInterestCoverageAnnual']:raw(fd.interestCoverage),'x'), sub:'Operating income / interest expense'},
        ]
      }
    ];

    let html = '';
    for (const sec of sections) {
      html += '<div class="advm-section"><div class="advm-section-title">'+sec.title+'</div><div class="advm-grid">';
      for (const c of sec.cards) {
        html += '<div class="advm-card"><div class="advm-lbl">'+c.lbl+'</div><div class="advm-val">'+c.val+'</div><div class="advm-sub">'+c.sub+'</div></div>';
      }
      html += '</div></div>';
    }
    if(loading) loading.style.display='none';
    if(cont) cont.innerHTML = html;
  } catch(e) {
    if(loading) loading.style.display='none';
    handleSectionError(e, 'advmetrics', cont);
    console.error('advmetrics error', e);
  }
}

/* =====================================================
   INSTITUTIONAL & FINRA OTC ACTIVITY
===================================================== */
async function loadInstitutional(ticker) {
  const dpCards  = document.getElementById('dp-cards');
  const dpCanvas = document.getElementById('dp-chart');
  const instTbl  = document.getElementById('inst-tbody');
  const loading  = document.getElementById('inst-loading');
  const nostock  = document.getElementById('inst-nostock');
  if (!ticker) { if(nostock) nostock.style.display='block'; return; }
  if(nostock) nostock.style.display='none';
  if(loading) loading.style.display='flex';

  try {
    const [dpResult, instResult] = await Promise.allSettled([
      proAwareFetch('/api/darkpool/'+encodeURIComponent(ticker),'institutional'),
      proAwareFetch('/api/institutional/'+encodeURIComponent(ticker),'institutional'),
    ]);
    if (dpResult.status === 'rejected' && instResult.status === 'rejected') throw dpResult.reason;
    const dpData = dpResult.status === 'fulfilled' ? await dpResult.value.json() : {};
    const instData = instResult.status === 'fulfilled' ? await instResult.value.json() : {};
    if(loading) loading.style.display='none';
    const instContent = document.getElementById('inst-content');
    if(instContent) instContent.style.display='block';
    const sourceParts = [dpData.impliedLens?.source, instData.impliedLens?.source].filter(Boolean).join(' + ');
    showDataSource('inst-source', {
      source: sourceParts || 'FINRA OTC Transparency + Finnhub institutional ownership',
      asOf: dpData.impliedLens?.asOf || instData.impliedLens?.asOf,
    });

    // ── OTC Flow & Short Interest cards ──
    const dp  = Array.isArray(dpData.otcActivity)
      ? dpData.otcActivity
      : Array.isArray(dpData.darkpool) ? dpData.darkpool : [];
    const si  = dpData.shortInterest || {};
    const siShares  = si.sharesShort           ? fmtShares(si.sharesShort)   : null;
    const siRatio   = si.shortRatio            ? si.shortRatio.toFixed(2)+'d'             : null;
    const siPct     = si.shortPercentOfFloat   ? (si.shortPercentOfFloat*100).toFixed(2)+'%' : null;
    const siDate    = si.dateShortInterest     || null;

    const siCards = [
      { lbl:'Short % Float',   val: siPct    || '—', color: siPct && parseFloat(siPct)>15 ? '#d96a70' : '#C6A052' },
      { lbl:'Shares Short',    val: siShares || '—', color:'var(--text)' },
      { lbl:'Short Ratio',     val: siRatio  || '—', color:'var(--text)' },
      { lbl:'SI Date',         val: siDate   || '—', color:'var(--text5)' },
    ];

    if(dpCards) {
      const dpKpi = dp.length ? [
        { lbl:'Latest Week Vol',  val: dp[0].totalWeeklyShareQuantity ? fmtShares(dp[0].totalWeeklyShareQuantity) : '—', color:'var(--gold)' },
        { lbl:'Latest Trades',   val: dp[0].totalWeeklyTradeCount    ? Number(dp[0].totalWeeklyTradeCount).toLocaleString()        : '—', color:'var(--gold)' },
        { lbl:'Avg Reported Price', val: dp[0].averageReportedPrice ? '$'+Number(dp[0].averageReportedPrice).toFixed(2) : '—', color:'var(--text)' },
      ] : [];
      const allCards = [...dpKpi, ...siCards];
      if(!allCards.length) {
        dpCards.innerHTML = '<div style="color:var(--text5);font-size:.8rem;">No FINRA OTC activity data is available for this ticker. Coverage varies by security and reporting period.</div>';
      } else {
        dpCards.innerHTML = allCards.map(c =>
          `<div class="dp-card"><div class="dp-card-lbl">${c.lbl}</div><div class="dp-card-val" style="color:${c.color}">${c.val}</div></div>`
        ).join('');
      }
    }

    // ── OTC Weekly Volume bar chart ──
    if(dpCanvas && dp.length) {
      destroyChart('dp-chart');
      dpCanvas.style.display='block';
      document.getElementById('dp-chart-empty')?.remove();
      const labels = dp.map(w=>w.weekStartDate||'').reverse();
      const vols   = dp.map(w=>w.totalWeeklyShareQuantity||0).reverse();
      S.charts['dp-chart'] = new Chart(dpCanvas, {
        type:'bar',
        data:{ labels, datasets:[{ label:'OTC weekly volume', data:vols, backgroundColor:colorAlpha(cp().price,.44), borderColor:cp().price, borderWidth:1, borderRadius:3 }] },
        options:{
          responsive:true, maintainAspectRatio:false,
          plugins:{ legend:{display:false}, tooltip:{callbacks:{label:ctx=>' '+Number(ctx.raw).toLocaleString()+' shares'}} },
          scales:{
            x:{ticks:{color:ct().muted,font:{size:9}}, grid:{display:false}},
            y:{ticks:{color:ct().muted,font:{size:9},callback:v=>fmtShares(v)}, grid:{color:gcol()}}
          }
        }
      });
    } else if(dpCanvas) {
      dpCanvas.style.display='none';
      if(!document.getElementById('dp-chart-empty')) dpCanvas.insertAdjacentHTML('afterend','<div id="dp-chart-empty" style="color:var(--text5);font-size:.78rem;padding:.5rem 0;">No weekly OTC volume data found for this ticker from FINRA.</div>');
    }

    // ── Institutional table ──
    if(instTbl) {
      const holders = instData.ownership || [];
      if(!holders.length) {
        instTbl.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text5);padding:1.5rem;">No institutional holder data available.</td></tr>';
      } else {
        instTbl.innerHTML = holders.map(h => {
          const shares    = h.share          != null ? fmtShares(h.share)       : '—';
          const pct       = h.percentageHeld != null ? (h.percentageHeld*100).toFixed(2)+'%' : '—';
          const change    = h.change         != null ? h.change : null;
          const chgColor  = change>0?'var(--market-up)':change<0?'var(--market-down)':'var(--text4)';
          const chgStr    = change!=null ? `<span style="color:${chgColor}">${change>0?'+':change<0?'−':''}${fmtShares(Math.abs(change))}</span>` : '—';
          return `<tr>
            <td>${escapeHtml(h.holderName||h.name||'—')}</td>
            <td>${escapeHtml(shares)}</td>
            <td>${escapeHtml(pct)}</td>
            <td>${chgStr}</td>
            <td style="font-size:.68rem;color:var(--text5);">${escapeHtml(h.reportDate||h.date||'—')}</td>
          </tr>`;
        }).join('');
      }
    }
  } catch(e) {
    if(loading) loading.style.display='none';
    const instWrap = document.getElementById('body-institutional');
    handleSectionError(e, 'institutional', instWrap);
    if(e.code !== 'PRO_REQUIRED' && e.code !== 'LOGIN_REQUIRED') console.error('institutional/OTC activity error', e);
  }
}

/* =====================================================
   EARNINGS TAB
===================================================== */
async function loadEarnings(ticker) {
  const cont    = document.getElementById('earn-content');
  const loading = document.getElementById('earn-loading');
  const error   = document.getElementById('earn-error');
  const nostock = document.getElementById('earn-nostock');
  if (!ticker) { if(nostock) nostock.style.display='block'; return; }
  if(nostock) nostock.style.display='none';
  if(loading) loading.style.display='block';
  if(error)   error.style.display='none';
  try {
    // Fetch forward quarterly estimates alongside historical
    const [res, estRes] = await Promise.allSettled([
      proAwareFetch('/api/earnings/' + ticker, 'earnings'),
      proAwareFetch('/api/estimates/' + ticker, 'earnings'),
    ]);
    if (res.status === 'rejected') throw res.reason;
    const data = res.status==='fulfilled' ? await res.value.json() : [];
    const estData = estRes.status==='fulfilled' ? await estRes.value.json().catch(()=>({})) : {};
    const fwdQ = estData.fwdQuarterly || [];
    const earningsSource = res.value.headers.get('X-Data-Source') || 'Reported earnings';
    showDataSource('earn-source', null, earningsSource, res.value.headers.get('X-Data-As-Of'));
    const basisNote = document.getElementById('earn-basis-note');
    if (basisNote) {
      basisNote.style.display = 'block';
      basisNote.textContent = /SEC/i.test(earningsSource)
        ? 'Actual EPS is diluted GAAP EPS from SEC filings. Period is the fiscal quarter end, not the announcement date. Consensus surprise is shown only when the provider’s consensus-compatible actual agrees with SEC GAAP EPS.'
        : 'SEC quarterly GAAP EPS is unavailable for this company. Rows use the provider’s consensus-compatible earnings basis and are labeled accordingly.';
    }

    // Build forward estimates banner if available
    let fwdHtml = '';
    if (fwdQ.length) {
      fwdHtml = `<div style="background:rgba(185,138,61,.08);border:1px solid rgba(185,138,61,.25);border-radius:8px;padding:10px 14px;margin-bottom:12px;">
        <div style="font-size:.65rem;color:var(--gold);font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;">\u2736 Analyst Forward EPS Estimates</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          ${fwdQ.map(q => `<div style="background:var(--t-metric-bg);border:1px solid var(--t-metric-border);border-radius:6px;padding:6px 10px;min-width:90px;">
            <div style="font-size:.6rem;color:var(--text5);margin-bottom:2px;">Forecast period ${q.period}</div>
            <div style="font-size:.9rem;font-weight:700;color:var(--text);">$${q.epsAvg.toFixed(2)}</div>
            <div style="font-size:.63rem;color:var(--text5);">$${(q.epsLow||q.epsAvg).toFixed(2)}–$${(q.epsHigh||q.epsAvg).toFixed(2)}</div>
            <div style="font-size:.62rem;color:var(--text5);">${q.numberAnalysts||'?'} analysts</div>
          </div>`).join('')}
        </div>
      </div>`;
    }

    if (!Array.isArray(data) || !data.length) {
      if(loading) loading.style.display='none';
      if(cont) cont.innerHTML=fwdHtml+'<div style="color:var(--text5);font-size:.82rem;">No historical earnings data found for this ticker.</div>';
      return;
    }
    // sort newest first
    const rows = data.slice().sort((a,b) => (b.period||'').localeCompare(a.period||''));
    // Build beat/miss summary bar
    const withData = rows.filter(r => r.surprisePercent != null);
    const beats = withData.filter(r => r.surprisePercent > 2).length;
    const misses = withData.filter(r => r.surprisePercent < -2).length;
    const inLine = withData.length - beats - misses;
    const beatPct = withData.length ? Math.round(beats / withData.length * 100) : 0;
    // Summary bar HTML
    let summaryHtml = '';
    if (withData.length) {
      summaryHtml = `
        <div style="display:flex;gap:8px;align-items:center;background:var(--t-metric-bg);border:1px solid var(--t-metric-border);border-radius:8px;padding:10px 14px;margin-bottom:12px;flex-wrap:wrap;">
          <div style="flex:1;min-width:180px;">
            <div style="font-size:.68rem;color:var(--text5);text-transform:uppercase;letter-spacing:.07em;margin-bottom:4px;">${ticker} EPS Beat Rate — Last ${withData.length} Quarters</div>
            <div style="height:6px;background:var(--t-acc-border);border-radius:3px;overflow:hidden;display:flex;">
              <div style="width:${beatPct}%;background:var(--chart-positive);"></div>
              <div style="width:${Math.round(inLine/withData.length*100)}%;background:var(--gold);"></div>
              <div style="width:${Math.round(misses/withData.length*100)}%;background:var(--chart-negative);"></div>
            </div>
          </div>
          <div style="display:flex;gap:12px;">
            <span style="font-size:.75rem;color:var(--market-up);"><strong>${beats}</strong> Beat</span>
            <span style="font-size:.75rem;color:var(--gold);"><strong>${inLine}</strong> In-Line</span>
            <span style="font-size:.75rem;color:var(--market-down);"><strong>${misses}</strong> Miss</span>
          </div>
        </div>`;
    }
    // Build expandable rows
    let tableHtml = '<div style="overflow-x:auto;"><table class="earn-table"><thead><tr>'
      + '<th style="text-align:left;">Fiscal quarter end</th>'
      + '<th>Consensus est.</th>'
      + '<th>Reported GAAP EPS</th>'
      + '<th>Comparable surprise</th>'
      + '<th>Result</th>'
      + '<th style="width:28px;"></th>'
      + '</tr></thead><tbody>';
    rows.forEach((row, idx) => {
      const est  = row.estimate   != null ? '$'+row.estimate.toFixed(2)   : '—';
      const act  = row.actual     != null ? '$'+row.actual.toFixed(2)     : '—';
      const streetAct = row.consensusActual != null ? '$'+row.consensusActual.toFixed(2) : null;
      const surp = row.surprise   != null ? (row.surprise > 0 ? '+' : '') + '$'+row.surprise.toFixed(2) : '—';
      const basisMismatch = row.comparisonStatus === 'basis-mismatch';
      const surpPct = row.surprisePercent != null ? (row.surprisePercent > 0 ? '+' : '') + row.surprisePercent.toFixed(1) + '%' : basisMismatch ? 'N/M' : '—';
      let badge = '', cls = '', barColor = 'var(--gold)', barWidth = 50;
      if (row.surprisePercent != null) {
        if      (row.surprisePercent >  2) { badge='<span class="earn-badge beat">BEAT</span>'; cls='earn-beat'; barColor='var(--chart-positive)'; barWidth=Math.min(100,50+row.surprisePercent*2); }
        else if (row.surprisePercent < -2) { badge='<span class="earn-badge miss">MISS</span>'; cls='earn-miss'; barColor='var(--chart-negative)'; barWidth=Math.max(5,50+row.surprisePercent*2); }
        else                               { badge='<span class="earn-badge meet">IN-LINE</span>'; cls='earn-meet'; barWidth=50; }
      } else if (basisMismatch) {
        badge='<span class="earn-badge meet">BASIS DIFF</span>';
      }
      const detailId = 'earn-det-'+idx;
      tableHtml += `<tr class="earn-expand-row" role="button" tabindex="0" aria-label="Toggle ${row.period||'earnings'} details" onclick="toggleEarnDetail('${detailId}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleEarnDetail('${detailId}')}" style="cursor:pointer;">
        <td>${row.period||'—'}${row.actualAsOf ? `<div style="font-size:.58rem;color:var(--text5);margin-top:2px;">Filed ${row.actualAsOf}</div>` : ''}</td>
        <td>${est}</td>
        <td class="${cls}">${act}${basisMismatch && streetAct ? `<div style="font-size:.58rem;color:var(--text5);margin-top:2px;">Street basis ${streetAct}</div>` : ''}</td>
        <td class="${cls}">${surpPct}</td>
        <td>${badge}</td>
        <td style="text-align:center;color:var(--text5);font-size:.7rem;" id="chev-${detailId}">›</td>
      </tr>
      <tr id="${detailId}" style="display:none;">
        <td colspan="6" style="padding:0;">
          <div style="background:var(--t-metric-bg);border-radius:6px;padding:10px 14px;margin:2px 0 4px 0;border:1px solid var(--t-metric-border);">
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:8px;">
              <div>
                <div style="font-size:.65rem;color:var(--text5);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;">Consensus estimate</div>
                <div style="font-size:.95rem;font-family:var(--mono);color:var(--text2);">${est}</div>
              </div>
              <div>
                <div style="font-size:.65rem;color:var(--text5);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;">Reported GAAP EPS</div>
                <div style="font-size:.95rem;font-family:var(--mono);color:${cls==='earn-beat'?'var(--market-up)':cls==='earn-miss'?'var(--market-down)':'var(--text2)'};">${act}</div>
              </div>
              <div>
                <div style="font-size:.65rem;color:var(--text5);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;">Comparable surprise</div>
                <div style="font-size:.95rem;font-family:var(--mono);color:${cls==='earn-beat'?'var(--market-up)':cls==='earn-miss'?'var(--market-down)':'var(--text2)'};">${surp}</div>
              </div>
            </div>
            <div style="font-size:.65rem;color:var(--text5);line-height:1.5;margin-bottom:6px;"><strong style="color:var(--text3);">Basis:</strong> ${row.actualBasis || 'Provider earnings basis'}${basisMismatch && streetAct ? ` · consensus-compatible actual ${streetAct}` : ''}. ${row.comparisonNote || ''}</div>
            ${row.surprisePercent != null ? `<div style="margin-top:6px;">
              <div style="font-size:.62rem;color:var(--text5);margin-bottom:3px;">EPS Surprise vs Estimate</div>
              <div style="height:5px;background:var(--t-acc-border);border-radius:3px;overflow:hidden;">
                <div style="width:${barWidth}%;background:${barColor};height:100%;border-radius:3px;transition:width .4s ease;"></div>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:.63rem;color:var(--text5);margin-top:2px;"><span>Miss</span><span>In-Line</span><span>Beat</span></div>
            </div>` : ''}
          </div>
        </td>
      </tr>`;
    });
    tableHtml += '</tbody></table></div>';
    if(loading) loading.style.display='none';
    if(cont) cont.innerHTML = fwdHtml + summaryHtml + tableHtml;
  } catch(e) {
    if(loading) loading.style.display='none';
    if(error) { error.style.display='block'; error.textContent='Could not load earnings: '+e.message; }
    console.error('earnings error', e);
  }
}

function toggleEarnDetail(id) {
  const det = document.getElementById(id);
  const chev = document.getElementById('chev-'+id);
  if (!det) return;
  const open = det.style.display !== 'none';
  det.style.display = open ? 'none' : 'table-row';
  if (chev) chev.textContent = open ? '›' : '˅';
}

/* =====================================================
   SEC FILINGS TAB
===================================================== */
var _secFilings = [];
var _secFilter  = 'ALL';

function badgeClass(form) {
  if (form === '10-K' || form === '10-K/A') return 'sec-badge-10k';
  if (form === '10-Q' || form === '10-Q/A') return 'sec-badge-10q';
  if (form === '8-K')  return 'sec-badge-8k';
  return 'sec-badge-other';
}

function filterSecFilings(type) {
  _secFilter = type;
  document.querySelectorAll('.sec-filter-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.form === type);
  });
  renderSecFilings();
}

function renderSecFilings() {
  const list = document.getElementById('sec-filings-list');
  if (!list) return;
  const rows = _secFilter === 'ALL' ? _secFilings : _secFilings.filter(f => f.form === _secFilter || (f.form === _secFilter + '/A'));
  if (!rows.length) {
    list.innerHTML = '<div style="font-size:.8rem;color:var(--text5);padding:.5rem 0;">No filings found for this filter.</div>';
    return;
  }
  list.innerHTML = rows.map(f => {
    const badge = badgeClass(f.form);
    const desc  = f.description || f.form;
    const url   = safeExternalUrl(f.viewerUrl && f.primaryDoc ? f.viewerUrl : f.indexUrl);
    if (!url) return '';
    return `<a href="${url}" target="_blank" rel="noopener" class="sec-filing-row">
      <span class="sec-filing-badge ${badge}">${escapeHtml(f.form)}</span>
      <span class="sec-filing-date">${escapeHtml(f.date)}</span>
      <span class="sec-filing-desc">${escapeHtml(desc)}</span>
      <span class="sec-filing-arrow">↗</span>
    </a>`;
  }).join('');
}

async function loadSecFilings(ticker) {
  const nostock  = document.getElementById('sec-nostock');
  const loading  = document.getElementById('sec-loading');
  const errEl    = document.getElementById('sec-error');
  const cont     = document.getElementById('sec-content');
  const entityLbl= document.getElementById('sec-entity-label');

  if (!ticker) {
    if(nostock) { nostock.style.display='block'; }
    if(cont)    { cont.style.display='none'; }
    return;
  }
  if(nostock) nostock.style.display='none';
  if(loading) loading.style.display='block';
  if(errEl)   errEl.style.display='none';
  if(cont)    cont.style.display='none';

  try {
    const r = await proAwareFetch('/api/sec/' + encodeURIComponent(ticker), 'secfilings');
    const d = await r.json();
    if(loading) loading.style.display='none';
    if (!d.filings) throw new Error(d.error || 'No filings found');

    if(entityLbl) entityLbl.textContent = d.entity + (d.cik ? '  ·  CIK ' + d.cik : '');

    // Store filings globally for filter
    _secFilings = d.filings;
    _secFilter  = 'ALL';
    renderSecFilings();

    if(cont) cont.style.display='block';
  } catch(e) {
    if(loading) loading.style.display='none';
    handleSectionError(e, 'secfilings', errEl || cont);
  }
}



let homeDashboardLoaded=false;
function initializeHomeDashboard(){
  if(homeDashboardLoaded) return;
  homeDashboardLoaded=true;
  setTimeout(initModernGlobe,40);
  loadFeaturedGrid();
  loadHomeTickerStrip();
  loadMarketOverview('1d');
  loadMarketMovers();
  loadHomeInsights();
  loadPortfolioSparklines();
}
// Load the tool's "Popular starting points" once, when it is actually needed.
let _featuredGridLoaded=false;
function loadFeaturedGridOnce(){ if(_featuredGridLoaded) return; _featuredGridLoaded=true; loadFeaturedGrid(); }
// Do NOT eagerly load the hidden market dashboard on the landing page — that fired a
// storm of quote/index/movers/news requests for content the visitor cannot see and was
// the main driver of slow first paint. Market data now loads when the market page is
// opened (showMarketPage → initializeHomeDashboard); the featured grid loads when the
// analyze tool opens (openSection). (audit P1-01)
if(new URLSearchParams(window.location.search).get('view')==='tool') loadFeaturedGridOnce();

// Prime the analysis limit counter for free/guest users
(async () => {
  try {
    if (window.IL_AUTH_READY) await window.IL_AUTH_READY;
    if (isPro()) { syncPlanUI(); return; }
    const r = await fetch('/api/me/limit', { credentials: 'same-origin' });
    if (!r.ok) return;
    const d = await r.json();
    if (d.limit !== null && d.plan !== 'pro' && d.plan !== 'trial') updateLimitUI(d.remaining, d.limit, d.plan);
    else syncPlanUI();
  } catch(_) {}
})();

// Enter key → search
(function(){
  var ti = document.getElementById('main-ticker');
  if (ti) ti.addEventListener('keydown', function(e){ if(e.key==='Enter'){e.preventDefault();if(typeof fetchAndRender==='function')fetchAndRender();} });
})();

/* ── Mobile navigation helpers ── */
function _setMobileNav(id) {
  const map = { home:'mbn-market', analyze:'mbn-analyze', screener:'mbn-screener', workspace:'mbn-workspace' };
  document.querySelectorAll('.mbn-item').forEach(el => el.classList.remove('mbn-active'));
  const target = map[id];
  if (target) {
    const el = document.getElementById(target);
    if (el) el.classList.add('mbn-active');
  }
  // sync mobile section tabs
  document.querySelectorAll('.mst-btn').forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-sec') === id);
  });
}
function setMobileTab(btn) {
  document.querySelectorAll('.mst-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
}
function _toggleMobileMenu() {
  const m = document.getElementById('mobile-more-menu');
  if (!m) return;
  m.classList.toggle('open');
}
// ── Top-nav account icon (mobile): open account menu or go to login ──
function navAccountTap() {
  if (window.S && S.loggedIn) {
    const w = document.getElementById('nav-acct-wrap');
    if (w) { w.style.display = 'block'; w.classList.toggle('open'); return; }
  }
  window.location.href = '/login';
}
// ── Mobile More sheet: ticker search + account access ──
function mobileTickerGo() {
  const i = document.getElementById('mmenu-ticker');
  if (!i) return;
  const v = (i.value || '').trim();
  if (!v) { i.focus(); return; }
  i.value = '';
  const menu = document.getElementById('mobile-more-menu');
  if (menu) menu.classList.remove('open');
  if (typeof heroLoadTicker === 'function') heroLoadTicker(v.toUpperCase());
}
function _mobileAccount() {
  const menu = document.getElementById('mobile-more-menu');
  if (menu) menu.classList.remove('open');
  const s = document.getElementById('nav-acct-settings');
  if (s) { s.click(); } else { window.location.href = '/login'; }
}
function syncMobileAuth() {
  const loggedIn = !!(window.S && S.loggedIn);
  const state = { 'mmenu-login': !loggedIn, 'mmenu-signup': !loggedIn, 'mmenu-account': loggedIn, 'mmenu-logout': loggedIn };
  Object.keys(state).forEach(function(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = state[id] ? '' : 'none';
  });
}
if (window.IL_AUTH_READY && window.IL_AUTH_READY.then) { window.IL_AUTH_READY.then(syncMobileAuth).catch(function(){}); }
document.addEventListener('DOMContentLoaded', function(){ setTimeout(syncMobileAuth, 1500); });
// Close more menu when tapping outside
document.addEventListener('click', function(e) {
  const menu = document.getElementById('mobile-more-menu');
  const btn  = document.getElementById('mbn-more');
  if (menu && menu.classList.contains('open') && !menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
    menu.classList.remove('open');
  }
  // Pro gate upgrade CTAs (dynamically injected .js-pgc-upgrade buttons)
  if (e.target.closest('.js-pgc-upgrade')) {
    const card = e.target.closest('[data-sec]') || e.target.closest('.section-content') || e.target.closest('.pro-gate-card');
    const sec = card ? (card.dataset.sec || card.id || 'gate_card') : 'gate_card';
    showUpgradeModal(false, 'pro_gate_' + sec);
  }
});

// ── Event delegation: saved analyses load/delete ──
(function() {
  function _attachSaListDelegation() {
    var saList = document.getElementById('sa-list');
    if (!saList) return;
    saList.addEventListener('click', function(e) {
      var btn = e.target.closest('[data-sa-action]');
      if (!btn) return;
      var idx = parseInt(btn.dataset.saIdx, 10);
      var entry = _saListEntries[idx];
      if (!entry) return;
      if (btn.dataset.saAction === 'load') {
        loadSavedAnalysis(entry);
      } else if (btn.dataset.saAction === 'del') {
        deleteSavedAnalysis(entry.id);
      }
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _attachSaListDelegation);
  } else {
    _attachSaListDelegation();
  }
})();

// ── Account modal buttons: submitUsernameChange / submitPasswordChange ──
(function() {
  function _attachAccountButtons() {
    var unBtn = document.getElementById('am-submit-username');
    var pwBtn = document.getElementById('am-submit-password');
    if (unBtn) unBtn.addEventListener('click', submitUsernameChange);
    if (pwBtn) pwBtn.addEventListener('click', submitPasswordChange);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _attachAccountButtons);
  } else {
    _attachAccountButtons();
  }
})();

// ── Batch 2 event wires ──
(function() {
  function _attachBatch2() {
    // --- Sidebar section navigation ---
    var sidebar = document.querySelector('.app-sidebar');
    if (sidebar) {
      sidebar.querySelectorAll('.sb-item').forEach(function(item) {
        item.setAttribute('role', 'button');
        item.setAttribute('tabindex', '0');
        if (!item.getAttribute('aria-label')) {
          item.setAttribute('aria-label', (item.textContent || '').trim().replace(/\s+/g, ' '));
        }
      });
      sidebar.addEventListener('click', function(e) {
        var item = e.target.closest('.sb-item');
        if (item && item.dataset.sec) {
          e.preventDefault();
          openSection(item.dataset.sec);
          if (item.dataset.wstab) {
            document.querySelectorAll('.sb-item[data-sec="workspace"]').forEach(function(el){ el.classList.toggle('active', el === item); });
            setTimeout(function(){ document.querySelector('.il-ws-tab[data-tab="' + item.dataset.wstab + '"]')?.click(); }, 60);
          }
          if (item.dataset.scroll) {
            document.querySelectorAll('.sb-item[data-sec="' + item.dataset.sec + '"]').forEach(function(el){ el.classList.toggle('active', el === item); });
            setTimeout(function(){ document.querySelector(item.dataset.scroll)?.scrollIntoView({ behavior:'smooth', block:'start' }); }, 120);
          }
        }
        var proCard = e.target.closest('#sb-pro-card');
        if (proCard) showUpgradeModal();
      });
      sidebar.addEventListener('keydown', function(e) {
        var item = e.target.closest('.sb-item');
        if (item && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          item.click();
        }
      });
    }

    // --- Mobile section tabs ---
    var mstContainer = document.getElementById('mobile-sec-tabs');
    if (mstContainer) {
      mstContainer.addEventListener('click', function(e) {
        var btn = e.target.closest('.mst-btn');
        if (btn && btn.dataset.sec) { openSection(btn.dataset.sec); setMobileTab(btn); }
      });
    }

    // --- SEC filings filter ---
    var secFilterRow = document.getElementById('sec-filter-row');
    if (secFilterRow) {
      secFilterRow.addEventListener('click', function(e) {
        var btn = e.target.closest('.sec-filter-btn');
        if (btn && btn.dataset.form) filterSecFilings(btn.dataset.form);
      });
    }

    // --- Saved analyses type filter pills ---
    var saTypeFilters = document.getElementById('sa-type-filters');
    if (saTypeFilters) {
      saTypeFilters.addEventListener('click', function(e) {
        var btn = e.target.closest('.sa-pill');
        if (btn && btn.dataset.type) setSavedTypeFilter(btn.dataset.type);
      });
    }

    // --- Saved analyses sort buttons ---
    var sdDate  = document.getElementById('sa-sort-date');
    var sdStock = document.getElementById('sa-sort-stock');
    var sdType  = document.getElementById('sa-sort-type');
    if (sdDate)  sdDate.addEventListener('click',  function() { setSavedSort('date'); });
    if (sdStock) sdStock.addEventListener('click', function() { setSavedSort('stock'); });
    if (sdType)  sdType.addEventListener('click',  function() { setSavedSort('type'); });

    // --- Saved analyses clear all ---
    var clearBtn = document.getElementById('sa-clear-all-btn');
    if (clearBtn) clearBtn.addEventListener('click', clearAllSaved);

    // --- Theme toggle ---
    var themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) themeBtn.addEventListener('click', toggleTheme);
    updateThemeControl();

    // --- Account dropdown ---
    var acctBtn = document.getElementById('nav-acct-btn');
    if (acctBtn) acctBtn.addEventListener('click', toggleAcctMenu);

    // --- Account settings link ---
    var acctSettings = document.getElementById('nav-acct-settings');
    if (acctSettings) acctSettings.addEventListener('click', function(e) {
      e.preventDefault();
      openAccountModal();
      var wrap = document.getElementById('nav-acct-wrap');
      if (wrap) wrap.classList.remove('open');
    });

    // --- Login modal close ---
    var loginClose = document.getElementById('modal-close-btn');
    if (loginClose) loginClose.addEventListener('click', closeModal);

    // --- "See plans" in login modal ---
    var seePlans = document.getElementById('modal-see-plans-btn');
    if (seePlans) seePlans.addEventListener('click', function() { closeModal(); showUpgradeModal(); });

    // --- Upgrade modal close ---
    var upClose = document.getElementById('upgrade-modal-close-btn');
    if (upClose) upClose.addEventListener('click', closeUpgradeModal);

    // --- Pricing buttons ---
    var pricingPro    = document.getElementById('pricing-pro-btn');
    var pricingFree   = document.getElementById('pricing-free-btn');
    if (pricingPro)    pricingPro.addEventListener('click',    function() { showUpgradeModal(window._pricingAnnual === true); });
    if (pricingFree)   pricingFree.addEventListener('click',   function() { openModal(); });

    // --- Horizontal sub-bar upgrade + report links ---
    var hsbUp = document.getElementById('hsb-up-link');
    if (hsbUp) hsbUp.addEventListener('click', function(e) { e.preventDefault(); showUpgradeModal(); });
    var reportBtn = document.getElementById('report-btn');
    if (reportBtn) reportBtn.addEventListener('click', function(e) { e.preventDefault(); showUpgradeModal(); });

    // --- Hero CTAs ---
    var ctaMain  = document.getElementById('cta-btn-main');
    var ctaPlans = document.getElementById('cta-btn-plans');
    if (ctaMain)  ctaMain.addEventListener('click',  function(e) { e.preventDefault(); navGoTo('analyze'); });
    if (ctaPlans) ctaPlans.addEventListener('click', function(e) { e.preventDefault(); document.getElementById('pricing').scrollIntoView({behavior:'smooth'}); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _attachBatch2);

/* ── Panel chrome: minimize/collapse system removed (blocked the expand
      button on hover and added no value). Clean up any leftovers. ── */
(function(){
  function strip(){ document.querySelectorAll('.il-panel-collapse').forEach(b=>b.remove()); }
  document.addEventListener('DOMContentLoaded',strip); strip();
})();


/* (top-bar dropdown menus removed — nav is now flat: Home, Market, Analyze, Learn, About) */

  } else {
    _attachBatch2();
  }
})();
// Patch navGoTo to also update mobile nav
(function(){
  const _orig = navGoTo;
  navGoTo = function(id) {
    _orig(id);
    _setMobileNav(id);
  };
})();
