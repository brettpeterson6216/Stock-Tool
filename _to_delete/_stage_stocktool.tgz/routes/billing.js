// ============================================================
//  Billing routes — Stripe checkout, webhook, portal
// ============================================================
const express = require("express");
const Stripe  = require("stripe");

const { db }                                                    = require("../lib/db");
const { subscriptionStatusToPlan } = require("../lib/plan");
const { validateCsrf } = require("../lib/csrf");
const { track }        = require("../lib/analytics");
const { STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
        STRIPE_PRICE_MONTHLY, STRIPE_PRICE_ANNUAL, APP_URL }   = require("../lib/config");

const stripe = STRIPE_SECRET_KEY ? Stripe(STRIPE_SECRET_KEY) : null;
const router = express.Router();

function stripeId(value) {
  if (!value) return null;
  return typeof value === "string" ? value : value.id || null;
}

async function stripeCustomerEmail(customerId) {
  if (!stripe || !customerId) return null;
  try {
    const customer = await stripe.customers.retrieve(customerId);
    return customer && !customer.deleted ? customer.email || null : null;
  } catch (_) {
    return null;
  }
}

async function findUserIdForStripeEvent({ userId, customerId, subscriptionId, email }) {
  if (userId) {
    const byId = await db.execute({ sql: "SELECT id FROM users WHERE id = ? LIMIT 1", args: [userId] });
    if (byId.rows.length) return Number(byId.rows[0].id);
  }

  if (customerId || subscriptionId) {
    const byStripe = await db.execute({
      sql: "SELECT id FROM users WHERE stripe_customer_id = ? OR stripe_subscription_id = ? LIMIT 1",
      args: [customerId || "", subscriptionId || ""],
    });
    if (byStripe.rows.length) return Number(byStripe.rows[0].id);
  }

  if (email) {
    const byEmail = await db.execute({
      sql: "SELECT id FROM users WHERE email = ? LIMIT 1",
      args: [String(email).toLowerCase()],
    });
    if (byEmail.rows.length) return Number(byEmail.rows[0].id);
  }

  return null;
}

// ============================================================
//  POST /api/stripe/create-checkout
// ============================================================
router.post("/stripe/create-checkout", validateCsrf, async (req, res) => {
  if (!req.session.userId)    return res.status(401).json({ error: "Login required." });
  const annual = req.body?.annual === true;

  try {
    const userRow  = await db.execute({
      sql: "SELECT id, email, plan, trial_ends_at, stripe_customer_id, stripe_subscription_id, email_verified FROM users WHERE id = ?",
      args: [req.session.userId],
    });
    const user     = userRow.rows[0];
    if (!user)     return res.status(404).json({ error: "User not found." });
    if (!user.email_verified) {
      return res.status(403).json({
        error: "Please verify your email before starting a trial. Check your inbox or resend from account settings.",
        requiresEmailVerification: true,
      });
    }

    if (!stripe) return res.status(503).json({ error: "Payments not configured yet." });

    if (user.stripe_subscription_id) {
      try {
        const current = await stripe.subscriptions.retrieve(user.stripe_subscription_id);
        if (["active", "trialing", "past_due"].includes(current.status)) {
          return res.status(409).json({
            error: "You already have a subscription. Manage it from your billing portal.",
            hasSubscription: true,
          });
        }
      } catch (e) {
        if (e?.code !== "resource_missing") throw e;
      }
    }

    const priceId = annual ? STRIPE_PRICE_ANNUAL : STRIPE_PRICE_MONTHLY;
    if (!priceId) return res.status(503).json({ error: "Price not configured." });

    const metadata = { userId: String(req.session.userId) };
    const params = {
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      subscription_data: { trial_period_days: 7, metadata },
      success_url: `${APP_URL}/?upgraded=1`,
      cancel_url:  `${APP_URL}/?checkout=cancelled`,
      client_reference_id: String(req.session.userId),
      metadata,
      allow_promotion_codes: true,
    };
    if (user.stripe_customer_id) {
      params.customer = user.stripe_customer_id;
    } else {
      params.customer_email = user.email;
    }

    const checkoutSession = await stripe.checkout.sessions.create(params, {
      idempotencyKey: `checkout:${req.session.userId}:${annual ? "annual" : "monthly"}:${Math.floor(Date.now() / (5 * 60 * 1000))}`,
    });
    track("checkout_started", { annual, plan: annual ? "annual" : "monthly", trialDays: 7, promotionCodes: true },
          req.sessionID, req.session.userId).catch(() => {});
    res.json({ url: checkoutSession.url });
  } catch (err) {
    console.error("Stripe checkout error:", err);
    res.status(500).json({ error: "Could not create checkout session." });
  }
});

// ============================================================
//  POST /api/stripe/webhook
// ============================================================
router.post("/stripe/webhook", async (req, res) => {
  if (!stripe) return res.status(503).send("Not configured");
  const sig = req.headers["stripe-signature"];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature error:", err.message);
    return res.status(400).send("Webhook error: " + err.message);
  }

  try {
    const processed = await db.execute({
      sql: "SELECT 1 FROM stripe_events WHERE event_id = ? LIMIT 1",
      args: [event.id],
    });
    if (processed.rows.length) return res.json({ received: true, duplicate: true });

    switch (event.type) {
      case "checkout.session.completed": {
        const sess   = event.data.object;
        const subscriptionId = stripeId(sess.subscription);
        const customerId = stripeId(sess.customer);
        if (!subscriptionId) break;
        const sub    = await stripe.subscriptions.retrieve(subscriptionId);
        const email  = sess.customer_details?.email || sess.customer_email || await stripeCustomerEmail(customerId);
        const userId = await findUserIdForStripeEvent({
          userId: sess.metadata?.userId || sess.client_reference_id,
          customerId,
          subscriptionId,
          email,
        });
        if (!userId) {
          console.warn("[stripe] checkout completed could not be linked to a user", { customerId, subscriptionId, email });
          break;
        }
        const plan   = subscriptionStatusToPlan(sub.status);
        const trialEnd = sub.trial_end ? new Date(sub.trial_end * 1000).toISOString() : null;
        await db.execute({
          sql:  "UPDATE users SET plan=?, trial_ends_at=?, stripe_customer_id=?, stripe_subscription_id=? WHERE id=?",
          args: [plan, trialEnd, customerId || stripeId(sub.customer), subscriptionId, userId],
        });
        track("checkout_completed", { plan, trial: plan === "trial" }, null, Number(userId)).catch(() => {});
        break;
      }
      case "customer.subscription.updated": {
        const sub = event.data.object;
        const customerId = stripeId(sub.customer);
        const userId = await findUserIdForStripeEvent({
          userId: sub.metadata?.userId,
          customerId,
          subscriptionId: sub.id,
          email: await stripeCustomerEmail(customerId),
        });
        if (!userId) {
          console.warn("[stripe] subscription update could not be linked to a user", { customerId, subscriptionId: sub.id });
          break;
        }
        const plan = subscriptionStatusToPlan(sub.status);
        const trialEnd = sub.trial_end ? new Date(sub.trial_end * 1000).toISOString() : null;
        await db.execute({
          sql: "UPDATE users SET plan=?, trial_ends_at=?, stripe_customer_id=?, stripe_subscription_id=? WHERE id=?",
          args: [plan, trialEnd, customerId, sub.id, userId],
        });
        track("subscription_updated", { status: sub.status, plan }, null, Number(userId)).catch(() => {});
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object;
        const customerId = stripeId(sub.customer);
        const userId = await findUserIdForStripeEvent({
          userId: sub.metadata?.userId,
          customerId,
          subscriptionId: sub.id,
          email: await stripeCustomerEmail(customerId),
        });
        if (!userId) break;
        await db.execute({
          sql: "UPDATE users SET plan='free', trial_ends_at=NULL, stripe_customer_id=?, stripe_subscription_id=? WHERE id=?",
          args: [customerId, sub.id, userId],
        });
        track("subscription_cancelled", {}, null, Number(userId)).catch(() => {});
        break;
      }
      case "invoice.payment_failed": {
        // Stripe may retry a failed invoice while the subscription remains active
        // or past_due. Access is updated from customer.subscription.updated.
        const invoice = event.data.object;
        const customerId = stripeId(invoice.customer);
        const subscriptionId = stripeId(invoice.subscription);
        const userId = await findUserIdForStripeEvent({
          customerId,
          subscriptionId,
          email: await stripeCustomerEmail(customerId),
        });
        if (userId) track("payment_failed", {}, null, Number(userId)).catch(() => {});
        break;
      }
      default:
        console.log(`[stripe] unhandled webhook event: ${event.type}`);
    }
    await db.execute({
      sql: "INSERT OR IGNORE INTO stripe_events (event_id, event_type) VALUES (?, ?)",
      args: [event.id, event.type],
    });
  } catch (err) {
    console.error(`[stripe] webhook handler error on event ${event.type}:`, err);
    return res.status(500).json({ error: "Webhook processing failed." });
  }

  res.json({ received: true });
});

// ============================================================
//  POST /api/stripe/portal
// ============================================================
router.post("/stripe/portal", validateCsrf, async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Login required." });
  if (!stripe)             return res.status(503).json({ error: "Payments not configured." });
  try {
    const r          = await db.execute({ sql: "SELECT stripe_customer_id FROM users WHERE id = ?", args: [req.session.userId] });
    const customerId = r.rows[0]?.stripe_customer_id;
    if (!customerId) return res.status(404).json({ error: "No subscription found." });
    const portalSession = await stripe.billingPortal.sessions.create({
      customer:   customerId,
      return_url: `${APP_URL}/`,
    });
    track("billing_portal_opened", {}, req.sessionID, req.session.userId).catch(() => {});
    res.json({ url: portalSession.url });
  } catch (err) {
    console.error("portal error:", err);
    res.status(500).json({ error: "Could not open the billing portal." });
  }
});

module.exports = router;
